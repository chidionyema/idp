# crew#841: the break-glass bridge, off the founder's laptop.
#
# Founder, 2026-09-04: "while this works fir now t crete dependency on laptop so while we can
# use this w need t consider debugging fro aother nachine, we have oracle login so not sure why
# ll this". He is right. Reading a pod log needs the Kubernetes API, the Oracle Console has no
# pod log view, and the API's public endpoint admits one address -- the house. So something
# other than his Mac has to hold the door open.
#
# This is that something: one Always Free instance (R14: EUR 0), inside the VCN, with no public
# IP at all. It reaches the control plane's PRIVATE endpoint, so `control_plane_allowed_cidrs`
# is not widened and nothing new is exposed to the internet. It joins the tailnet outbound
# through the NAT gateway the workers already use, so no ingress rule is opened either. Identity
# is an instance principal: nothing is stored on the machine and nobody types a credential.
#
# It is not in the cluster. A pod would die with the thing it is meant to debug; a separate
# instance survives a node event, a gateway failure and a bad Flux reconcile. The Mac
# (bin/idp-kubeapi-mac) stays as the second road, on a different failure domain again -- two
# ways in, never one.

data "oci_identity_availability_domains" "ads" {
  compartment_id = var.tenancy_ocid
}

# The workers subnet is private and regional, and its route already reaches the NAT gateway and
# the control plane. Looked up rather than passed in, so this file names no OCID (LAW 46).
data "oci_core_subnets" "workers" {
  compartment_id = var.compartment_ocid
  filter {
    name   = "display_name"
    values = ["^workers-"]
    regex  = true
  }
}

# Always Free capacity is not offered in every availability domain, and Oracle moves it: on
# 2026-09-04 VM.Standard.E2.1.Micro was offered in UK-LONDON-1-AD-2 only, and launching into
# AD-1 answers 404-NotAuthorizedOrNotFound. So the domain is chosen by asking which ones carry
# the shape today, never by taking the first one in the list.
data "oci_core_shapes" "by_ad" {
  for_each            = toset([for ad in data.oci_identity_availability_domains.ads.availability_domains : ad.name])
  compartment_id      = var.compartment_ocid
  availability_domain = each.value
}

locals {
  bridge_shape = "VM.Standard.E2.1.Micro" # Always Free; a shape change here costs money
  bridge_ads = sort([
    for ad, s in data.oci_core_shapes.by_ad : ad
    if contains([for sh in s.shapes : sh.name], local.bridge_shape)
  ])
}

data "oci_core_images" "ol9" {
  compartment_id           = var.compartment_ocid
  operating_system         = "Oracle Linux"
  operating_system_version = "9"
  shape                    = local.bridge_shape
  sort_by                  = "TIMECREATED"
  sort_order               = "DESC"
}

# The OAuth client the Tailscale operator already uses (platform/tailscale/external-secret.yaml).
# The bridge reads the same entry to join the tailnet; no second credential is minted.
data "oci_vault_secrets" "tailscale" {
  compartment_id = var.compartment_ocid
  name           = "tailscale-operator"
}

# This VCN carries no egress rules on its security list -- it is empty, and every subnet's
# reachability comes from a network security group instead. An instance launched into none of
# them can reach nothing: the first bridge booted cleanly and then sat there while
# pkgs.tailscale.com:443 timed out, so Tailscale never installed. So the bridge carries its own
# group rather than borrowing the workers', which would hand it worker-level reach it has no
# use for. Egress only; groups are stateful, so the replies come back without an ingress rule,
# and nothing may open a connection to this machine.
resource "oci_core_network_security_group" "bridge" {
  compartment_id = var.compartment_ocid
  vcn_id         = module.oke.vcn_id
  display_name   = "${var.cluster_name}-bridge"
}

# Packages, and Tailscale's control plane and its DERP relays, which are all HTTPS.
resource "oci_core_network_security_group_security_rule" "bridge_https" {
  network_security_group_id = oci_core_network_security_group.bridge.id
  direction                 = "EGRESS"
  protocol                  = "6" # TCP
  destination               = "0.0.0.0/0"
  destination_type          = "CIDR_BLOCK"
  description               = "HTTPS out: package repositories, Tailscale control and DERP"
  tcp_options {
    destination_port_range {
      min = 443
      max = 443
    }
  }
}

# Tailscale negotiates a direct WireGuard path over UDP on ports it picks, and finds it with
# STUN, so the port cannot be pinned. This is what keeps traffic off the relays.
resource "oci_core_network_security_group_security_rule" "bridge_wireguard" {
  network_security_group_id = oci_core_network_security_group.bridge.id
  direction                 = "EGRESS"
  protocol                  = "17" # UDP
  destination               = "0.0.0.0/0"
  destination_type          = "CIDR_BLOCK"
  description               = "UDP out: Tailscale WireGuard and STUN, and DNS"
}

# The private control-plane endpoint. This is the whole reason the machine exists.
resource "oci_core_network_security_group_security_rule" "bridge_kubeapi" {
  network_security_group_id = oci_core_network_security_group.bridge.id
  direction                 = "EGRESS"
  protocol                  = "6" # TCP
  destination               = module.oke.control_plane_subnet_cidr
  destination_type          = "CIDR_BLOCK"
  description               = "Kubernetes API: the control-plane subnet only, not the whole VCN"
  tcp_options {
    destination_port_range {
      min = 6443
      max = 6443
    }
  }
}

# The instance metadata service, which is how the instance principal proves who it is. Without
# this the machine cannot read the vault or mint a kubeconfig.
resource "oci_core_network_security_group_security_rule" "bridge_metadata" {
  network_security_group_id = oci_core_network_security_group.bridge.id
  direction                 = "EGRESS"
  protocol                  = "all"
  destination               = "169.254.0.0/16"
  destination_type          = "CIDR_BLOCK"
  description               = "Instance metadata: the instance principal's identity"
}

resource "oci_core_instance" "bridge" {
  compartment_id      = var.compartment_ocid
  availability_domain = local.bridge_ads[0]
  display_name        = "${var.cluster_name}-bridge"
  shape               = local.bridge_shape

  create_vnic_details {
    subnet_id        = data.oci_core_subnets.workers.subnets[0].id
    assign_public_ip = false # the whole point: no door on the internet
    nsg_ids          = [oci_core_network_security_group.bridge.id]
    display_name     = "${var.cluster_name}-bridge"
  }

  source_details {
    source_type = "image"
    source_id   = data.oci_core_images.ol9.images[0].id
  }

  metadata = {
    ssh_authorized_keys = var.ssh_public_key
    user_data = base64encode(templatefile("${path.module}/cloud-init/bridge.yaml", {
      cluster_id          = module.oke.cluster_id
      region              = var.region
      tailscale_secret_id = data.oci_vault_secrets.tailscale.secrets[0].id
    }))
  }

  # The image is rebuilt by Oracle constantly; a new one is not a reason to replace a working
  # bridge. Recreate deliberately with -replace when the base image should move.
  lifecycle {
    precondition {
      condition     = length(local.bridge_ads) > 0
      error_message = "No availability domain in this region currently offers ${local.bridge_shape}; the bridge would cost money on any other shape (R14)."
    }

    ignore_changes = [source_details[0].source_id, metadata["ssh_authorized_keys"]]
  }
}

resource "oci_identity_dynamic_group" "bridge" {
  provider       = oci.home
  compartment_id = var.tenancy_ocid
  name           = "${var.cluster_name}-bridge"
  description    = "the break-glass bridge instance, and only it (crew#841)"
  matching_rule  = "ALL {instance.id = '${oci_core_instance.bridge.id}'}"
}

resource "oci_identity_policy" "bridge" {
  provider       = oci.home
  compartment_id = var.compartment_ocid
  name           = "${var.cluster_name}-bridge"
  description    = "the bridge may reach the cluster and read the tailnet join credential, nothing else (crew#841)"
  statements = [
    "Allow dynamic-group ${oci_identity_dynamic_group.bridge.name} to use cluster-family in compartment id ${var.compartment_ocid}",
    "Allow dynamic-group ${oci_identity_dynamic_group.bridge.name} to read secret-family in compartment id ${var.compartment_ocid} where target.secret.name = 'tailscale-operator'",
  ]
}

# The subject a ClusterRoleBinding names for an instance principal is the instance's OCID
# (platform/rbac/bridge.yaml). Printed here so the binding can be filled in without a console.
# The cluster has to know which instance principal to trust, and that identity changes every time
# the machine is rebuilt. Copying the OCID into platform/rbac/bridge.yaml by hand after each apply
# is the hacked-together version of this, and it goes stale silently -- a ClusterRoleBinding
# naming a destroyed instance refuses nothing and grants nothing, it just quietly stops working.
# So the identity is published here and the cluster reads it: External Secrets syncs this entry
# into flux-system and Flux substitutes it into the binding. Nobody edits a file, and a rebuild
# propagates on its own.
resource "oci_vault_secret" "bridge_identity" {
  compartment_id = var.compartment_ocid
  vault_id       = oci_kms_vault.estate.id
  key_id         = oci_kms_key.estate.id
  secret_name    = "bridge-instance-ocid"
  secret_content {
    content_type = "BASE64"
    content      = base64encode(oci_core_instance.bridge.id)
  }
}

output "bridge_instance_ocid" {
  value = oci_core_instance.bridge.id
}
