#!/usr/bin/env python3
from __future__ import annotations
import importlib.machinery
import importlib.util
import inspect
import json
import logging
import math
import os
import re
import sqlite3
import subprocess
import sys
import typing
import urllib.error
import urllib.request
import yaml
from pathlib import Path

try:
    from mcp.plugins import pobr_grant

    # The door's ceiling, imported from the one module that defines it. This file used to carry
    # `args.get("timeout", 55)`, a second opinion about the same work that sat BELOW the door's
    # 100s and killed long intents before the executor ever reached its own bound (measured
    # 2026-10-25: bin/idp-ci's schema rung runs 57s, so invoking it through this door would have
    # been cut at 55s and reported as a timeout rather than as the work).
    from mcp.plugins.estate_executor import CEILING_SEC as DOOR_CEILING_SEC
except ImportError:
    pobr_grant = None  # type: ignore
    DOOR_CEILING_SEC = 100  # restated only if the door itself cannot be imported

# The backstop this door holds around the child. It is DERIVED from the ceiling (+ process start
# and teardown), never a number of its own: a bound that undercuts the door turns a slow intent into
# a false timeout, and a bound that restates the ceiling as a literal is a second answer that
# drifts. The child bounds itself; this only catches a child that never returns.
CHILD_BACKSTOP_SEC = DOOR_CEILING_SEC + 15

HOME = Path.home()
# The laptop installs the library at ~/.estate/intents. The estate-mcp image has no ~/.estate
# and carries the committed library at /app/intents instead (estate-mcp.Dockerfile); before that,
# production estate_list answered "# 0 intents available" (measured 2026-10-01 in the pod).
INTENTS = Path(os.environ.get("ESTATE_INTENTS_DIR") or HOME / ".estate" / "intents")

# The executor's own ledger: how often each intent has run, so the search ranks the intents
# agents actually reuse above the one-offs (1822 runs, 387 of 537 intents run exactly once,
# measured 2026-09-30).
ESTATE_DB = HOME / ".estate" / "estate.db"
MAX_MATCHES = 12
log = logging.getLogger(__name__)

# THE POD'S PATH TO THE GOVERNED DOOR (idp#7579 R2).
#
# The estate-mcp image ships the intent LIBRARY and no executor: `~/.estate/bin/estate-execute`
# and the plan ledger are absent from it, so the production `estate_invoke` had no gate at all
# -- the production intent path was not the governed door. The laptop owns the gate, the
# ledger and the audit, so a pod WITHOUT a local executor asks the laptop over ONE
# authenticated, intent-scoped route. A pod WITH a local executor keeps using it: that is the
# laptop's own path and it must not change.
LAPTOP_INTENT_URL_ENV = "ESTATE_LAPTOP_INTENT_URL"
LAPTOP_INTENT_TOKEN_FILE_ENV = "ESTATE_LAPTOP_INTENT_TOKEN_FILE"  # noqa: S105 -- a path
LAPTOP_INTENT_TOKEN_ENV = "ESTATE_LAPTOP_INTENT_TOKEN"  # noqa: S105 -- an env var NAME


def _local_executor() -> Path:
    """This host's own door, if it has one. The pod does not; the laptop does."""
    return HOME / ".estate" / "bin" / "estate-execute"


def _remote_intent_token() -> str:
    """The credential for the laptop's intent door: a mounted file first, then the environment.

    A file is preferred because a token in an environment variable is a token in every crash
    dump and every `/proc` of the pod.
    """
    path = (os.environ.get(LAPTOP_INTENT_TOKEN_FILE_ENV) or "").strip()
    if path:
        try:
            token = Path(path).read_text().strip()
        except OSError:
            token = ""
        if token:
            return token
    return (os.environ.get(LAPTOP_INTENT_TOKEN_ENV) or "").strip()


def _invoke_remote(name, arg_items, session, timeout):
    """Run one intent on the laptop's governed door, from a host that has no door of its own."""
    url = (os.environ.get(LAPTOP_INTENT_URL_ENV) or "").strip()
    token = _remote_intent_token()
    if not url or not token:
        return (
            "ERROR: this gateway has no local executor and no laptop intent door. Set {} and "
            "{}.".format(LAPTOP_INTENT_URL_ENV, LAPTOP_INTENT_TOKEN_FILE_ENV)
        )
    payload = json.dumps(
        {"intent": name, "args": dict(arg_items), "session_id": session or ""}
    )
    request = urllib.request.Request(  # noqa: S310 -- operator-supplied door URL only
        url,
        data=payload.encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310
            body = json.loads(response.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:400]
        return "ERROR (HTTP {}): {}".format(exc.code, detail)
    except (urllib.error.URLError, OSError, ValueError) as exc:
        return "ERROR: the laptop intent door did not answer: {}".format(exc)
    if not isinstance(body, dict):
        return (
            "ERROR: the laptop intent door answered with something that is not a result"
        )
    out = str(body.get("stdout") or "").strip()
    err = str(body.get("stderr") or "").strip()
    try:
        code = int(body.get("exit_code") or 0)
    except (TypeError, ValueError):
        code = 1
    if body.get("ok") and code == 0:
        return out if out else "ok"
    return "ERROR (exit {}):\n{}\n{}".format(code, out, err)


# The plan contract, loaded only to RESOLVE A SESSION (who is calling). The gate itself lives in
# the intent executor, which reads the same durable ledger -- this plugin does not second-guess
# the door, it only tells the door which session the call belongs to (idp#7576).
_PLAN_CONTRACT = None
_PLAN_CONTRACT_TRIED = False


def _plan_contract():
    """The plan module, from the checkout this plugin lives in, or from the installed runtime."""
    global _PLAN_CONTRACT, _PLAN_CONTRACT_TRIED
    if _PLAN_CONTRACT_TRIED:
        return _PLAN_CONTRACT
    _PLAN_CONTRACT_TRIED = True
    root = Path(__file__).resolve().parents[2]
    estate = HOME / ".estate"
    candidates = [
        root / "platform" / "estate" / "memory" / "plan.py",
        estate / "runtime" / "idp" / "platform" / "estate" / "memory" / "plan.py",
        estate / "memory" / "platform" / "estate" / "memory" / "plan.py",
    ]
    for path in candidates:
        try:
            if not path.exists():
                continue
            spec = importlib.util.spec_from_file_location(
                "estate_plan_contract", str(path)
            )
            if spec is None or spec.loader is None:
                continue
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            _PLAN_CONTRACT = module
            return _PLAN_CONTRACT
        except Exception as exc:  # noqa: BLE001 - try the next candidate
            log.warning("plan contract %s failed to load: %s", path, exc)
    return None


def _resolve_caller_session(explicit: str = "") -> tuple:
    """Who is calling, in order of trust: the stated session, the environment, the pointer file.

    Returns (session_id, source). An empty session means ANONYMOUS AUTOMATION: standing estate
    policy lets it through, and the door records it as such. What must never happen is a
    planless LIVE session reaching work through this path while the gate thinks it is anonymous
    -- that blind spot is exactly what idp#7576 records.
    """
    stated = (explicit or "").strip()
    if stated:
        return stated, "argument"
    module = _plan_contract()
    if module is not None:
        try:
            sid = (module.resolve_session_id() or "").strip()
            if sid:
                return sid, "environment-or-pointer"
        except Exception as exc:  # noqa: BLE001 - identity must never break the door
            log.warning("session identity resolution failed: %s", exc)
    return "", "anonymous"


_ALLOWED = re.compile(r"^[a-z][a-z0-9.-]*$")
_REGISTRY = None


def _is_valid(n):
    return bool(_ALLOWED.match(n))


def _load_intents():
    r = []
    for f in sorted(INTENTS.glob("*.yaml")):
        try:
            with open(f) as fh:
                d = yaml.safe_load(fh)
            r.append(
                {
                    "name": f.stem,
                    "description": d.get("description", "").strip(),
                    "args": {
                        k: v.get("help", "") for k, v in d.get("args", {}).items()
                    },
                    "halt_on_failure": d.get("halt_on_failure", True),
                }
            )
        except Exception as exc:
            log.warning("intent %s failed: %s", f.name, exc)
    return r


def _load_intent(name):
    if not _is_valid(name):
        return None
    p = INTENTS / (name + ".yaml")
    if not p.exists():
        return None
    with open(p) as fh:
        return yaml.safe_load(fh)


_FILLER = frozenset(
    "a an the for to of in on and or with from by is it its my this that".split()
)


def _words(text):
    return [
        w for w in re.split(r"[^a-z0-9]+", str(text).lower()) if w and w not in _FILLER
    ]


def _same(q, t):
    """One word matches another exactly or on a shared stem of five letters or more:
    "encode" finds "encoding", "compare" finds "comparator", "parse" finds "parser", and
    "compare" does not find "comp"."""
    return q == t or len(os.path.commonprefix([q, t])) >= 5


def _covered(query_words, text_words):
    """The query words the text covers."""
    return {q for q in query_words if any(_same(q, t) for t in text_words)}


def _run_counts():
    try:
        con = sqlite3.connect("file:{}?mode=ro".format(ESTATE_DB), uri=True)
        try:
            return dict(
                con.execute("SELECT intent, count(*) FROM intent_tickets GROUP BY 1")
            )
        finally:
            con.close()
    except sqlite3.Error:
        return {}


def _harv_parts():
    """The harv shelf: sealed, tested functions from open-source libraries. Read straight from
    the registry index, newest version of each name."""
    home = Path(os.environ.get("HARV_HOME") or HOME / ".estate" / "harv")
    db = home / "registry" / "index.db"
    if not db.exists():
        return [], "no harv shelf at {}".format(db)
    try:
        con = sqlite3.connect("file:{}?mode=ro".format(db), uri=True)
        try:
            rows = con.execute(
                "SELECT name, version, tier FROM artifacts ORDER BY created"
            ).fetchall()
        finally:
            con.close()
    except sqlite3.Error as exc:
        return [], "harv shelf at {} unreadable: {}".format(db, exc)
    latest = {}
    for name, version, tier in rows:
        latest[name] = (version, tier)
    return [{"name": n, "version": v, "tier": t} for n, (v, t) in latest.items()], None


def _find(query):
    """Everything the estate already has that matches `query`: intents and harv parts, ranked
    by how many query words they cover, then by how often the intent has been reused."""
    q = _words(query)
    if not q:
        return (
            '# nothing in the estate matches "{}"\n'
            'Only filler words were given: say what you need, e.g. "base64 encode".'
        ).format(query)
    runs = _run_counts()
    parts, shelf_error = _harv_parts()
    cands = []
    for i in _load_intents():
        in_name = _covered(q, _words(i["name"]))
        cands.append(
            (in_name | _covered(q, _words(i["description"])), in_name, "intent", i)
        )
    for p in parts:
        cover = _covered(q, _words(p["name"]))
        cands.append((cover, cover, "part", p))
    # A word that matches almost everything ("numbers", "status") says little; a rare one
    # ("levenshtein", "base64") says a lot. Each covered word counts by its rarity (IDF).
    n = len(cands) or 1
    weight = {
        w: math.log((n + 1) / (1 + sum(1 for c in cands if w in c[0]))) for w in q
    }
    found = []
    for cover, in_name, kind, x in cands:
        if cover:
            used = runs.get(x["name"], 0) if kind == "intent" else 0
            score = sum(weight[w] for w in cover)
            found.append((len(cover), round(score, 6), len(in_name), used, kind, x))
    # A shelf that could not be read is said, never shown as "no parts match".
    note = [
        "NOTE: {}; harv parts are missing from these results.".format(shelf_error),
        "",
    ]
    note = note if shelf_error else []
    if not found:
        return "\n".join(
            ['# nothing in the estate matches "{}"'.format(query)]
            + note
            + [
                "No intent and no harv part covers it. Check the words, then build it once "
                "as an intent so the next agent finds it here."
            ]
        )
    # Most of the request covered first; among those, the rarer words; then covered by the
    # name; then the most reused.
    found.sort(key=lambda f: (-f[0], -f[1], -f[2], -f[3], f[5]["name"]))
    lines = [
        '# {} match(es) for "{}" (best first)'.format(len(found), query),
        "",
    ] + note
    for _n, _score, _in_name, used, kind, x in found[:MAX_MATCHES]:
        if kind == "intent":
            lines.append("## intent {} (run {} time(s))".format(x["name"], used))
            lines.append(x["description"][:160])
            argl = ", ".join('"{}": ...'.format(a) for a in x["args"])
            lines.append(
                'call: estate_invoke {{"intent": "{}", "args": {{{}}}}}'.format(
                    x["name"], argl
                )
            )
        else:
            lines.append(
                "## harv part {} {} ({}: tested, sealed, no network/files/clock)".format(
                    x["name"], x["version"], x["tier"]
                )
            )
            lines.append(
                'call: estate_invoke {{"intent": "harv", "args": {{"verb": "run", '
                '"name": "{}", "text": "<input>"}}}}'.format(x["name"])
            )
        lines.append("")
    if len(found) > MAX_MATCHES:
        lines.append(
            "{} more; add words to narrow it.".format(len(found) - MAX_MATCHES)
        )
    return "\n".join(lines)


# A full estate_list is every intent with its description and args. Measured 2026-11-11: 381
# intents = 7,576 chars, about 1,894 tokens, on a call that mostly answers "is there a door for
# this?" and mostly gets no. The routed view below serves the few that answer the question and
# keeps the full list reachable, so a missing route is never read as a missing capability.
LIST_DEFAULT = int(os.environ.get("ESTATE_LIST_DEFAULT", "12"))


def _route(query, limit):
    """The intents a task actually needs, best first, reusing the one scorer `_find` uses.

    Deliberately NOT a second matcher: `_words`, `_covered` and the rarity weighting already
    exist for `estate_list query=`, and two scorers would drift (AGENTS.md section 6)."""
    q = _words(query)
    cands = []
    for i in _load_intents():
        in_name = _covered(q, _words(i["name"]))
        cands.append((in_name | _covered(q, _words(i["description"])), in_name, i))
    n = len(cands) or 1
    weight = {
        w: math.log((n + 1) / (1 + sum(1 for c in cands if w in c[0]))) for w in q
    }
    scored = []
    for cover, in_name, i in cands:
        if not cover:
            continue
        score = sum(weight.get(w, 0.0) for w in cover) + 0.5 * sum(
            weight.get(w, 0.0) for w in in_name
        )
        scored.append((score, i["name"], i))
    scored.sort(key=lambda t: (-t[0], t[1]))
    return [i for _s, _n, i in scored[:limit]], len(scored)


def _render(intents, header):
    lines = [header]
    for i in intents:
        lines.append("## {}".format(i["name"]))
        lines.append(i["description"][:120])
        if i["args"]:
            lines.append("args: {}".format(", ".join(i["args"].keys())))
        lines.append("")
    return "\n".join(lines)


def _estate_list(args):
    args = args or {}
    query = args.get("query", "")
    if query:
        return _find(query)
    intents = _load_intents()
    if args.get("full"):
        return _render(intents, "# {} intents available:".format(len(intents)))
    try:
        limit = int(args.get("limit", LIST_DEFAULT))
    except (TypeError, ValueError):
        limit = LIST_DEFAULT
    # Without a query there is nothing to rank on, so the routed view is the intents an agent
    # most often needs to start a piece of work, in that order, and it says how to see the rest.
    routed = _first_contact(intents)[:limit]
    lines = _render(
        routed,
        "# {} of {} intents (the ones work usually starts with):".format(
            len(routed), len(intents)
        ),
    )
    return (
        lines
        + '\nAll {} are reachable: `estate_list query="<what you need>"` to find the right '
        "one, or `estate_list full=true` for every intent.".format(len(intents))
    )


# The intents a session reaches for before anything else, in the order the estate's own laws name
# them: declare the work, then look at what exists, then run it. Kept short on purpose -- this is
# a starting point, not a catalogue, and `query=` is the real router.
FIRST_CONTACT = (
    "lane-submit",
    "ci.status",
    "pr-state",
    "git-status",
    "work-audit",
    "code-review",
    "explore",
    "search-text",
    "disk-free",
    "host-pressure",
    "hypotheses.race",
    "claim-open",
)


def _first_contact(intents):
    by_name = {i["name"]: i for i in intents}
    out = [by_name[n] for n in FIRST_CONTACT if n in by_name]
    seen = set(i["name"] for i in out)
    out.extend(i for i in intents if i["name"] not in seen)
    return out


def _estate_show(args):
    name = args.get("intent", "")
    if not name:
        return "ERROR: intent name required"
    d = _load_intent(name)
    if d is None:
        avail = ", ".join(sorted(f.name for f in INTENTS.glob("*.yaml")))
        return "ERROR: unknown intent: {}\n\nAvailable: {}".format(name, avail)
    lines = ["# {}".format(name), "", d.get("description", "")]
    if d.get("args"):
        lines.append("\n## Args:")
        for k, v in d["args"].items():
            lines.append("  {}: {}".format(k, v.get("help", "")[:80]))
            if "default" in v:
                lines.append("    default: {}".format(v["default"]))
    if d.get("steps"):
        lines.append("\n## Steps:")
        for i, s in enumerate(d["steps"]):
            lines.append("  {}. {}".format(i + 1, s.get("cmd", "")[:80]))
    return "\n".join(lines)


def _estate_invoke(args):
    name = args.get("intent", "")
    # A caller may still ask for a shorter bound explicitly (a probe wants to fail fast); the
    # default is the backstop above, which cannot undercut the door's own budget.
    try:
        timeout = int(args.get("timeout", CHILD_BACKSTOP_SEC))
    except (TypeError, ValueError):
        return "ERROR: timeout must be whole seconds, got {}".format(
            args.get("timeout")
        )
    if not name:
        return "ERROR: intent name required"
    if not _is_valid(name):
        return "ERROR: invalid intent name: {}".format(name)
    d = _load_intent(name)
    if d is None:
        return "ERROR: unknown intent: {}".format(name)
    # The session this call belongs to. Explicit beats environment beats pointer; the child is
    # told through BOTH the environment and an explicit flag, so the identity survives a child
    # that scrubs one of them (idp#7576).
    session, session_source = _resolve_caller_session(args.get("session_id") or "")
    log.debug(
        "estate_invoke intent=%s session=%s source=%s",
        name,
        session or "anonymous",
        session_source,
    )
    arg_items = []
    for k, v in (args.get("args") or {}).items():
        if not re.match(r"^[a-z_][a-z0-9_]*$", str(k)):
            return "ERROR: invalid arg name: {}".format(k)
        arg_items.append((str(k), v))
    exe = _local_executor()
    if not exe.exists():
        # No executor on this host (the estate-mcp pod): the door is on the laptop, and the
        # session travels there UNCHANGED -- a programmatic session is not a voice session and
        # is never namespaced as one (idp#7579 R2).
        return _invoke_remote(name, arg_items, session, timeout)
    cmd = [sys.executable, str(exe), name]
    if session:
        cmd.extend(["--session", session])
    child_env = dict(os.environ)
    if session:
        child_env["ESTATE_SESSION_ID"] = session
    for k, v in arg_items:
        cmd.append("{}={}".format(k, v))
    idp_root = HOME / "Documents" / "code" / "idp"
    try:
        r = subprocess.run(  # noqa: S603  # cmd validated by regex above
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(idp_root),
            env=child_env,
            check=False,
        )
        out = r.stdout.strip()
        if r.returncode == 0:
            return out if out else "ok"
        err = r.stderr.strip() if r.stderr else ""
        msg = "ERROR (exit {}):\n{}\n{}"
        return msg.format(r.returncode, out, err)
    except subprocess.TimeoutExpired:
        return "ERROR: intent timed out after {}s".format(timeout)
    except Exception as exc:
        return "ERROR: {}".format(exc)


def _registry_door():
    """The Estate Capability Registry door, loaded from the checkout this plugin lives in.

    The registry is a door in the repository (bin/capability-index), not a copy of a store
    inside this plugin: the plugin asks, the door answers (spec principle 1: one store,
    many renderers).
    """
    global _REGISTRY
    if _REGISTRY is not None:
        return _REGISTRY
    root = Path(os.environ.get("ESTATE_IDP") or Path(__file__).resolve().parents[2])
    door_path = root / "bin" / "capability-index"
    if not door_path.exists():
        _REGISTRY = False
        return _REGISTRY
    spec = importlib.util.spec_from_loader(
        "capability_index",
        importlib.machinery.SourceFileLoader("capability_index", str(door_path)),
    )
    if spec is None or spec.loader is None:
        _REGISTRY = False
        return _REGISTRY
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception as exc:  # a door that will not load is BLIND, never a crash
        log.warning("capability registry door failed to load: %s", exc)
        _REGISTRY = False
        return _REGISTRY
    _REGISTRY = module
    return _REGISTRY


def _registry_records(door):
    ctx = door.Context()
    return door.load_records(ctx)


def _capability_get(args):
    door = _registry_door()
    if not door:
        return "BLIND  the capability registry door (bin/capability-index) is not in this checkout"
    cap_id = (args.get("id") or "").strip()
    if not cap_id:
        return "ERROR: capability id required"
    records, source = _registry_records(door)
    for record in records:
        if record.get("id") == cap_id:
            read = door.read_record(record)
            return "{}\n  source: {}".format(door.render_record(read), source)
    return "BLIND  no record for {}".format(cap_id)


def _capability_query(args):
    door = _registry_door()
    if not door:
        return "BLIND  the capability registry door (bin/capability-index) is not in this checkout"
    query = (args.get("query") or "").strip()
    kind = (args.get("kind") or "").strip()
    state = (args.get("state") or "").strip()
    plane = (args.get("plane") or "").strip()
    records, source = _registry_records(door)
    words = [w for w in re.split(r"[^a-z0-9]+", query.lower()) if w]
    rows = []
    for record in records:
        if kind and record.get("kind") != kind:
            continue
        if plane and record.get("plane") != plane:
            continue
        read = door.read_record(record)
        if state and (read.get("health") or {}).get("state") != state:
            continue
        if words:
            haystack = " ".join(
                [
                    record.get("id") or "",
                    record.get("summary") or "",
                    " ".join((record.get("contract") or {}).get("inputs") or []),
                ]
            ).lower()
            if not all(w in haystack for w in words):
                continue
        rows.append(read)
    rows.sort(key=lambda r: r.get("id") or "")
    if not rows:
        return "BLIND  no capability matches {}".format(
            query or (kind or state or plane or "anything")
        )
    lines = [
        "# {} capability record(s) (source: {})".format(len(rows), source),
        "",
    ]
    for read in rows[:40]:
        stale = "  stale" if read.get("stale") else ""
        lines.append(
            "{}  [{}]  {}  plane={}{}".format(
                read.get("id"),
                read.get("kind"),
                (read.get("health") or {}).get("state"),
                read.get("plane"),
                stale,
            )
        )
        if read.get("summary"):
            lines.append("    {}".format(read["summary"][:160]))
    if len(rows) > 40:
        lines.append("")
        lines.append("{} more; narrow the query.".format(len(rows) - 40))
    return "\n".join(lines)


def _capability_prove(args):
    door = _registry_door()
    if not door:
        return "BLIND  the capability registry door (bin/capability-index) is not in this checkout"
    cap_id = (args.get("id") or "").strip()
    if not cap_id:
        return "ERROR: capability id required"
    records, _source = _registry_records(door)
    for record in records:
        if record.get("id") == cap_id:
            verdict = door.prove(door.Context(), record)
            return "{}: {}".format(verdict.get("verdict"), verdict.get("detail", ""))
    return "BLIND  no record for {}".format(cap_id)


try:
    from datasette import hookimpl
except ImportError:

    def hookimpl(fn):
        return fn


TOOL_DEFS = [
    {
        "name": "estate_list",
        "description": (
            "Find what the estate already has before building anything. Pass `query` in plain "
            'words ("base64 encode", "ci status for a pr") to get the matching intents and '
            "harv parts (tested, sealed functions from open-source libraries), best first, "
            "each with the exact estate_invoke call. Without `query`: the intents work usually "
            "starts with, and how to see the rest (a full list is ~1,894 tokens on 381 intents)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "What you need, in plain words",
                },
                "limit": {
                    "type": "integer",
                    "description": "How many intents the routed view returns (default 12)",
                },
                "full": {
                    "type": "boolean",
                    "description": "Return every intent, unbounded (the pre-2026-11-11 view)",
                },
            },
        },
    },
    {
        "name": "estate_show",
        "description": "Show args and description for one intent.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "intent": {"type": "string", "description": "Intent name"},
            },
            "required": ["intent"],
        },
    },
    {
        "name": "estate_invoke",
        "description": "Run an estate intent via the intent system.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "intent": {"type": "string", "description": "Intent name"},
                "args": {"type": "object", "description": "Intent args", "default": {}},
                "session_id": {
                    "type": "string",
                    "description": (
                        "The estate session this call belongs to. Optional: when it is absent the "
                        "door resolves it from the environment and the runtime's pointer file."
                    ),
                },
                "timeout": {
                    "type": "integer",
                    "description": "Max seconds (default 55s)",
                },
            },
            "required": ["intent"],
        },
    },
    {
        "name": "capability_get",
        "description": (
            "One capability from the Estate Capability Registry, with its proof, its "
            "freshness and whether the record is stale. An answer that names no registry "
            "read is a guess."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {
                    "type": "string",
                    "description": "Capability id, e.g. cap:intent/lane-submit",
                },
            },
            "required": ["id"],
        },
    },
    {
        "name": "capability_query",
        "description": (
            "Find capabilities in the Estate Capability Registry by words, kind, plane or "
            "state (operating, degraded, frozen, declared). Use it before building anything: "
            "the estate has already built most of it."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Plain words: what you need the estate to do",
                },
                "kind": {
                    "type": "string",
                    "description": "intent | tool | service | layer | agent | surface | model | dataset | workflow",
                },
                "plane": {
                    "type": "string",
                    "description": "idp | estate | cluster | mac",
                },
                "state": {
                    "type": "string",
                    "description": "operating | degraded | frozen | declared",
                },
            },
        },
    },
    {
        "name": "capability_prove",
        "description": (
            "Re-run the receipt probe for one capability and report the verdict: OK, FAILED "
            "or BLIND. This is the proof behind a claim of working."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {
                    "type": "string",
                    "description": "Capability id, e.g. cap:intent/lane-submit",
                },
            },
            "required": ["id"],
        },
    },
    {
        "name": "pobr_submit",
        "description": "Submit a PoBR receipt to consume the session grant.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "Session ID matching the grant",
                },
                "receipt": {
                    "type": "object",
                    "description": "PoBR receipt dict from the reasoning trace",
                    "default": {},
                },
            },
            "required": ["session_id"],
        },
    },
    {
        "name": "pobr_status",
        "description": "Check PoBR grant status for a session.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "Session ID to check",
                },
            },
            "required": ["session_id"],
        },
    },
]


def _pobr_submit(args):
    if pobr_grant is None:
        return "ERROR: pobr_grant not available"
    session_id = args.get("session_id", "")
    receipt = args.get("receipt", {})
    result = pobr_grant.pobr_submit_tool(session_id, receipt)
    return str(result)


def _pobr_status(args):
    if pobr_grant is None:
        return "ERROR: pobr_grant not available"
    session_id = args.get("session_id", "")
    result = pobr_grant.grant_status(session_id)
    return str(result)


TOOL_FNS = {
    "estate_list": _estate_list,
    "estate_show": _estate_show,
    "estate_invoke": _estate_invoke,
    "capability_get": _capability_get,
    "capability_query": _capability_query,
    "capability_prove": _capability_prove,
    "pobr_submit": _pobr_submit,
    "pobr_status": _pobr_status,
}


@hookimpl
def register_mcp_tools(datasette, mcp):
    for td in TOOL_DEFS:
        fn = TOOL_FNS[td["name"]]

        def make_wrapper(f, td=td):
            def wrapper(kwargs):
                tool_name = td["name"]

                # --- PoBR grant gate ---
                if pobr_grant is not None and pobr_grant.requires_grant(tool_name):
                    session_id = kwargs.get("session_id", "")
                    if not session_id:
                        return {
                            "content": [
                                {
                                    "type": "text",
                                    "text": (
                                        "PoBR grant required for {}. "
                                        "Call pobr_submit or pobr_status first."
                                    ).format(tool_name),
                                }
                            ],
                            "isError": True,
                        }
                    check = pobr_grant.check_grant(session_id)
                    if not check.get("valid"):
                        return {
                            "content": [
                                {
                                    "type": "text",
                                    "text": "PoBR grant check failed: {}".format(
                                        check.get("reason", "unknown")
                                    ),
                                }
                            ],
                            "isError": True,
                        }
                # --- end PoBR gate ---

                try:
                    result = f(kwargs)
                    return {"content": [{"type": "text", "text": str(result)}]}
                except Exception as exc:
                    err_msg = "ERROR: {}".format(exc)
                    return {
                        "content": [{"type": "text", "text": err_msg}],
                        "isError": True,
                    }

            return wrapper

        mcp.add_tool(
            _as_mcp_tool(make_wrapper(fn), td),
            name=td["name"],
            description=td["description"],
        )


_JSON_TYPES = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
    "object": dict,
    "array": list,
}


def _as_mcp_tool(wrapper, td):
    """The MCP SDK 2.x `add_tool` takes no `inputSchema`: it reads the schema off the function's
    signature. estate-mcp crash-looped on `unexpected keyword argument 'inputSchema'` from
    2026-09-28 (datasette-mcp pulls `mcp>=2.0.0` unpinned). Build that signature from the tool's
    own inputSchema, so the declared schema stays the one source, and turn an error result into
    an exception, which the SDK reports as isError."""
    schema = td["inputSchema"]
    required = set(schema.get("required", []))
    params, annotations = [], {}
    for name, spec in schema.get("properties", {}).items():
        typ = _JSON_TYPES.get(spec.get("type"), object)
        if name in required:
            param = inspect.Parameter(
                name, inspect.Parameter.KEYWORD_ONLY, annotation=typ
            )
        else:
            typ = typing.Optional[typ]
            param = inspect.Parameter(
                name,
                inspect.Parameter.KEYWORD_ONLY,
                default=spec.get("default"),
                annotation=typ,
            )
        params.append(param)
        annotations[name] = typ

    def tool(**kwargs):
        out = wrapper({k: v for k, v in kwargs.items() if v is not None})
        text = out["content"][0]["text"]
        if out.get("isError"):
            raise RuntimeError(text)
        return text

    tool.__name__ = td["name"]
    tool.__doc__ = td["description"]
    tool.__signature__ = inspect.Signature(params, return_annotation=str)
    tool.__annotations__ = {**annotations, "return": str}
    return tool
