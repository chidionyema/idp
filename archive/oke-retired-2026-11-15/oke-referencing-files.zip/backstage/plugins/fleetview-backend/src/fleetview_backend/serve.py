#!/usr/bin/env python3
"""FleetView launcher.

The plugin's logic lives in `fleetview_backend/routes.py` as a proper Python module.
This file is the HTTP shell that mounts its routes on the paths the Backstage board calls.

The Backstage backend's proxy plugin (app-config.yaml `proxy.endpoints./fleetview`)
forwards requests here, with `pathRewrite: { '^/api/fleetview': '' }`, so the launcher
listens at root and the proxy strips the prefix before forwarding.

Run:
    python -m fleetview_backend.serve 18790
"""

from __future__ import annotations

import asyncio
import hmac
import json
import logging
import os
import subprocess
import sys
import threading
import time
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse

# fleetview_backend is installed as a package. All modules use normal imports.
from fleetview_backend import (
    approvals_adapter,
    claude_code_adapter,
    delivery,
    executor_link,
    metrics,
    nats_adapter,
    routes,
)

# THE PROGRAMMATIC INTENT DOOR (idp#7579 R2).
#
# The estate-mcp pod ships the intent LIBRARY but no executor and no plan ledger, so a
# programmatic intent run there had no gate at all -- the production intent path was not the
# governed door. The laptop owns the gate, the ledger and the audit, so the pod asks the
# laptop, over ONE authenticated, intent-scoped route. This credential is NOT the mac-door
# token (that one runs arbitrary commands) and NOT the voice key (that one is a router key):
# it buys exactly one thing, which is running a COMMITTED intent through the laptop's own door.
INTENT_TOKEN_ENV = "FLEETVIEW_INTENT_TOKEN"  # noqa: S105 -- an env var NAME, not a secret
INTENT_TOKEN_FILE_ENV = "FLEETVIEW_INTENT_TOKEN_FILE"  # noqa: S105 -- a path, not a secret
# The launchd-safe mirror of the encrypted secret. A launchd job cannot read the vault under
# ~/Documents (macOS TCC) and does not have `sops` on its PATH, so the encrypted copy is
# mirrored under ~/.estate/secrets and decrypted with the PINNED sops binary.
INTENT_SECRET_MIRROR = "~/.estate/secrets/dev/fleetview-intent.yaml"  # noqa: S105 -- a path
SOPS_BIN = "~/.cache/estate-tools/sops"
AGE_KEY_FILE = "~/.config/prospector/age-key.txt"
_INTENT_TOKEN_CACHE = ""


def _decrypt_secret(path: Path) -> str:
    """One leaf (`token`) out of an encrypted secret file, or "".

    Never the whole document, never a log line: the value is a credential, and the only thing
    that needs it is the comparison below.
    """
    sops = os.path.expanduser(os.environ.get("SOPS") or SOPS_BIN)
    key = os.path.expanduser(os.environ.get("SOPS_AGE_KEY_FILE") or AGE_KEY_FILE)
    try:
        proc = subprocess.run(  # noqa: S603
            [sops, "--decrypt", "--output-type", "json", str(path)],
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
            env={**os.environ, "SOPS_AGE_KEY_FILE": key},
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    if proc.returncode != 0:
        return ""
    try:
        doc = json.loads(proc.stdout)
    except ValueError:
        return ""
    token = doc.get("token") if isinstance(doc, dict) else None
    return token.strip() if isinstance(token, str) else ""


def intent_token() -> str:
    """The laptop's credential for the programmatic intent door.

    Order: the environment, then a token FILE, then the launchd-safe encrypted mirror. An
    absent credential means the door is CLOSED -- never open, never a default.
    """
    global _INTENT_TOKEN_CACHE
    token = (os.environ.get(INTENT_TOKEN_ENV) or "").strip()
    if token:
        return token
    path = (os.environ.get(INTENT_TOKEN_FILE_ENV) or "").strip()
    if path:
        try:
            token = Path(path).read_text().strip()
        except OSError:
            token = ""
        if token:
            return token
    if _INTENT_TOKEN_CACHE:
        return _INTENT_TOKEN_CACHE
    token = _decrypt_secret(Path(os.path.expanduser(INTENT_SECRET_MIRROR)))
    if token:
        _INTENT_TOKEN_CACHE = token
    return token


class _ClosingStream(StreamingResponse):
    """A StreamingResponse that closes its body iterator when the response ends.

    WHY (issue #5829). Starlette answers a streamed response with
    `async for chunk in self.body_iterator: await send(...)` and no aclose(). When the client goes
    away, listen_for_disconnect returns and the task group cancels the sender -- but the sender is
    suspended in `send`, not in the iterator, so the generator is left at its yield with nobody to
    resume it and every finally behind it never runs. Measured live: 191 sockets to nats:4222
    behind 49 inbound ones, `[Errno 24] Too many open files` 12,114 times. Closing the iterator is
    the one thing this response owns, so it closes it here, after the cancelled scope has exited
    (the finally below runs whether __call__ returned or raised).
    """

    async def __call__(self, scope, receive, send) -> None:
        try:
            await super().__call__(scope, receive, send)
        finally:
            aclose = getattr(self.body_iterator, "aclose", None)
            if aclose is not None:
                await aclose()


@asynccontextmanager
async def lifespan(app: FastAPI):
    nats_url = os.environ.get("NATS_URL", "")
    if nats_url:
        # crew#1013: ensure all three estate streams exist before any adapter starts publishing.
        # Idempotent -- safe to call every startup; the bus already knows streams that exist.
        try:
            await nats_adapter.ensure_estate_streams(nats_url)
        except Exception:  # noqa: BLE001, S110 -- bus may be down; adapters retry on publish
            pass
        ledger_prefix = os.environ.get("ESTATE_STATE_PATH_PREFIX") or None
        try:
            asyncio.create_task(
                claude_code_adapter.run_claude_code_adapter(nats_url, ledger_prefix)
            )
        except Exception:  # noqa: BLE001, S110 -- adapter startup failure must not break the app
            pass
        asyncio.create_task(approvals_adapter.run_approvals_adapter(nats_url))
        from fleetview_backend import efficiency_feed

        asyncio.create_task(efficiency_feed.publish_highlights(nats_url))
        # The research department's verified claims, on the news channel: the same air the
        # room's rundown and the board already breathe. Until this task the claims reached
        # only the findings strip and a voice that was asked directly.
        from fleetview_backend import research_feed

        asyncio.create_task(research_feed.publish_claims(nats_url))
        from fleetview_backend import key_sync

        asyncio.create_task(key_sync.publish_alerts(nats_url))
        # The outbox (steer intents from the browser, signed actions from the router's
        # action_ledger) only reaches the bus if this worker runs. Nothing started it before
        # 2026-09-29: ~/.estate/outbox.db stayed 0 bytes and every row that would have carried
        # an event to the Fleet director never left this process (crew#983).
        from fleetview_backend import outbox

        await outbox.start_worker(nats_url)
    sessions_url = os.environ.get("FLEETVIEW_SESSIONS_URL", "").strip()
    if sessions_url:
        # Warm the voice's fleet snapshot so the first spoken turn does not pay the relay either.
        _refresh_in_background(sessions_url)
    # The face's voice is warm before anyone asks (2026-10-16): after a restart the first clause
    # paid the lazy engine import and the first subprocess spawn itself -- ~20s on the founder's
    # first words. Off the critical path: warm_voice logs its own failures and never blocks serve.
    from fleetview_backend import voice_media

    asyncio.create_task(voice_media.warm_voice())
    yield
    if nats_url:
        from fleetview_backend import outbox

        await outbox.stop_worker()


async def _bus_reachable(nats_url: str) -> dict:
    """A TCP connect to the bus, bounded at 0.5s: reachable or not, and why."""
    if not nats_url:
        return {"reachable": False, "reason": "NATS_URL is unset"}
    from urllib.parse import urlparse  # noqa: PLC0415

    u = urlparse(nats_url)
    try:
        _r, w = await asyncio.wait_for(
            asyncio.open_connection(u.hostname, u.port or 4222), timeout=0.5
        )
        w.close()
        return {"reachable": True, "url": nats_url}
    except Exception as exc:  # noqa: BLE001 - the reason is the answer
        return {"reachable": False, "url": nats_url, "reason": type(exc).__name__}


def _voice_sessions() -> list[dict]:
    """The fleet the voice answers from: the SAME fleet the board draws.

    On OKE the board's /fleetview proxy goes to the founder's Mac (fleetview-mac-egress.yaml),
    but /voice/* is routed to this sidecar, whose /data/estate.db is the CI-built copy with no
    session rows. So the board showed 431 agents while the voice said "zero agents are running"
    (measured 2026-10-08). FLEETVIEW_SESSIONS_URL points this at the board's source; unset (a
    laptop launch, where the local store IS the fleet) or unreachable, the local store answers.
    """
    url = os.environ.get("FLEETVIEW_SESSIONS_URL", "").strip()
    if url:
        # A VOICE TURN NEVER WAITS ON THE MAC (2026-10-09). The upstream is the Mac over Tailscale,
        # which runs through the "lhr" DERP relay, not a direct path: the 235KB board took 8.1s,
        # 21.0s, 29.5s and 18.3s to arrive from inside the pod, against 0.09s on the Mac itself,
        # and every /voice/stream waited for it before asking the model (~1s). That was most of
        # the founder's 49s reply. So the turn answers from the last snapshot and a refresh runs
        # behind it; only the first turn after start, with no snapshot yet, fetches inline.
        snap = _sessions_snapshot.get("rows")
        if snap is None:
            rows = _fetch_board_sessions(url)
            if rows is not None:
                return rows
        else:
            if time.time() - _sessions_snapshot["at"] > SESSIONS_REFRESH_S:
                _refresh_in_background(url)
            return snap
    body, _ = routes.sessions_envelope()
    return body.get("sessions") or []


# How old the voice's fleet snapshot may get before a turn starts a refresh. The board itself
# repaints on its own SSE; this is only what the spoken answer counts from.
SESSIONS_REFRESH_S = 15.0
_sessions_snapshot: dict = {"rows": None, "at": 0.0}
_sessions_refreshing = threading.Lock()


def _fetch_board_sessions(url: str) -> list[dict] | None:
    import json  # noqa: PLC0415
    import urllib.request  # noqa: PLC0415

    try:
        with urllib.request.urlopen(url, timeout=5) as r:  # noqa: S310 - our own Service
            rows = json.load(r).get("sessions") or []
    except Exception as exc:  # noqa: BLE001 - fall back to the local store, and say so
        print(
            f"voice.sessions upstream failed: {type(exc).__name__}: {exc}",
            file=sys.stderr,
            flush=True,
        )
        return None
    _sessions_snapshot.update(rows=rows, at=time.time())
    return rows


def _refresh_in_background(url: str) -> None:
    # One refresh at a time: a burst of turns over a slow relay must not stack fetches.
    if not _sessions_refreshing.acquire(blocking=False):
        return

    def run():
        try:
            _fetch_board_sessions(url)
        finally:
            _sessions_refreshing.release()

    threading.Thread(target=run, daemon=True).start()


def build_app() -> FastAPI:
    app = FastAPI(title="FleetView", version="1.1.0", lifespan=lifespan)

    @app.get(routes.SESSIONS_PATH)
    def sessions():
        body, status = routes.sessions_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.STREAM_PATH)
    async def stream():
        nats_url = os.environ.get("NATS_URL", "")

        async def gen_nats():
            body, _status = routes.sessions_envelope()
            for record in body.get("sessions") or []:
                yield routes.stream_frames([record])[0]
            import json as _json

            # Each source closes itself when this response ends (issue #5829). The generator has
            # to be closed, not merely abandoned: one suspended at its yield never runs its
            # finally, and the finally is what releases the bus subscription.
            async def _events():
                gen = nats_adapter.subscribe_stream(nats_url)
                try:
                    async for event in gen:
                        yield f"data: {_json.dumps(event)}\n\n"
                finally:
                    await nats_adapter.close_gen(gen)

            async def _cues():
                gen = nats_adapter.subscribe_cues(nats_url)
                try:
                    async for cue in gen:
                        yield routes.cue_frame(cue)
                finally:
                    await nats_adapter.close_gen(gen)

            async def _stories():
                gen = nats_adapter.subscribe_stories(nats_url)
                try:
                    async for on, story in gen:
                        yield routes.story_frame(on, story)
                finally:
                    await nats_adapter.close_gen(gen)

            async def _approvals():
                gen = nats_adapter.subscribe_approvals(nats_url)
                try:
                    async for approval in gen:
                        yield f"data: {__import__('json').json.dumps({'type': 'approval', **approval})}\n\n"
                finally:
                    await nats_adapter.close_gen(gen)

            last_hb = asyncio.get_event_loop().time()
            merged = nats_adapter.merge(
                nats_adapter.isolated("events", _events()),
                nats_adapter.isolated("cues", _cues()),
                nats_adapter.isolated("stories", _stories()),
                nats_adapter.isolated("approvals", _approvals()),
            )
            try:
                async for frame in merged:
                    yield frame
                    now = asyncio.get_event_loop().time()
                    if now - last_hb >= 30:
                        yield ": heartbeat\n\n"
                        last_hb = now
                while True:
                    await asyncio.sleep(30)
                    yield ": heartbeat\n\n"
            finally:
                await nats_adapter.close_gen(merged)

        async def gen():
            body, _status = routes.sessions_envelope()
            for record in body.get("sessions") or []:
                yield routes.stream_frames([record])[0]
            while True:
                await asyncio.sleep(30)
                yield ": heartbeat\n\n"

        return _ClosingStream(
            gen_nats() if nats_url else gen(), media_type="text/event-stream"
        )

    @app.get(routes.NOTES_PATH)
    def notes_get(session_id: str):
        body, status = routes.notes_envelope(session_id)
        return JSONResponse(content=body, status_code=status)

    @app.post(routes.NOTES_PATH)
    async def notes_post(request: Request):
        body = await request.json()
        result, status = routes.add_note(body)
        return JSONResponse(content=result, status_code=status)

    @app.post(routes.NUDGE_PATH)
    async def nudge_post(request: Request):
        body = await request.json()
        result, status = routes.add_nudge(body)
        return JSONResponse(content=result, status_code=status)

    @app.get(routes.SIGNALS_PATH)
    def signals_get(session_id: str):
        body, status = routes.signals_envelope(session_id)
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.REPLIES_PATH)
    def replies_get(session_id: str = "", limit: int = 20):
        body, status = routes.reply_envelope(session_id, limit)
        return JSONResponse(content=body, status_code=status)

    # ------------------------------------------------------------------ identity on the
    # DESTRUCTIVE PATHS
    #
    # WHY THIS EXISTS. Measured by review 2026-09-20: `POST /work` accepts a caller-supplied pid
    # for ANY session id with no authentication. CORS is not an access control -- a page can send
    # a cross-origin request without a preflight by using `Content-Type: text/plain`, and
    # FastAPI's `await request.json()` does not care about the header. What the pid is FOR is the
    # hard-stop path (`/kill`, restored separately): a forged work row would aim it at a process
    # of the forger's choosing.
    #
    # `FLEETVIEW_BOARD_KEY` is a shared secret on that pair, following the pattern the executor
    # relay already uses (`FLEETVIEW_EXECUTOR_KEY`). It is UNLIKE the executor key in one way that
    # matters: the BROWSER must present it, so it cannot be a secret in the cryptographic sense --
    # anything the page can read, a page can leak. What it buys is that a drive-by page cannot
    # forge the call without first reading this app's own memory, and it makes the tampering
    # deliberate rather than accidental.
    #
    # THE HONEST GAP, stated rather than implied: this is not user authentication. On loopback,
    # with this board as the only client, it raises the bar from "any page" to "a page that can
    # read the board's key". Real identity is the estate's own C4/C5 work and is not claimed here.
    #
    # `/work` GET and both `/replies` verbs stay open: they are reads of telemetry and writes of
    # conversation text (redacted at the writer in redact.py), not the pid chain.
    def _check_board_key(x_board_key: str | None) -> None:
        expected = os.environ.get("FLEETVIEW_BOARD_KEY")
        key_file = os.environ.get("FLEETVIEW_BOARD_KEY_FILE")
        if not expected and key_file:
            try:
                expected = Path(key_file).read_text().strip() or None
            except FileNotFoundError:
                expected = None
        # UNSET MEANS NO ENFORCEMENT, deliberately: a laptop run must keep working with no vault
        # loaded, and the alternative -- a service that refuses to start -- is worse for the case
        # this rule actually protects (a public deployment). The estate's secrets work is what sets
        # it in the cluster, and the log warns so an unset key is visible rather than assumed.
        if not expected:
            logging.getLogger(__name__).warning(
                "FLEETVIEW_BOARD_KEY is unset: the destructive work/kill chain is UNPROTECTED"
            )
            return
        if x_board_key != expected:
            raise HTTPException(status_code=401, detail="bad or missing board key")

    # WHAT EACH SESSION IS WORKING ON. GET reads it; POST is the session's own report.
    @app.get(routes.WORK_PATH)
    def work_get():
        body, status = routes.work_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.post(routes.WORK_PATH)
    async def work_post(
        request: Request, x_board_key: str | None = Header(default=None)
    ):
        # `/work` writes the PID that a hard-stop will signal, so it is half of the destructive
        # chain even though it is not destructive itself.
        _check_board_key(x_board_key)
        try:
            payload = await request.json()
        except Exception:  # noqa: BLE001
            return JSONResponse(content={"error": "body must be JSON"}, status_code=400)
        body, status = routes.post_work(payload if isinstance(payload, dict) else {})
        return JSONResponse(content=body, status_code=status)

    @app.post(routes.REPLIES_PATH)
    async def replies_post(request: Request):
        try:
            payload = await request.json()
        except Exception:  # noqa: BLE001 -- a body that is not JSON never reached a session
            return JSONResponse(content={"error": "body must be JSON"}, status_code=400)
        body, status = routes.post_reply(payload if isinstance(payload, dict) else {})
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.TRACE_PATH)
    def trace_get(session_id: str):
        body, status = routes.trace_envelope(session_id)
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.DEVICE_STATUS_PATH)
    def device_status():
        body, status = routes.device_status_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.post(routes.DEVICE_AUTHORIZE_PATH)
    def device_authorize_post():
        # POST: this mints a single-use challenge, and a GET that changed state would be prefetchable.
        body, status = routes.device_authorize_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.LEDGER_PATH)
    def ledger_get(session_id: str):
        body, status = routes.ledger_tail_envelope(session_id)
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.BLAST_RADIUS_PATH)
    def blast_radius(node_id: str = ""):
        body, status = routes.blast_radius_envelope(node_id)
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.GRAPH_PATH)
    def graph():
        body, status = routes.graph_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.MEMORY_PATH)
    def memory():
        body, status = routes.memory_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.GREENLANE_PATH)
    def greenlane():
        body, status = routes.greenlane_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.CLAIMS_PATH)
    def claims():
        # The live agent claims (routes.claims_envelope, fleetview_backend/claims.py): who holds
        # which paths, and how stale the heartbeat is. Sync handler on purpose -- the GitHub read
        # is urllib inside, and FastAPI runs sync handlers in its threadpool.
        body, status = routes.claims_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.RESEARCH_PATH)
    def research():
        # Loopback GET to the portal's research-output plugin. Sync handler on purpose:
        # FastAPI runs sync handlers in its threadpool, so the urllib read is off the event
        # loop for free -- no get_running_loop/run_in_executor dance (that combo 500s: a sync
        # handler has no running loop, and an awaited Future does not unpack as a tuple).
        body, status = routes.research_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.ESTATE_PATH)
    def estate():
        # Green + burn + research in one envelope (routes.estate_envelope); each part
        # individually cached, so this stays cheap on a 10-15s poll. Sync handler, same
        # reasoning as research() above.
        body, status = routes.estate_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.HARV_PATH)
    def harv():
        body, status = routes.harv_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.HARNESS_PATH)
    def harness():
        body, status = routes.harness_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.post(routes.CHECK_RECEIPTS_PATH)
    async def check_receipts_post(request: Request):
        body = await request.json()
        result, status = routes.check_receipts_envelope(body)
        return JSONResponse(content=result, status_code=status)

    @app.get(routes.MUTATIONS_PATH)
    async def mutations_get():
        body, status = await routes.mutations_envelope()
        return JSONResponse(content=body, status_code=status)

    @app.post(routes.MUTATIONS_APPROVE_PATH)
    async def mutations_approve_post(request: Request):
        body = await request.json()
        result, status = await routes.approve_mutation(body)
        return JSONResponse(content=result, status_code=status)

    @app.post(routes.MUTATIONS_REJECT_PATH)
    async def mutations_reject_post(request: Request):
        body = await request.json()
        result, status = await routes.reject_mutation(body)
        return JSONResponse(content=result, status_code=status)

    @app.get("/healthz")
    async def healthz():
        # `ok` is liveness and stays true; `bus` says whether the estate bus answers. 2026-09-27
        # the laptop's NATS was never installed, this answered {"ok": true} throughout, and every
        # voice turn and the board's live stream went without it with nobody told.
        return {"ok": True, "bus": await _bus_reachable(os.environ.get("NATS_URL", ""))}

    @app.get("/metrics")
    def metrics_handler():
        if os.environ.get("METRICS_ENABLED", "").lower() not in (
            "1",
            "true",
            "yes",
            "on",
        ):
            raise HTTPException(status_code=404, detail="metrics not enabled")
        try:
            from sovereign.voice import turnlog  # noqa: PLC0415

            summary = turnlog.summary()
        except Exception:  # noqa: BLE001
            summary = {"turns": 0, "empty": 0, "errors": 0}
        body = metrics.render(summary)
        return Response(
            content=body, media_type="text/plain; version=0.0.4; charset=utf-8"
        )

    # -- voice routes ------------------------------------------------------------
    # Lazy imports: voice and voice_media load Kokoro (~90s) on first use.
    # Keeping them out of module-level imports means the service starts immediately.

    @app.post("/voice/say")
    async def voice_say(request: Request):
        """Text -> PCM streaming via Cartesia Sonic. One clause, immediate."""
        from fleetview_backend import voice_media as vm

        body = await request.json()
        pcm, err = await vm.say(body.get("text", ""))
        if err:
            return JSONResponse(content={"error": err}, status_code=502)
        return Response(content=pcm, media_type="audio/pcm")

    @app.post("/voice/hear")
    async def voice_hear(request: Request, session_id: str = "", author: str = ""):
        """PCM -> transcript via Deepgram. Author required (estate law: no unattributed steer)."""
        from fleetview_backend import voice_media as vm

        pcm = await request.body()
        body, status = await vm.hear(pcm, session_id, author)
        return JSONResponse(content=body, status_code=status)

    @app.post("/voice/stream")
    async def voice_stream(request: Request):
        """Question -> SSE clauses. Full conversation with fleet context + history."""
        from fleetview_backend import voice as voice_module

        body = await request.json()
        question = body.get("question", "")
        history = body.get("history") or []
        session_id = str(body.get("session_id") or "")

        # A SPOKEN INTENT RUNS BEFORE THE BRAIN ANSWERS. The prompt tells the model every catalogue
        # intent "runs on the laptop" when named, but since the page moved from the voice-router
        # socket (which called /voice/intent inside the turn, #4437) to this stream, nothing ran
        # them: the face could describe an intent and never do it. handle() is the same matcher,
        # confirmation rule and audit /voice/intent uses; None means the utterance named none.
        from fleetview_backend import voice_intents as vi

        loop = asyncio.get_running_loop()
        ran = await loop.run_in_executor(None, vi.handle, question, session_id)
        if ran is not None:

            async def intent_gen():
                yield voice_module._sse("intent", ran)
                yield voice_module._sse("delta", {"text": ran["text"]})
                yield voice_module._sse("done", {"intent": ran["intent"]})

            return StreamingResponse(intent_gen(), media_type="text/event-stream")

        sessions = await loop.run_in_executor(None, _voice_sessions)

        # VOICE PRESENCE ON THE BUS: every spoken turn lands as an estate.agent event so the
        # board and the room show the founder talking to the estate as it happens, not just
        # agents talking to each other. Presence only -- this says a turn HAPPENED, never
        # that it succeeded; the answer's own provenance stays in the friction log.
        nats_url = os.environ.get("NATS_URL", "")
        if nats_url and (question or "").strip():
            from fleetview_backend import nats_adapter as _na

            asyncio.create_task(
                _na.publish(
                    nats_url,
                    session_id="voice",
                    runtime="fleetview",
                    kind="phase",
                    phase="asked",
                    tool="voice",
                    text=str(question)[:200],
                )
            )

        async def gen():
            # stream_ask is a plain (sync) generator: it makes blocking urllib calls to the
            # router. Iterating it directly on the event loop -- `async for` doesn't even work,
            # since it has no __aiter__ -- would also stall every other request (the board's SSE
            # included) for the length of the router call. Each `next()` runs in a thread instead,
            # same reasoning `hear()` uses for the CPU-bound transcribe call.
            loop = asyncio.get_running_loop()
            it = iter(voice_module.stream_ask(question, sessions, history))
            _DONE = object()
            try:
                while True:
                    frame = await loop.run_in_executor(None, lambda: next(it, _DONE))
                    if frame is _DONE:
                        break
                    yield frame
            except Exception as exc:  # noqa: BLE001
                # Through _sse like every other frame (2026-10-14). This was hand-built as
                # {'error': '...'} -- Python's repr, not JSON -- so the page's JSON.parse threw,
                # the frame was skipped, and a turn whose brain had failed ended in silence with
                # no error shown. An exception carrying a newline would also have split the frame.
                yield voice_module._sse(
                    "error", {"error": str(exc) or type(exc).__name__}
                )

        return StreamingResponse(gen(), media_type="text/event-stream")

    @app.post("/voice/done")
    async def voice_done(request: Request):
        """Turn ended: write friction log, close bus row."""
        from fleetview_backend import voice_media as vm

        body = await request.json()
        result, status = await vm.answered(body)
        return JSONResponse(content=result, status_code=status)

    @app.get("/voice/voices")
    async def voice_voices():
        """Catalogue: say / kokoro / piper groups + live engine. Does not load models."""
        from fleetview_backend import voice_media as vm

        return JSONResponse(content=await vm.voices())

    @app.post("/voice/select")
    async def voice_select(request: Request):
        """Switch live engine + voice."""
        from fleetview_backend import voice_media as vm

        body = await request.json()
        result, status = await vm.select(body.get("engine", ""), body.get("voice", ""))
        return JSONResponse(content=result, status_code=status)

    @app.get("/voice/log")
    async def voice_log(limit: int = 40):
        """Recent voice turns, newest first."""
        from fleetview_backend import voice_media as vm

        return JSONResponse(content=vm.log(limit=limit))

    @app.get("/friction")
    async def friction(window_hours: float = 24.0):
        """What the doors refused, ranked -- read from the ledger the door wrote, never re-derived.

        `available: false` means the ledger could not be read (BLIND). It does not mean zero: an
        empty board and a broken board are different facts, and the page renders them differently.
        """
        from fleetview_backend import friction_feed

        return JSONResponse(
            content=await asyncio.to_thread(friction_feed.summary, window_hours)
        )

    @app.get("/friction/stream")
    async def friction_stream(window_hours: float = 24.0):
        """One `friction` frame per tick, so the tile moves with nobody reloading it."""
        from fleetview_backend import friction_feed

        return StreamingResponse(
            friction_feed.stream(window_hours), media_type="text/event-stream"
        )

    @app.get("/pi-sessions")
    async def pi_sessions(limit: int = 8):
        """The pi-session monitor's last receipt, in the shape `/fleet` renders.

        Read from `~/.estate/pi-observe/latest.json`, which the scheduled job writes; nothing is
        re-measured here. `available: false` means nothing has looked or the receipt is unreadable
        -- which is not the same fact as "no pi processes are running", and the tile says so.
        """
        from fleetview_backend import observe_feed

        return JSONResponse(
            content=await asyncio.to_thread(observe_feed.summary, limit)
        )

    @app.get("/pi-sessions/stream")
    async def pi_sessions_stream(limit: int = 8):
        """One `pi-sessions` frame per tick, so the tile moves with nobody reloading it."""
        from fleetview_backend import observe_feed

        return StreamingResponse(
            observe_feed.stream(limit), media_type="text/event-stream"
        )

    @app.get("/efficiency")
    async def efficiency(since: str = "1h"):
        from fleetview_backend import efficiency_feed

        return JSONResponse(
            content=await asyncio.to_thread(efficiency_feed.summary, since)
        )

    @app.get("/efficiency/proof")
    async def efficiency_proof():
        from fleetview_backend import efficiency_feed

        return JSONResponse(content=await asyncio.to_thread(efficiency_feed.proof))

    @app.get("/efficiency/stream")
    async def efficiency_stream(since: str = "1h"):
        from fleetview_backend import efficiency_feed

        return StreamingResponse(
            efficiency_feed.stream(since), media_type="text/event-stream"
        )

    # The founder's evals, live (2026-10-23): every agent is under continuous evaluation and the
    # surface reports it as the round runs, not as a report read afterwards. Two endpoints, no
    # second store: `eval/founder-agent/` writes the ledger and the feed, this reads them.
    @app.get("/evals/founder-agent")
    async def founder_agent_evals(limit: int = 200):
        from fleetview_backend import founder_agent_evals as fa

        try:
            body = await asyncio.to_thread(fa.snapshot, limit)
        except fa.EvalsAbsent as exc:
            # 503 with the path it looked for: an eval panel must never render "no rounds" over
            # a ledger that is not there.
            return JSONResponse(status_code=503, content={"absent": str(exc)})
        return JSONResponse(content=body)

    @app.get("/evals/founder-agent/stream")
    async def founder_agent_evals_stream(limit: int = 200):
        from fleetview_backend import founder_agent_evals as fa

        return StreamingResponse(fa.stream(limit), media_type="text/event-stream")

    @app.get("/voice/log/summary")
    async def voice_log_summary(limit: int = 200):
        """Friction stats: empty rate, median latencies, per-voice speed."""
        from fleetview_backend import voice_media as vm

        return JSONResponse(content=vm.log_summary(limit=limit))

    @app.post("/voice/speculate")
    async def voice_speculate(request: Request):
        """Server-side speculative intent for partial transcripts."""
        from fleetview_backend import voice_media as vm

        body = await request.json()
        trace_context = {
            k: v for k, v in request.headers.items() if k.lower().startswith("x-trace-")
        }
        result, status = await vm.speculate(body, trace_context or None)
        return JSONResponse(content=result, status_code=status)

    @app.post("/voice/steer")
    async def voice_steer(request: Request):
        """Validated JSON intent from browser -> outbox -> NATS. Author required."""
        from fleetview_backend import voice_media as vm

        body = await request.json()
        trace_context = {
            k: v for k, v in request.headers.items() if k.lower().startswith("x-trace-")
        }
        result, status = await vm.steer(body, trace_context or None)
        return JSONResponse(content=result, status_code=status)

    @app.get(routes.AGENT_JOBS_PATH)
    async def agent_jobs_get():
        # GitHub calls, up to a 10s timeout each: off the event loop, like /voice/intent.
        loop = asyncio.get_running_loop()
        body, status = await loop.run_in_executor(None, routes.agent_jobs_envelope)
        return JSONResponse(content=body, status_code=status)

    @app.post(routes.AGENT_JOBS_PATH)
    async def agent_jobs_post(request: Request):
        try:
            body = await request.json()
        except ValueError:
            body = None
        loop = asyncio.get_running_loop()
        result, status = await loop.run_in_executor(None, routes.submit_agent_job, body)
        return JSONResponse(content=result, status_code=status)

    @app.get(routes.MISSION_RECEIPT_PATH)
    def mission_receipt_get(run_id: str = "", instruction_id: str = ""):
        """One dispatched cloud mission, projected into a truthful receipt.

        Sync handler on purpose, like /claims: the reads are urllib calls against GitHub and
        FastAPI runs sync handlers in its threadpool, so the event loop is never blocked.
        """
        body, status = routes.mission_receipt_envelope(
            run_id=run_id or None, instruction_id=instruction_id or None
        )
        return JSONResponse(content=body, status_code=status)

    @app.get(routes.CONCIERGE_TASKS_PATH)
    async def concierge_tasks_get():
        loop = asyncio.get_running_loop()
        body, status = await loop.run_in_executor(None, routes.concierge_tasks_envelope)
        return JSONResponse(content=body, status_code=status)

    @app.post(routes.CONCIERGE_TASKS_PATH)
    async def concierge_tasks_post(request: Request):
        try:
            body = await request.json()
        except ValueError:
            body = None
        loop = asyncio.get_running_loop()
        result, status = await loop.run_in_executor(
            None, routes.submit_concierge_task, body
        )
        return JSONResponse(content=result, status_code=status)

    @app.get(routes.KEY_SYNC_PATH)
    async def key_sync_get():
        loop = asyncio.get_running_loop()
        body, status = await loop.run_in_executor(None, routes.key_sync_envelope)
        return JSONResponse(content=body, status_code=status)

    @app.get("/voice/intents")
    async def voice_intents_catalogue():
        """The intents the voice can run, for the Face's command deck: each with its own
        description, whether it is read-only, and the arguments it declares (`args` plus an
        MCP-shaped `inputSchema`) so the deck can ask for values the intent itself describes."""
        from fleetview_backend import voice_intents as vi

        loop = asyncio.get_running_loop()
        return JSONResponse(
            content={"intents": await loop.run_in_executor(None, vi.catalogue)}
        )

    @app.post("/voice/intent")
    async def voice_intent(request: Request):
        """Utterance -> committed estate intent. 204 when it names none: the brain answers.

        `intent` + `args` is the same door for a caller that is not speaking (the Face's deck, a
        controller): the name is still resolved against the committed catalog and each argument
        must be one the intent declares, so a deck click buys nothing an utterance could not.
        """
        from fleetview_backend import voice_intents as vi

        try:
            body = await request.json()
        except ValueError:
            body = {}
        if not isinstance(body, dict):
            body = {}
        text = str(body.get("text") or "")
        intent = str(body.get("intent") or "").strip()
        raw_args = body.get("args")
        args = raw_args if isinstance(raw_args, dict) and raw_args else None
        session_id = str(body.get("session_id") or "")
        # handle() may run a subprocess for up to 120s: off the event loop, like /voice/stream.
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None, vi.handle, intent or text, session_id, args
        )
        if result is None:
            return Response(status_code=204)
        return JSONResponse(content=result)

    @app.post("/intent/execute")
    async def intent_execute(request: Request):
        """ONE committed intent, run by the laptop's governed door, for a programmatic caller.

        The pod ships the intent library but no executor and no plan ledger (idp#7579), so its
        intent path is THIS route: the laptop owns the gate, the ledger and the audit, and the
        pod never grows a second gate. The credential is intent-scoped and compared with
        hmac.compare_digest; an UNCONFIGURED token means the door is CLOSED, never open.

        400 for a request that names no committed intent, an undeclared argument or a
        non-scalar value. A governed REFUSAL is not a bad request: it is 200 with ok=false, the
        door's stderr and its exit code, so the caller sees the refusal and the refusal is in
        the laptop's durable ledger.
        """
        from fleetview_backend import voice_intents as vi

        expected = intent_token()
        presented = ""
        header = request.headers.get("authorization") or ""
        if header.lower().startswith("bearer "):
            presented = header[len("bearer ") :].strip()
        if (
            not expected
            or not presented
            or not hmac.compare_digest(expected.encode(), presented.encode())
        ):
            raise HTTPException(status_code=401, detail="bad or missing intent token")
        try:
            body = await request.json()
        except ValueError:
            body = None
        if not isinstance(body, dict):
            raise HTTPException(status_code=400, detail="body must be a JSON object")
        intent = str(body.get("intent") or "").strip()
        if not intent:
            raise HTTPException(status_code=400, detail="intent name required")
        raw_args = body.get("args")
        if raw_args is None:
            args: dict = {}
        elif isinstance(raw_args, dict):
            args = raw_args
        else:
            raise HTTPException(status_code=400, detail="args must be an object")
        session_id = str(body.get("session_id") or "")
        # The door may run a subprocess for up to its own ceiling: off the event loop.
        loop = asyncio.get_running_loop()
        try:
            outcome = await loop.run_in_executor(
                None, vi.execute_programmatic, intent, args, session_id, None
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return JSONResponse(content=outcome)

    @app.get(routes.DELIVERY_PATH)
    def delivery_get():
        body, status = delivery.delivery_envelope()
        return JSONResponse(content=body, status_code=status)

    return app


def build_executor_app() -> FastAPI:
    app = FastAPI(title="FleetView executor relay", version="1.0.0")

    def _check_key(x_executor_key: str | None) -> None:
        expected = os.environ.get("FLEETVIEW_EXECUTOR_KEY")
        key_file = os.environ.get("FLEETVIEW_EXECUTOR_KEY_FILE")
        if not expected and key_file:
            try:
                expected = Path(key_file).read_text().strip() or None
            except FileNotFoundError:
                expected = None
        if expected and x_executor_key != expected:
            raise HTTPException(status_code=401, detail="bad or missing executor key")

    @app.post("/executor/poll")
    async def executor_poll(x_executor_key: str | None = Header(default=None)):
        _check_key(x_executor_key)
        return await executor_link.poll()

    @app.post("/executor/reply")
    async def executor_reply(
        request: Request, x_executor_key: str | None = Header(default=None)
    ):
        _check_key(x_executor_key)
        body = await request.json()
        request_id = body.get("request_id", "")
        result = body.get("result", {})
        accepted = await executor_link.reply(request_id, result)
        return {"accepted": accepted}

    @app.get("/healthz")
    def healthz():
        return {"ok": True, "connected": executor_link.is_connected()}

    return app


def main():
    if len(sys.argv) not in (2, 3):
        print(__doc__, file=sys.stderr)
        sys.exit(2)
    port = int(sys.argv[1])
    app = build_app()

    if len(sys.argv) == 3:
        executor_port = int(sys.argv[2])
        executor_app = build_executor_app()
        # 0.0.0.0 (RC-1b 2026-10-03): the anonymous voice door's Service
        # (overlays/oke/fleetview-voice-service.yaml) must reach this port from the edge
        # (Traefik, ns edge); reachability is governed by that Service + its port-scoped
        # NetworkPolicy, exactly like the 8091 relay below.
        main_config = uvicorn.Config(app, host="0.0.0.0", port=port, log_level="info")  # noqa: S104
        executor_config = uvicorn.Config(
            executor_app,
            host="0.0.0.0",  # noqa: S104 -- pre-existing on main; executor relay is key-checked (_check_key)
            port=executor_port,
            log_level="info",
        )
        # uvicorn.Server takes one Config; there is no `configs=` (the src-layout move, 2e364b4b,
        # wrote one, and every two-port start raised TypeError). Two servers on one loop.
        main_server = uvicorn.Server(main_config)
        executor_server = uvicorn.Server(executor_config)

        async def _serve_both():
            await asyncio.gather(main_server.serve(), executor_server.serve())

        asyncio.run(_serve_both())
        return

    uvicorn.run(app, host="127.0.0.1", port=port, log_level="info")


if __name__ == "__main__":
    main()
