# Directive for Codex Desktop: Genesis delivery bundle and xrec review (5 Nov 2026)

Source: founder request, reviewed 14:30 London. Authority: GEN-NET-006 in chidionyema/argon AGENTS.md.
Report each item as done and proven (command, output) or blocked with evidence.

## Do NOT
1. Do not run `bootstrap-argo-sync.sh` from genesis-delivery-bundle.zip as written.
   - Stage 3 executes a downloaded script after only `bash -n` and a two-pattern grep (GEN-NET-006 s9 forbids).
   - Stage 1 copies a Telegram bot token found in ~/.env* and ~/.estate/**/.env* into a new env file.
   - Stage 1 deletes ~/Documents/FOUNDER_LAUNCH_ACTIONS.md.
   - Stages 4-6 only echo "[OK]" / "[READY]"; nothing is installed or started.
2. Do not download xrec-0.3.0.zip from temp.sh. Review the local tree at ~/Downloads/xrec instead.
3. Do not copy the bundle's AGENTS.md over argon's AGENTS.md. It is a competing constitution.
4. Do not push main, force-push, or claim anything deployed without a measured result.

## Do
1. Migration script (history -> Genesis). Keep: the stage-0 sqlite `.backup` snapshots and the additive
   `CREATE TABLE IF NOT EXISTS` schema. Remove: remote execution, token harvesting, the file deletion, and
   the fake stages 4-6. Implement the missing import of action-ledger.jsonl into step_runs
   (INSERT OR IGNORE, status LEGACY_MIGRATED) and prove it: row counts before and after, run against a COPY of
   estate.db, never the live file.
2. Runbook vs bundle. The runbook lists ~13 deliverables; the zip contains 7 small stubs. List which claimed
   files do not exist. Do not describe the bundle as complete.
3. xrec. In ~/Downloads/xrec run `cargo test` and report the exact pass count. Cargo.toml says 0.2.0, README says
   30 tests, the draft message says 32; reconcile. Read src/store.rs and tests/integration.rs; confirm the
   README claims (self-report-only success refused, stale fencing token refused, tamper detected by `xrec verify`).
4. Gemini reports. Treat as design input only. The marshalling design targets OKE (retired) and an internal
   subscription-multiplexing router on :4001, which conflicts with the direct-provider rule in GEN-NET-006.
5. Hygiene. ~/Downloads/private-key.pem should be moved out of Downloads; report where it is, do not read it.

## Report format
One line per item: DONE (command + output) or BLOCKED (command + exit status + printed line).
