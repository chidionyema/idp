# Evidence bundle (machine-generated)

generated_at: 2026-10-31T03:06:00Z

Verdicts: PASS = observed matches what was stated; FAIL = the earlier statement was wrong; OBSERVED = descriptive, no prior claim; ERROR = probe failed.

| id | verdict | statement |
|---|---|---|
| C1 | PASS | router-doctor reports BROKEN; last run 2026-10-31T01:52:39 |
| C2 | PASS | runtime lane registry refused only glm/cerebras/nvidia/sambanova, all for absent credentials |
| C3 | PASS | rendered LiteLLM config: default/fast/voice have two deployments each and a fallbacks block exists |
| C4 | PASS | compiled route table has empty target lists for deepseek, deepseek-v4-flash, gemini, groq, vision |
| C5 | PASS | deepseek bridge: single repeating playwright error since 2026-09-20; last bound 8767 on 2026-10-26 |
| C6 | OBSERVED | fallback substitutions actually recorded (descriptive, no prior claim) |
| C7 | PASS | argon /api/gateway/complete has no thought/reasoning handling and returns a hardcoded 200 fake dispatch |
| C8 | PASS | estate door refuses any agent named claude; runtimes.json quarantines claude-code |
| C9 | PASS | estate-cluster.yaml holds a plaintext service-account token whose exp is in the past |
| C10 | PASS | fallback chains for default/fast point at gemini and groq, which have empty route-table target lists |
| C11 | OBSERVED | substitution (fallback) events recorded by the router, counted (descriptive, no prior claim) |

## C1 - PASS

router-doctor reports BROKEN; last run 2026-10-31T01:52:39

command: `parse router-doctor.out.log + router-doctor.last`

expected:
```
{
 "last_verdict": "BROKEN",
 "last_run": "2026-10-31T01:52:39"
}
```
observed:
```
{
 "runs": 712,
 "first_run": "2026-09-28T16:36:49",
 "last_run": "2026-10-31T01:52:39",
 "verdict_counts": {
  "HEALED+OK": 25,
  "BROKEN": 687
 },
 "last_verdict": "BROKEN",
 "fail_checks": {
  "launchd": 113,
  "settings": 22,
  "liveliness": 53,
  "e2e": 32,
  "oauth-patch": 206,
  "lanes": 119
 },
 "router_doctor_last": [
  "2026-10-31T01:52:39",
  "doctor  mode=watch         http://127.0.0.1:4000",
  "ok      launchd            running: com.estate.litellm-front, com.estate.litellm-local-4001 (0.0s)",
  "ok      liveliness         HTTP 200  (0.1s)",
  "ok      oauth-patch        Max OAuth forwarding patch staged (0.0s)",
  "FAIL    lanes              missing: []; dropped (key absent at render): ['\"claude-*\"', 'cerebras', 'deepseek', 'deepseek-v4-flash', 'gemini', 'glm', 'minimax', 'minimax_json', 'minimax_m27', 'minimax_m31f', 'narrate', 'nvidia', 'openrouter', 'sambanova', 'vision', 'voice', 'voice-tts-minimax']",
  "FIX:    lanes              claude-* lane or efficiency gateway missing from the rendered config -- bin/idp-vendor-render in a clean worktree of main, then rerun",
  "doctor  BROKEN             141.4s"
 ]
}
```
sources:
- `/mnt/user-data/uploads/.estate/router-doctor.last` sha256=c8b8bddaef5cf0f8fbd14de5cb5b9c6ed22dade1a4b863274d8d2fba53b97049 bytes=770
- `/mnt/user-data/uploads/.estate/router-doctor.out.log` sha256=67298020a4b1a25ed71369b26ac966effc532a7bf2f5fd342aa1d63b96aea50d bytes=375304

## C2 - PASS

runtime lane registry refused only glm/cerebras/nvidia/sambanova, all for absent credentials

command: `parse router-state/lanes.json`

expected:
```
{
 "refused_lanes": [
  "cerebras",
  "glm",
  "nvidia",
  "sambanova"
 ],
 "all_reasons_credential_absent": true
}
```
observed:
```
{
 "at": "2026-10-31T01:51:25Z",
 "served": 25,
 "declared": 22,
 "refused": [
  [
   "glm",
   "credential ZAI_API_KEY absent"
  ],
  [
   "cerebras",
   "credential CEREBRAS_API_KEY absent"
  ],
  [
   "cerebras",
   "credential CEREBRAS_API_KEY_2 absent"
  ],
  [
   "cerebras",
   "credential CEREBRAS_API_KEY_3 absent"
  ],
  [
   "nvidia",
   "credential NVIDIA_API_KEY absent"
  ],
  [
   "sambanova",
   "credential SAMBANOVA_API_KEY absent"
  ],
  [
   "sambanova",
   "credential SAMBANOVA_API_KEY_2 absent"
  ],
  [
   "sambanova",
   "credential SAMBANOVA_API_KEY_3 absent"
  ]
 ],
 "served_includes": [
  "claude-*",
  "deepseek",
  "gemini",
  "groq",
  "minimax"
 ]
}
```
sources:
- `/mnt/user-data/uploads/.estate/router-state/lanes.json` sha256=04d34c9539c421eea0398033ccf1d7f7393dc06c2c9e67ec2fc3faed1db3e648 bytes=2759

## C3 - PASS

rendered LiteLLM config: default/fast/voice have two deployments each and a fallbacks block exists

command: `parse router-state/config.runtime.yaml`

expected:
```
{
 "default": [
  "openai/MiniMax-M3",
  "openai/openai/gpt-oss-120b"
 ],
 "fast": [
  "openai/MiniMax-M3",
  "openai/openai/gpt-oss-120b"
 ],
 "voice": [
  "openai/MiniMax-M3",
  "deepseek/deepseek-chat"
 ],
 "has_fallbacks_key": true
}
```
observed:
```
{
 "model_name_entries": 29,
 "default": [
  "openai/MiniMax-M3",
  "openai/openai/gpt-oss-120b"
 ],
 "fast": [
  "openai/MiniMax-M3",
  "openai/openai/gpt-oss-120b"
 ],
 "voice": [
  "openai/MiniMax-M3",
  "deepseek/deepseek-chat"
 ],
 "has_fallbacks_key": true,
 "router_settings": [
  "router_settings:",
  "  fallbacks:",
  "  - deepseek:",
  "    - gemini",
  "    - minimax",
  "    - groq",
  "  - deepseek-v4-flash:",
  "    - minimax",
  "    - gemini",
  "    - groq",
  "  - minimax:",
  "    - minimax_m31f",
  "    - gemini",
  "    - groq",
  "  - minimax_m31f:",
  "    - minimax",
  "    - gemini",
  "    - groq",
  "  - minimax_json:",
  "    - minimax",
  "    - gemini",
  "    - groq",
  "  - minimax_m27:",
  "    - minimax",
  "    - gemini",
  "    - groq",
  "  - gemini:",
  "    - minimax",
  "    - groq",
  "  - default:",
  "    - gemini",
  "    - groq",
  "  - fast:",
  "    - gemini",
  "    - groq",
  "  - groq:",
  "    - openrouter",
  "  - voice:",
  "    - narrate",
  "    - fast",
  "    - groq",
  "  - narrate:",
  "    - groq",
  "  model_group_alias:",
  "    kimi: moonshot/kimi-k3",
  "  num_retries: 2",
  "  allowed_fails: 3",
  "  cooldown_time: 60",
  "  routing_strategy: cost-based-routing"
 ]
}
```
sources:
- `/mnt/user-data/uploads/.estate/router-state/config.runtime.yaml` sha256=837fe84a50c73dbf2c6214e82ee2719ef5c8b41f99a1ba84026799d528e15d5c bytes=7910

## C4 - PASS

compiled route table has empty target lists for deepseek, deepseek-v4-flash, gemini, groq, vision

command: `parse router/table.json`

expected:
```
{
 "empty_lanes": [
  "deepseek",
  "deepseek-v4-flash",
  "gemini",
  "groq",
  "vision"
 ]
}
```
observed:
```
{
 "empty_lanes": [
  "deepseek",
  "deepseek-v4-flash",
  "gemini",
  "groq",
  "vision"
 ],
 "compiled_at": "2026-10-31 01:53:42 UTC",
 "default_fast_voice": {
  "default": [
   "openai/MiniMax-M3"
  ],
  "fast": [
   "openai/MiniMax-M3"
  ],
  "voice": [
   "openai/MiniMax-M3"
  ]
 }
}
```
sources:
- `/mnt/user-data/uploads/.estate/router/table.json` sha256=526cb10babca3198814589b86e4ab95c1ac9e294ca38d629d59eb587d2a4ba7d bytes=1253

## C5 - PASS

deepseek bridge: single repeating playwright error since 2026-09-20; last bound 8767 on 2026-10-26

command: `parse .deepseek-bridge/logs/bridge.jsonl (rows before 2025 excluded)`

expected:
```
{
 "distinct_error_count": 1,
 "error_mentions": "playwright",
 "first_boot_failed": "2026-09-20 13:20:19 UTC",
 "last_listening": "2026-10-26 16:54:02 UTC",
 "listening_port": 8767
}
```
observed:
```
{
 "rows": 35115,
 "rows_with_pre_2026_timestamps": 15,
 "boot_failed": 35090,
 "distinct_errors": {
  "start failed: ModuleNotFoundError: No module named 'playwright'": 35090
 },
 "first_boot_failed": "2026-09-20 13:20:19 UTC",
 "last_boot_failed": "2026-10-31 02:55:02 UTC",
 "last_listening": "2026-10-26 16:54:02 UTC",
 "listening_port": 8767,
 "last_handler_error": "2026-10-27 00:27:30 UTC"
}
```
sources:
- `/mnt/user-data/uploads/.deepseek-bridge/logs/bridge.jsonl` sha256=fb1a6e5fb3bfce536d63c2a0c22a29c7ae19de16f75d653894dfc0f869c7472f bytes=4314885

## C6 - OBSERVED

fallback substitutions actually recorded (descriptive, no prior claim)

command: `parse router/substitutions.jsonl`

expected:
```
null
```
observed:
```
{
 "lines": 8489,
 "recent_records_parsed": 2000,
 "key_frequency": {
  "capability_tier": 2000,
  "policy_version": 2000,
  "requested": 2000,
  "served_by": 2000,
  "t": 2000,
  "why": 2000
 },
 "last_record_ts": null,
 "last_3": [
  "{\"capability_tier\": \"cheap\", \"policy_version\": \"c5d4e1f150089831\", \"requested\": \"groq\", \"served_by\": \"openrouter\", \"t\": 1793411622.112, \"why\": \"dead group\"}",
  "{\"capability_tier\": null, \"policy_version\": null, \"requested\": \"deepseek-v4-flash\", \"served_by\": \"default\", \"t\": 1793412395.213, \"why\": \"dead group\"}",
  "{\"capability_tier\": null, \"policy_version\": null, \"requested\": \"deepseek-v4-flash\", \"served_by\": \"default\", \"t\": 1793412548.381, \"why\": \"dead group\"}"
 ]
}
```
sources:
- `/mnt/user-data/uploads/.estate/router/substitutions.jsonl` sha256=244786849984557ed7a1bef5c05e3db8540ad588b477aa9d738653f6bed520cf bytes=1014021

## C7 - PASS

argon /api/gateway/complete has no thought/reasoning handling and returns a hardcoded 200 fake dispatch

command: `regex over server.ts handler region`

expected:
```
{
 "thought_handling": [],
 "fake_dispatch_string_min": 1,
 "http_200_hardcoded_min": 1
}
```
observed:
```
{
 "argon_commit": "2b237c0fcfb43481b719eec242ad5b9cbb427c64",
 "handler_lines": [
  813,
  929
 ],
 "thought_handling": [],
 "text_extraction": [
  [
   860,
   "output_text) {"
  ],
  [
   861,
   "output_text;"
  ],
  [
   864,
   "model_output' && Array.isArray(step.content)) {"
  ]
 ],
 "hardcoded_reasoning_model": [
  [
   847,
   "gemini-4-argon' : resolution.selectedModel.modelId;"
  ]
 ],
 "fake_dispatch_string": [
  [
   889,
   "Verified Capability Dispatch \u00b7 capability=${requestedCap} \u00b7 resolved_model=${resolvedModel} \u00b7 bucket=${resolution.selectedBucket.providerName}]\\nPre-d"
  ]
 ],
 "http_200_hardcoded": [
  [
   905,
   "httpStatus: 200,"
  ]
 ]
}
```
sources:
- `/home/claude/argon/server.ts` sha256=25f511aba001bba31438c8afea7ea0822336a42900a7daa0785d75eb481fd611 bytes=34847

## C8 - PASS

estate door refuses any agent named claude; runtimes.json quarantines claude-code

command: `parse runtimes.json + plan.py`

expected:
```
{
 "claude_code_status": "QUARANTINED_TERMINATED_2026_10_30",
 "door_refuses_claude": true
}
```
observed:
```
{
 "claude_code_status": "QUARANTINED_TERMINATED_2026_10_30",
 "plan_py_lines": [
  [
   13,
   "if \"claude\" in agent_id.lower():"
  ],
  [
   16,
   "\"reason\": \"Agent claude is quarantined in runtimes.json (#7636); route work to pi or z-ai.\","
  ]
 ]
}
```
sources:
- `/home/claude/argon/platform/estate/memory/plan.py` sha256=61213a380656268970ab21f65a43453625f3f6921be9eefde7e4736464833331 bytes=1305
- `/home/claude/argon/platform/estate/memory/runtimes.json` sha256=4dbbbc1ad14d49ee7ec3e48b4cf7bda4bab24999b5264790b935c8d4fcadb74e bytes=1317

## C9 - PASS

estate-cluster.yaml holds a plaintext service-account token whose exp is in the past

command: `decode JWT payload (token not printed)`

expected:
```
{
 "expired": true
}
```
observed:
```
{
 "server": "http://100.98.58.115:8001",
 "aud": [
  "api"
 ],
 "iat": "2026-10-08 08:23:10 UTC",
 "exp": "2026-10-08 09:23:10 UTC",
 "now": "2026-10-31T03:06:00Z",
 "expired": true,
 "note": "token value not printed; plaintext token present in file"
}
```
sources:
- `/mnt/user-data/uploads/.estate/estate-cluster.yaml` sha256=0e182c26d2902206dac765f339d7bf625f1b58fa8b5acd9a8c362fe0f112d233 bytes=1216

## C10 - PASS

fallback chains for default/fast point at gemini and groq, which have empty route-table target lists

command: `parse router_settings.fallbacks in config.runtime.yaml, join with router/table.json`

expected:
```
{
 "default": [
  "gemini",
  "groq"
 ],
 "fast": [
  "gemini",
  "groq"
 ]
}
```
observed:
```
{
 "chains": {
  "default": [
   "gemini",
   "groq"
  ],
  "fast": [
   "gemini",
   "groq"
  ],
  "voice": [
   "narrate",
   "fast",
   "groq"
  ],
  "deepseek-v4-flash": [
   "minimax",
   "gemini",
   "groq"
  ],
  "groq": [
   "openrouter"
  ]
 },
 "fallback_targets_with_empty_route_table": {
  "deepseek": [
   "gemini",
   "groq"
  ],
  "deepseek-v4-flash": [
   "gemini",
   "groq"
  ],
  "minimax": [
   "gemini",
   "groq"
  ],
  "minimax_m31f": [
   "gemini",
   "groq"
  ],
  "minimax_json": [
   "gemini",
   "groq"
  ],
  "minimax_m27": [
   "gemini",
   "groq"
  ],
  "gemini": [
   "groq"
  ],
  "default": [
   "gemini",
   "groq"
  ],
  "fast": [
   "gemini",
   "groq"
  ],
  "voice": [
   "groq"
  ],
  "narrate": [
   "groq"
  ]
 }
}
```
sources:

## C11 - OBSERVED

substitution (fallback) events recorded by the router, counted (descriptive, no prior claim)

command: `count router/substitutions.jsonl by (requested, served_by, why)`

expected:
```
null
```
observed:
```
{
 "records": 8489,
 "first": "2026-10-02 12:13:49 UTC",
 "last": "2026-10-31 02:09:08 UTC",
 "last_24h": 1064,
 "top_pairs_all": [
  [
   [
    "deepseek",
    "minimax",
    "dead group"
   ],
   2334
  ],
  [
   [
    "groq",
    "default",
    "dead group"
   ],
   2057
  ],
  [
   [
    "deepseek-v4-flash",
    "default",
    "dead group"
   ],
   1553
  ],
  [
   [
    "deepseek",
    "default",
    "dead group"
   ],
   1299
  ],
  [
   [
    "glm",
    "default",
    "dead group"
   ],
   435
  ],
  [
   [
    "voice-tts",
    "default",
    "dead group"
   ],
   253
  ],
  [
   [
    "groq",
    "nvidia",
    "dead group"
   ],
   164
  ],
  [
   [
    "voice",
    "default",
    "dead group"
   ],
   163
  ],
  [
   [
    "groq",
    "openrouter",
    "dead group"
   ],
   116
  ],
  [
   [
    "gemini",
    "default",
    "dead group"
   ],
   46
  ]
 ],
 "top_pairs_last_24h": [
  [
   [
    "deepseek-v4-flash",
    "default",
    "dead group"
   ],
   1022
  ],
  [
   [
    "groq",
    "openrouter",
    "dead group"
   ],
   38
  ],
  [
   [
    "deepseek",
    "minimax",
    "dead group"
   ],
   4
  ]
 ]
}
```
sources:
