# Estate Special Forces — Full Operationalisation Specification v1

**Date:** 2026-10-28  
**Target repository:** `chidionyema/idp`  
**Status:** IMPLEMENTATION-READY SPECIFICATION; NOT DEPLOYED OR CERTIFIED  
**Mission:** Progressively commercialise verified estate capabilities without creating a parallel platform or disrupting the existing transformation.

## 1. Mandate and strategic objective

Establish Special Forces (SF) as a **persistent, bounded, cross-functional autonomous intervention capability**, not a new organisation chart or multi-agent chat room. Its outcome is the first successful paid external invocation of an estate capability, followed by repeatable delivery, positive unit economics, and expansion to a second capability. SF should demonstrate the estate's reusable autonomous-department operating contract rather than inventing its own workflow engine.

**North-star event:** an external customer, authenticated under a tenant identity, invokes a documented estate capability; the system produces a verifiably correct deliverable; the customer accepts the result; payment settles; the event is linked to cost, policy, evidence and support records. No synthetic transaction counts as market validation.

**Explicit non-goals:** new agent framework, new scheduler, new message bus, new context store, direct public access to internal estate control planes, unsupervised production mutation, broad commercial portal before a verified demand signal, speculative billing infrastructure before a paid use case.

## 2. Source authority and existing estate alignment

- `AGENTS.md`: programme authority, seven reasoning gates, one-of-each-layer, claim/lane governance, intent-only execution, proof over assertion, named decider.
- `docs/epics/2026-10-25-estate-master-epic.md`: autonomy, coherent closed loops, proactive/event-driven work, metric-led improvement, founder go/no-go at strategic boundaries.
- `platform/estate/context/server.py`: existing MCP policy gateway pattern; it is **not** evidence of commercial multi-tenant readiness.
- Existing estate capabilities to inspect and reuse: GitHub issue/CLAIM/lane-submit, `estate-execute`, agentgateway, NATS JetStream, Temporal, Dagster, unified memory, context broker, catalog/capability-index, verification/evidence, router/budgets, Fleet/Face.
- `platform/research-engine/objective-adapter.py`: prior failure pattern of wrong-lane zero-claim research and passive Continue/Park; SF must deliver experiments, not report-only output.
- The Media department charter offers a compatible department envelope, but is proposed, not a running dependency.

**Authority levels:** founder-approved strategic mandate > policy/identity/execution decisions > verified tool observations > source-linked research > model hypotheses. Lower-trust text never grants execution authority.

## 3. Operational topology

```text
Founder strategy / external market / estate capability signals
                         |
              Opportunity intake adapter
                         |
       Deduplication + portfolio scoring + budget gate
                         |
             Durable mission controller
                         |
  Recon -> Hypothesis -> Prototype -> Independent evaluation
                         |
             Decision: kill / park / propose
                         |
          Existing claim + governed execution
                         |
        External sandbox -> pilot -> paid outcome
                         |
        Measured learning -> portfolio reprioritisation
                         |
                Fleet/Face visibility
```

**Six functions, dynamically assigned:** (1) mission commander/portfolio optimizer, (2) market reconnaissance, (3) estate capability pathfinder, (4) prototype/engineering operator, (5) independent verifier and security reviewer, (6) commercial validation and economics analyst. These are responsibilities, not six permanently running agents. A role can be staffed by deterministic code, existing estate agents or a specialist model. The verifier must be independently instantiated and cannot approve its own changes.

**Single accountable mission controller:** runs on existing durable workflow infrastructure selected after baseline. Scheduling uses the existing estate scheduler; events use the existing event bus; agent calls use existing router; state and evidence use existing stores. If a required adapter does not exist, add only an adapter, not a new infrastructure tier.

## 4. Mission contract (versioned schema)

Every mission carries:

```json
{
  "schema_version": "1.0",
  "mission_id": "uuid",
  "objective_id": "source-qualified-id",
  "department_id": "special-forces",
  "mission_kind": "recon|prototype|integration|pilot|commercial_validation|hardening",
  "problem_statement": "string",
  "customer_segment": "string|null",
  "hypothesis": "falsifiable statement",
  "success_metrics": [{"name":"string","baseline":null,"target":null,"unit":"string","evidence_source":"string"}],
  "authority_ref": "policy or founder mandate ref",
  "risk_tier": "R0|R1|R2|R3",
  "scope": {"repositories":[],"capabilities":[],"tenants":[],"environments":[]},
  "budget": {"max_usd":0,"max_wall_minutes":0,"max_agent_calls":0,"max_concurrent_tasks":0},
  "idempotency_key": "stable-key",
  "source_revision": "immutable revision",
  "dependencies": [],
  "artifacts": [],
  "evidence_refs": [],
  "state": "DISCOVERED",
  "decider": "identity",
  "created_at": "RFC3339 timestamp",
  "expires_at": "RFC3339 timestamp"
}
```

The example is an illustrative contract, not a validated final JSON Schema. Build strict JSON Schema definitions and migration tests in the first implementation slice. Every artifact has digest, creator, source, timestamp, authority and retention class. No fabricated provenance or self-declared `CERTIFIED` field.

### Mission lifecycle

`DISCOVERED -> TRIAGED -> HYPOTHESIS -> RESEARCHING -> EXPERIMENT_APPROVED -> PROTOTYPING -> EVALUATING -> PROPOSED -> GOVERNED_DELIVERY -> VERIFYING -> PILOT -> COMMERCIAL_VALIDATION -> OPERATING -> LEARNING -> CLOSED`

Any nonterminal state may transition to `BLOCKED`, `PARKED`, `CANCELLED` or `FAILED` through a recorded policy decision. `EVALUATING -> PROPOSED` requires independent evidence; `PROPOSED -> GOVERNED_DELIVERY` requires the estate's existing authorization path; `VERIFYING -> PILOT` requires tenant isolation and security gates; `PILOT -> COMMERCIAL_VALIDATION` requires explicit customer consent and contractual controls. No direct `RESEARCHING -> SHIPPING` shortcut. Resume only from checkpointed state; replay must not duplicate effects.

## 5. Autonomous opportunity discovery

**Sources:** founder objectives; existing estate capability index and catalog; observed internal pain (repeat incidents, manual founder intervention, expensive agent calls); customer requests; market research; external agent ecosystem interfaces; measurable gaps in documentation, API accessibility, identity, isolation, billing and verification.

**Discovery rules:** source-linked and timestamped; do not mistake speculative market commentary for customer demand; deduplicate by capability/problem/segment; expire stale opportunities; maintain negative findings; cap external searches and model spend; do not autonomously scrape private data or contact customers without authorization.

**Prioritization:** deterministic weighted score with configurable weights: validated customer pain (30%), reuse of existing estate capability (20%), time to independently verified pilot (20%), expected contribution margin (15%), strategic learning value (10%), integration risk (5% inverse). Score each dimension 0–5 with source-linked justification; missing customer evidence scores zero rather than invented confidence. The weights are starting hypotheses, not proven optimal. Use portfolio diversity and capacity constraints to prevent a single speculative mission monopolizing work.

**Selection:** one active build mission initially, up to two read-only reconnaissance missions; WIP limits enforced. Reprioritize on new evidence, objective expiry, critical incidents or explicit founder redirection. Suspend nonessential work during estate incident or CI degradation according to existing policies.

## 6. Delegated authority and risk

| Tier | Examples | Default action |
|---|---|---|
| R0 | Public-source research, read-only estate inventory, analysis | Autonomous within budget |
| R1 | Isolated sandbox prototypes, test fixtures, local documentation changes | Autonomous with bounded runtime and security constraints |
| R2 | PR creation, staging integration, customer sandbox provisioning | Existing claim, CI, review and policy gates; approval per existing estate rules |
| R3 | Production writes, external publishing, customer commitments, charging cards, secrets, legal terms | Explicit authorized approval; fail closed |

No role can mint its own authority. Customer-provided repositories, prompts and webhook payloads are untrusted. Secrets never appear in research artifacts. Isolation and resource quotas must be enforced by infrastructure, not by prompt instructions. The founder can pause the whole team; the estate incident controller can preempt its workloads.

## 7. Commercial exposure options and product sequencing

**Wedge A (preferred first hypothesis): Verified Engineering Task API.** Customer connects a scoped test repository, submits an issue and receives a tested PR with evidence, limitations and cost. **Do not assume this is profitable or wanted**; test willingness to pay before building full billing. First run in isolated sandbox, never on an unbounded customer production repository.

**Wedge B:** Bring-Your-Own-Agent via governed MCP capabilities (context, diagnostics, verification, delivery). Test after Wedge A proves isolation, metering and authorization.

**Wedge C:** Autonomous Department as a Service, only after the reusable department runtime passes independent operation and cost gates.

**Commercial gateway requirement:** tenant-bound identity, per-tenant entitlements, authorization at every state-changing tool call, scoped repository credentials, isolated execution and memory, usage/cost attribution, audit/evidence delivery, idempotent metering, quota enforcement, revocation, data deletion/retention policy, support/incident boundaries, rate limits, versioned API/MCP contracts. Use existing gateway where appropriate; add tenant mediation without bypassing it. Cross-tenant leak is a stop-ship defect.

**Pricing experiments:** fixed-price accepted outcome vs reserved engineering capacity vs usage with minimum; compare gross margin and dispute rates. Model full cost = model + compute + retries + verification + human oversight + support + payment processing + refunds. Count unsuccessful attempts against internal cost; charge only according to explicit customer terms.

## 8. Reusable department spine

SF must use the same generic department envelope as Media/Research/Science: `Objective -> Hypothesis -> Experiment -> Artifact -> Independent Evaluation -> Governed Action -> Outcome -> Learning`. Department-specific capability packs supply prompts, deterministic tools, evaluators, policies and portfolio scoring. Shared core owns identity, workflow state, budgets, evidence, event schema and Fleet visualization. **No copied scheduler, approval engine, memory or ledger.**

The first implementation must expose a department instance descriptor (`department_id`, mission templates, allowed capabilities, triggers, evaluation packs, budgets, escalation matrix, visualizations, kill switch). Demonstrate portability with a second shadow-mode department without deploying a duplicate runtime.

## 9. Operational work packages (small independently mergeable PRs)

### SF-0: Evidence-based baseline and overlap audit
- Pin repository SHA and gather current issues/PRs, deployed gateway/workflows, capability index, estate execution and policy paths, prior research/science failure evidence, active CI health and budget/observability state.
- Enumerate commercial-capability gaps and current callers. Classify `SOURCE_ONLY`, `TESTED`, `DEPLOYED`, `OBSERVED`, `UNKNOWN`, `BROKEN`.
- Deliver machine-readable inventory, architecture map, nonduplication analysis and initial benchmark.
- **Exit:** no ungrounded deployment claim; 100% proposed dependencies linked to real source or explicit unknown.

### SF-1: Mission schema, state machine and BDD
- Strict schemas for mission, evidence, experiment, proposal, authorization, outcome and learning.
- Deterministic transition guard, idempotency key, expiry, budget and policy validation.
- **Exit:** tests reject missing provenance, forged approval, illegal transition, duplicate effect, stale source, overspend, cross-tenant scope and self-certification.

### SF-2: Durable autonomous controller
- Existing scheduler + Temporal/Dagster adapter, event triggers, bounded retry, timeout, cancellation, backpressure, recovery and dead-letter behavior.
- Persist objective state and checkpointed tool effects with correlation IDs; emit trace/event references.
- **Exit:** kill/restart/replay drills; no duplicate PR, billing event or external call under retries; no unbounded run.

### SF-3: Reconnaissance and hypothesis laboratory
- Capability/market scan, scored opportunity queue, competitor and user problem evidence, explicit alternatives including do-nothing.
- Produce falsifiable experiment plan with budget, success threshold and failure threshold; sandbox prototype required before proposal acceptance.
- **Exit:** one real, independently reproduced prototype with code and scorecard; no report-only completion.

### SF-4: Governed commercial boundary
- Minimum external tenant sandbox, scoped identity, authorization, repository isolation, versioned REST or MCP surface, metering and evidence return.
- Do not expose internal gateway/engine directly; support revocation and abuse controls.
- **Exit:** negative isolation/security suite passes, including prompt injection and cross-tenant tests; authenticated external sandbox invocation demonstrably works.

### SF-5: Verified Engineering Task vertical slice
- Accept one bounded GitHub issue, compile context, produce PR in customer-controlled test repo, run independent CI, return artifact/trace and chargeable-unit accounting.
- Handle non-success states and disputed results; prohibit success on green agent narration alone.
- **Exit:** 10 fixture tasks including adversarial/failed tasks; all results accurately reported; at least one real end-to-end external sandbox demo.

### SF-6: Customer and economics validation
- Customer discovery, explicit pilot consent, offer/pricing experiments, full cost attribution and customer outcome review.
- Payment and legal commitments through approved doors; no invented revenue.
- **Exit:** evidence-backed customer willingness-to-pay decision, measured cost per accepted result, and real paid transaction for the north-star milestone.

### SF-7: Fleet/Face command and observability
- Reuse estate visualization infrastructure to display mission board, opportunity funnel, live agents, authority tier, cost, hypothesis, artifact, CI/verification, blockers, customer outcome and learning.
- Founder can pause, redirect or approve through existing control surfaces; commands are audited and bound to real execution IDs.
- **Exit:** every visible status traceable to source event and verification artifact; failed or stale runs never appear as successful.

### SF-8: Reuse and scale decision
- Deploy a second department configuration in shadow mode, measure time-to-onboard, duplication and operational overhead; demonstrate rollback and cost ceilings.
- Expand to second product only if first shows repeatable demand and credible margin.
- **Exit:** reusable operating contract with no duplicate platform layer and independent evaluation evidence.

## 10. BDD acceptance scenarios

```gherkin
Feature: Autonomous Special Forces governed commercialisation

  Scenario: Autonomously discover and validate an opportunity
    Given an approved commercialisation mandate with a bounded budget
    And a source-linked estate capability gap
    When the discovery schedule runs
    Then one deduplicated opportunity is recorded
    And a falsifiable hypothesis and baseline are created
    And an isolated prototype is executed
    And an independent evaluator returns a reproducible verdict
    And the founder sees the artifact and next recommended action

  Scenario: A malicious customer attempts to escape tenant scope
    Given a customer token scoped to tenant A and test repository A
    When the customer requests tenant B memory or execution
    Then the authoritative gateway refuses the request
    And no cross-tenant data is returned
    And the refusal is linked to a security event

  Scenario: A workflow crashes after creating a pull request
    Given a mission with an idempotency key
    And a PR was created before the worker crashed
    When the workflow resumes from its checkpoint
    Then the existing PR is reused
    And no second PR or billable effect is created

  Scenario: A model declares a task complete without independent verification
    Given a prototype artifact without a passing independent evaluation
    When the mission requests a success transition
    Then the transition is rejected
    And the mission remains blocked or evaluating

  Scenario: The estate enters a critical incident
    Given a Special Forces mission is running
    When the estate incident policy preempts discretionary workloads
    Then Special Forces cancels or suspends bounded tasks
    And records checkpoints and spend
    And resumes only when policy allows

  Scenario: First commercial transaction
    Given a consented external customer and approved commercial terms
    When a scoped capability invocation completes
    Then acceptance is linked to independently verified output
    And payment settlement is verified from the payment provider
    And gross margin is computed from attributed actual costs
    And the milestone is recorded as achieved only when all evidence exists
```

## 11. Evaluation, SLOs and certification

**Safety invariants (zero tolerance):** no unauthorized production action; no cross-tenant data leakage; no fabricated customer/revenue/CI/deployment status; no unbounded spend; no duplicate externally visible side effects on retry; no self-awarded certification.

**Provisional operational targets (must be calibrated in SF-0):** 100% missions with traceable authority and artifacts; 100% mission states reconstructable from event history; 100% PR outcomes backed by CI run references; >=95% accepted proposals include a reproducible executable prototype (target 100%); <=1 active build mission at launch; 0 over-budget completions; 0 unapproved R3 actions; time-to-first evaluated prototype <=48 hours for scoped feasible objectives; monthly cost-per-success and founder-intervention trend reported. Deterministic controller replay should be exactly equivalent for identical input sequences.

**Evidence packet:** source revision; objective/claim refs; workflow execution IDs; tool and policy decision logs; schema validation; test commands/results; independent evaluator identity; signed/digested prototype; staging/live smoke results; tenant isolation tests; actual spend; rollback drill; customer acceptance; payment settlement where applicable. Each gate is `PASS`, `FAIL` or `UNKNOWN`; `UNKNOWN` never certifies.

**Stop/rollback triggers:** tenant escape, unauthorized external action, unexpected spend, duplicate charge/PR, stale state shown as success, >2 consecutive failed unattended cycles without recovery, material incident impact, or objective expiry. Stop cancels queued work and revokes ephemeral access; rollback uses existing GitOps/feature flag route; preserve immutable incident evidence.

## 12. Telemetry and Fleet representation

Every run emits: `mission.created`, `mission.ranked`, `hypothesis.registered`, `experiment.started`, `artifact.produced`, `evaluation.completed`, `approval.requested`, `change.submitted`, `verification.completed`, `pilot.started`, `customer.accepted`, `payment.settled`, `mission.failed`, `mission.closed`. Event envelope: schema version, mission ID, objective ID, tenant ID if any, causation/correlation ID, source revision, timestamp, actor/decider, authority, budget/spend, evidence references. Reuse the event bus and existing trace collector; avoid publishing secrets or customer code into globally readable events.

Fleet views: **mission board**, **commercial opportunity funnel**, **capability graph**, **cost and reliability**, **customer validation**, **independent evidence**, **intervention/kill controls**. Display measured vs inferred state visibly. An animated agent is not proof of a real action; link to trace and artifact.

## 13. First 14 days: thin-slice launch plan

- **Days 1–2:** create governing issue/claim; pin SHA; inspect overlapping programmes; measure current estate gateway, agent work execution, CI, budget, catalog and deployment reality. Record unknowns.
- **Days 3–4:** merge SF-1 mission schemas, transition engine and negative BDD tests behind a disabled feature flag.
- **Days 5–7:** integrate one existing durable workflow, bounded opportunity scanner and Fleet read-only mission status. Complete restart/kill drills.
- **Days 8–10:** autonomously research one candidate capability and produce a runnable sandbox prototype plus independent scorecard.
- **Days 11–14:** demonstrate one governed external sandbox invocation of the prototype, tenant-bound evidence and measured unit costs; decide whether to proceed to customer pilot.

These are **targets, not delivery promises**. Progress only on passing evidence gates; do not force timeline by skipping isolation, governance or independent verification.

## 14. Governance and immediate engineering handoff

Create one P0 programme issue in `chidionyema/idp`, then child missions as claimable, small, independently verifiable issues. Respect `AGENTS.md`: no direct main push; claim and heartbeat; `lane/<name>`; `estate-execute lane-submit`; existing policy and approvals. Start with SF-0 and SF-1, not a commercial portal. The programme can be paused or dismantled without affecting core estate execution.

**Current blocker observed in this conversation:** the GitHub integration returned HTTP 403 `Resource not accessible by integration` when attempting to create an issue. No issue, branch, PR, deployment or live test is asserted. The connected app requires issue-write authorization or an existing authorized estate execution path must create the issue.

## 15. Definition of done

Special Forces is operational when a bounded unattended mission has progressed from independently sourced opportunity through runnable prototype and independent evaluation to a governed PR or safe external sandbox invocation, with complete trace, cost, negative security tests, Fleet visibility, recovery and rollback evidence. Special Forces is **commercially validated** only when a real customer receives accepted verified output and an actual paid transaction settles with attributed costs. Special Forces is **reusable as an autonomous department pattern** only when a second department runs the same contract without duplicating shared infrastructure.
