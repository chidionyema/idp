cd /Users/roseonyema/Documents/code/idp

# Find breaker, gateway, or proxy modules
find . -name "*breaker*" -o -name "*gateway*" -o -name "*proxy*"