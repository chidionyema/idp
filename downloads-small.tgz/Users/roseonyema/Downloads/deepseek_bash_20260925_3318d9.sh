cat ~/.estate-idp/llm/config.base.yaml
sed -n '570,602p' ~/.estate-idp/llm/config.yaml