# Failure-mode matrix — Tempo v2.0 (Rust)

Every software-verifiable failure mode has a named test ("Verified by" is
greppable). Hardware paths are explicitly marked as spike items — the rest of
this file is enforced by `cargo test --workspace` (111 tests).

| ID | Failure | Detection | Response | Verified by |
|----|---------|-----------|----------|-------------|
| F-LOG-1 | Ledger record tampered after commit | Recomputed hash ≠ stored hash on load/verify | Refuse boot; refuse further writes | `log::tampered_payload_rejected_on_load_f_log_1`; `log::full_rewrite_with_recomputed_hashes_rejected_by_checkpoint_sig_f_log_1`; `integration::tampered_log_refuses_boot_f_log_1` |
| F-LOG-2 | Record deleted from storage | Sequence gap on load | Refuse boot | `log::deleted_record_rejected_f_log_2` |
| F-LOG-3 | Record inserted / reordered | Chain-link (`prev_hash`) mismatch | Refuse boot | `log::reordered_records_rejected_f_log_3`; `log::inserted_record_rejected_f_log_3` |
| F-LOG-4 | Torn write / disk full | Trailing line without newline; ENOSPC on append | Torn tail truncated + counted, chain continues; storage failure rolls back the partial line and **refuses further writes** (fail-closed) | `log::torn_tail_recovered_and_chain_continues_f_log_4`; `log::disk_full_refuses_and_stays_refused_f_log_4`; `integration::torn_tail_boots_and_recovers_f_log_4` |
| F-TIME-1 | Wall clock steps backwards (NTP, VM resume, attack) | Wall vs monotonic projection beyond `max_backstep_ms` | Hold on monotonic timeline, `time_confidence=degraded`, recover after sustained sanity; cross-scope execution refuses on degraded time | `timeutil::big_backstep_holds_and_degrades_f_time_1`; `timeutil::hold_value_derived_from_pre_call_state_invariant_4`; `timeutil::served_time_never_regresses_under_hostile_steps`; `timeutil::recovery_requires_sustained_sanity`; `policy::degraded_time_refuses_crossscope_fail_closed` |
| F-TIME-2 | Device clock lies about the future | `device_ts > received_ts + skew` | Flag `low_time_confidence` — keep the observation, never trust the time | `schema::future_device_ts_flagged_f_time_2`; `integration::future_device_ts_flagged_f_time_2`; `simulator::skew_feeds_future_device_ts_f_time_2` |
| F-ING-1 | Duplicate delivery | Caller `event_id` dedupe cache | Return original seq with `duplicated: true`; nothing double-logged | `integration::duplicate_event_id_deduped_f_ing_1` |
| F-ING-2 | Oversized payload | Body/payload byte caps before ledger | HTTP 400, nothing lands | `schema::oversize_payload_rejected_f_ing_2`; `integration::oversized_payload_rejected_f_ing_2` |
| F-ING-3 | Malformed body behind a valid signature | Envelope parse failure after byte verification | 401 `Malformed`, nothing lands | `identity::malformed_signature_rejected`; smoke check "tampered body refused" |
| F-STATE-1 | Anomaly / dormancy mishandled | Engine transition rules | Anomaly ⇒ sticky U2→U1 (heartbeat does not restore); dormancy ⇒ U0-frozen; return does not unfreeze without operator action | `state::anomaly_demotes_u2_to_u1_f_state_1`; `state::stale_to_dormant_freezes_u0`; `state::dormant_beats_any_grant`; `state::planned_offline_silence_is_not_suspicion`; `integration::anomaly_demotes_device_control_f_state_1`; `integration::silence_progresses_to_dormant_and_freezes` |
| F-AUTH-1 | Bad / tampered signature | Ed25519 verify over exact bytes | 401, nothing lands | `identity::wrong_key_rejected_f_auth_1`; `identity::tampered_body_rejected_f_auth_1`; `integration::tampered_body_rejected_at_ingest_f_auth_1` |
| F-AUTH-2 | Replayed request | Nonce cache (check-and-insert) | 401 `Replay` | `identity::replay_nonce_rejected_f_auth_2`; `identity::full_auth_path_replay_rejected_f_auth_2`; `integration::replay_rejected_f_auth_2`; smoke "replay refused" |
| F-AUTH-3 | Stale timestamp (long-delayed capture) | ±5 min window vs trusted time | 401 `StaleTimestamp` | `identity::stale_timestamp_rejected_f_auth_3`; `integration::stale_timestamp_rejected_f_auth_3` |
| F-AUTH-4 | Unknown principal / forged identity | Keystore lookup before any signature work | 401 `UnknownPrincipal` | `identity::unknown_principal_rejected_f_auth_4`; `integration::unknown_principal_rejected_f_auth_4`; smoke replay/tamper paths |
| F-BUS-1 | Slow consumer silently losing events | Bounded queue overflow counter | Drops counted per topic, callback `(topic, cumulative)` fires per drop-batch (constructor-required), flushed into the audit ledger | `bus::slow_consumer_drops_counted_f_bus_1`; `bus::loss_callback_carries_topic_and_cumulative_count_invariants_3_5`; `integration::bus_loss_audit_recorded_in_ledger_f_bus_1_invariants_3_5` |
| F-NET-1 | Presence flap / lease expiry | Lease TTL + neighbor states + 2-vote hysteresis | Transitions emitted once per state change; single flaps damped | `network::hysteresis_damps_flaps_f_net_1`; `network::lease_expiry_absent_after_ttl`; `network::return_to_present_emits_transition_once`; `integration::network_presence_poll_emits_and_damps` |
| F-HW-1 | BLE adapter unavailable | `BleSession::open` → `AdapterUnavailable` | Engine degrades to non-BLE inputs, never crashes | **hardware spike item** (`ble_btleplug.rs`, `--features ble`) |
| F-HW-2 | Mid-read disconnect / invalid measurement | Decode errors, zero-bpm rejection, dropout windows | Surface as errors/anomalies, not bogus readings | `ble::zero_bpm_is_invalid_f_hw_2`; `ble::truncated_u16_bpm_is_error`; `simulator::dropout_produces_no_events_f_hw_3_scenario` — radio path: **spike item** |
| F-HW-3 | Reconnect storm | Exponential backoff with cap + deterministic jitter | Bounded delays forever | `ble_btleplug::backoff::reconnect_storm_stays_bounded_f_hw_3`; `backoff::grows_exponentially_then_caps` — radio path: **spike item** |

Out-of-scope for software tests (physical/legal workstreams): real-radio soak,
hardware FIDO2 authenticators, DPIA/BIPA/MHMDA review.
