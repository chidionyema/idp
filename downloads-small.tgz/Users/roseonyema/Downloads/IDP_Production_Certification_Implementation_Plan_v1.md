# IDP estate context substrate — production certification and implementation plan v1

**Date:** 2026-10-28  | **Repository:** `chidionyema/idp`  | **Inspected main commit:** `2285593f0a4da6c3aebb895a1e55cd3fcf6eee83`  | **Status:** release-candidate specification; **NOT production-certified**.

This is an execution contract, not an assertion of deployment. Production certification is an outcome of the evidence gates below. Do not mark any gate PASS without attaching machine-verifiable results from the target environment.

## Decision

Extend the already implemented context stack, not a new RAG service. Retain Gortex as sole code-context ranker, `estate-context-broker` as the enforcement point, `ContextPlan` as deterministic compilation contract, unified memory as the memory authority, and catalog/affected-graph as topology sources. Add a versioned **federated read-only context API** to the existing broker with typed adapters and explicit coverage. Keep existing `estate_context` backward compatible. No new persistent database without benchmark evidence.

## 1. Code-grounded current state

| Component | Implementation | Production proof needed |
|---|---|---|
| Gortex index | `.github/workflows/context-index.yml` builds v0.64.11 index, tests freshness, publishes OCI artifact, signs it | Latest workflow run, index digest, signature verification, target pod index SHA |
| MCP broker | `platform/estate/context/server.py` exposes `estate_context` and `estate_context_status` | authenticated gateway end-to-end request; caller identity; trace |
| Policy | `platform/estate/context/broker.py` enforces tool allowlist, claims, freshness, budget, secret redaction | live refusal probes, negative auth tests |
| Deterministic compiler | `platform/estate/context/plan.py`, `bin/estate-context-compile` | deterministic hash across repeat executions with pinned inputs |
| Broker deployment | `platform/mcp/estate-context-broker.yaml` has loopback engine sidecar, index PVC | running image digests, resource usage, isolation and NetworkPolicy checks |
| Unified memory | `platform/unified-memory-server/main.py` exposes search, recall, brief, embeddings status | tenant isolation, embedding health, latency, recall quality |
| Topology | `bin/idp-affected-graph`, `bin/catalog-projection`, Backstage providers | coverage and edge ground truth |
| CI/test gates | `bin/estate-context-gate`, `tests/test_estate_context_{broker,compile,server,claims}.py` | test logs with SHA, exit code, runner and artifacts |

**Access limitation:** GitHub source and main commit were read through the connected repository. GitHub Actions workflow-run endpoint was rejected by the connector. Kubernetes, production metrics, deployment revisions, network access and live CI test results are not accessible through that read path. These are **BLIND**, not PASS or FAIL.

## 2. Production target: one federation contract

**New tool:** `estate_context_resolve_v1` on existing MCP broker; no mutation tools, no public Gortex route. Existing tools remain unchanged.

**Input:** `query`, `intent`, `scope`, `temporal` (`commit`, `as_of`, `live`), `evidence`, `limits` (`deadline_ms`, `token_budget`, `max_sources`), authenticated principal from gateway and optional issue/agent claim. Never trust client-supplied principal or trust tier.

**Output:** `schema_version`, `query_id`, `status` (`COMPLETE`, `PARTIAL`, `REFUSED`, `UNAVAILABLE`, `INVALID_REQUEST`), `context_plan`, `sources`, `claims`, `gaps`, `policy`, `timing`, `cache`. Every source has immutable revision or observed timestamp, locator, digest where applicable, authority, and evidence method. Every claim references its supporting source IDs. `SUPPORTED_SOURCE` must not be interpreted as semantic entailment; `REEXECUTED` requires a proposition-bound typed verifier.

**Typed adapters:** `code` (Gortex), `catalog` (catalog projection), `memory` (unified-memory API), `git_ci` (GitHub immutable commits/checks), `runtime` (Kubernetes read-only), `telemetry` (bounded logs/metrics/traces), `policy` (claim issue and effective policy), `evidence` (Aevum/verifier). Each implements `discover`, `hydrate`, `health`, deadline/cancellation, identity and scope validation. No arbitrary shell command from retrieved material.

**Compilation:** authenticate -> authorize scope -> classify intent -> select required/optional authorities -> parallel bounded discovery -> source-specific ranking -> hydrate -> deduplicate by source/revision/span -> compare conflicts -> deterministic budget allocation -> provenance and coverage envelope. Code ranking remains Gortex-owned; do not introduce a competing global embedding index.

**Freshness:** commit mode refuses index mismatch; live mode refuses to call stale cached data live; working-copy mode may explicitly report `ASYNC_REINDEX` as already supported by broker. Cache key includes principal/scope, revision, policy version, query, schema and budget. Revocation invalidates authorization regardless of cache TTL.

## 3. Critical dependencies and implementation work packages

| ID | Prerequisite | Change set | Required tests | Exit |
|---|---|---|---|---|
| P0 | none | Baseline collector and evidence manifest; run existing gates and live probes | existing context suite + reproducibility of collector | signed baseline with no unexplained BLIND for claimed capabilities |
| P1 | P0 | `platform/estate/context/contracts.py` typed schemas; fixtures; backward compatibility tests | strict schema, malformed input, unknown scope, downgrade tests | no change to existing tool responses |
| P2 | P1 | `platform/estate/context/adapters/{base,code,catalog,memory}.py`; `federation.py` | auth before discovery and hydration, stale index, memory down, conflicting sources, determinism | source-linked answers, required-source recall@20 >=0.90 on labelled set |
| P3 | P2 | Register `estate_context_resolve_v1` in `server.py`, enforce via `broker.py` | end-to-end MCP protocol, auth, path traversal, symlink, cross-tenant, secret leak | zero critical bypasses; old endpoint unchanged |
| P4 | P3 | `git_ci` and `runtime` adapters with read-only credentials | CI SHA pinning, RBAC denial, stale observations, cluster API outage | no cached history masquerading as live state |
| P5 | P4 | telemetry, policy and evidence adapters; semantic verification boundary | malicious retrieved instructions, false passing instrument, forged export flag, timestamp conflict | no false verified claims in adversarial suite |
| P6 | P5 | shadow consumers (Oracle, Claude, Pi), canary routing and dashboards | diff against baseline, load, chaos, rollback | acceptance thresholds and rollout gates all PASS |

No P2–P6 code should be merged on speculative assumptions about deployed infrastructure. Gate each dependency in sequence; independent tests can run concurrently.

## 4. Baseline capture: exact operator commands

Run from a clean checkout at a pinned SHA. Save all stdout/stderr, UTC timestamps, exit codes and SHA-256 digests in the release evidence bundle. These commands are **proposed**, not executed in this review.

```bash
set -uo pipefail
mkdir -p artifacts/context-cert
{
  date -u +%Y-%m-%dT%H:%M:%SZ
  git rev-parse HEAD
  git status --porcelain
  python3 --version
} > artifacts/context-cert/environment.txt

python3 -m pytest -q \
  tests/test_estate_context_broker.py \
  tests/test_estate_context_compile.py \
  tests/test_estate_context_server.py \
  tests/test_estate_context_claims.py \
  > artifacts/context-cert/pytest.log 2>&1
printf '%s\n' "$?" > artifacts/context-cert/pytest.exit

python3 bin/estate-context-gate \
  > artifacts/context-cert/context-gate.log 2>&1
printf '%s\n' "$?" > artifacts/context-cert/context-gate.exit

gh run list --workflow context-index.yml --limit 10 --json databaseId,headSha,status,conclusion,createdAt,url \
  > artifacts/context-cert/context-index-runs.json

kubectl -n mcp get deploy,pods,svc,pvc -l app.kubernetes.io/name=estate-context-broker -o json \
  > artifacts/context-cert/broker-resources.json
kubectl -n mcp get deploy estate-context-broker -o yaml \
  > artifacts/context-cert/broker-deployment.yaml
kubectl -n mcp get pods -l app.kubernetes.io/name=estate-context-broker -o json \
  > artifacts/context-cert/broker-pods.json
```

**Safety:** production commands above are read-only. The working directory `artifacts/context-cert` is local; do not commit raw environment output before reviewing secrets, private topology and access controls. A missing `gh`, `kubectl`, kube context or permissions yields BLIND with reason. Do not attempt unauthorized credentials or mutate production to make a probe pass.

**Further required operator observations:** (a) authenticated `estate_context_status` via actual agentgateway route, (b) one authorized and one unauthorized MCP request with redacted transcripts, (c) actual index `index.json` commit and OCI digest + cosign verification, (d) `/embeddings/status` via permitted memory route, (e) catalog projection age, (f) service RBAC and namespace policies, (g) resource requests/limits and measured p95 latency. Save raw evidence securely and summarize redacted results.

## 5. Certification matrix — all are release blockers unless expressly waived

| Gate | Test / evidence | Pass criterion | Initial status |
|---|---|---|---|
| C01 provenance | clean SHA + reproducible build + immutable OCI digest | source, image, index and signature match | BLIND |
| C02 CI | context gate and targeted tests | all required tests PASS, no skipped critical checks | BLIND |
| C03 transport | authenticated MCP through gateway | valid protocol, caller identity preserved, private engine unreachable | BLIND |
| C04 authorization | negative principal/tenant/path tests | zero unauthorized retrieval or cache leaks | BLIND |
| C05 freshness | stale index and expired runtime observations | zero stale results labelled current | BLIND |
| C06 evidence integrity | source hashes, revision, timestamps | zero invented references or unsupported verified labels | BLIND |
| C07 determinism | repeated pinned query and source set | identical plan hashes, omission list and ordering | BLIND |
| C08 retrieval quality | 100 expert-labelled questions, >=20 adversarial | recall@20 >=.90; supported claims >=.98; abstention >=.95 | BLIND |
| C09 performance | representative warmed and cold load tests | code-only p95 <=3s; federated p95 <=8s; limits respected | BLIND |
| C10 resilience | missing index, engine down, memory down, 403, timeout | correct REFUSED/PARTIAL/UNAVAILABLE; no false COMPLETE | BLIND |
| C11 operations | dashboard, alert, runbook, on-call and rollback drill | recovery evidenced; no data-loss or auth bypass | BLIND |
| C12 rollout | shadow diff, 5%, 25%, 100% stages | each stage meets gates, no regression vs legacy tool | BLIND |

Thresholds are **proposed release criteria**, not observed SLOs. Baseline results may justify stricter thresholds; any relaxation requires an explicit recorded decision and risk owner. Security, provenance and stale-as-live failures are not waivable for production certification.

## 6. Evaluation corpus and scoring

Store at `eval/estate-context/` with versioned fixtures, provenance and gold evidence. Stratify 100 cases: 20 code, 15 dependency/impact, 15 runtime, 15 incident, 10 memory/decision, 10 CI/GitOps, 10 policy/security, 5 cross-domain. At least 20 adversarial cases distributed across categories: stale docs, incorrect test name, counterfeit source URL, injected tool instruction, unauthorized namespace, cross-principal cache, false-positive instrument, missing runtime, conflicting observations, truncated response. Each case specifies required authoritative sources, forbidden assertions, expected abstention/coverage, maximum age and a deterministic grader. Human adjudication for ambiguous causal claims; no self-grading by the same generation model as sole oracle.

Report recall@20, citation validity, claim support precision, appropriate abstention, source coverage, contradiction detection, latency p50/p95/p99, CPU/RAM, index size, token usage and cost per question. Compare existing `estate_context`, federated implementation and a source-only deterministic baseline. Benchmark on a pinned commit and repeat on a changed commit to measure index lag and staleness.

## 7. Deployment, rollback and operational constraints

- Package in existing broker image; maintain loopback Gortex sidecar and existing private network boundary.
- Feature flag the new MCP tool; default disabled until C01–C11 PASS. Shadow invocation must not leak protected data or change any source of truth.
- Canary progression: internal authorized consumer -> 5% -> 25% -> 100%; minimum 24-hour observation per stage **proposed**, adjust only with measured traffic volume. Automatic rollback on any auth leak, stale-as-live claim, source fabrication, sustained error-budget burn or index provenance failure.
- Rollback: disable the new tool/route and adapter fanout; preserve old `estate_context`; revert broker image to recorded digest; leave memory, catalog, Git and Kubernetes untouched. Verify old MCP endpoint after rollback.
- Keep previous signed index artifact available; test loss of latest index and verify fail-closed behaviour for commit-pinned requests.
- Instrument adapter latency, errors, coverage, cache scope, redactions, plan tokens, authorization refusals, index lag and per-source freshness; use opaque request IDs and redact payloads.
- Capacity: enforce deadline, per-adapter concurrency, memory and CPU ceilings; establish actual node headroom before sizing. Do not assume the existing 2Gi index PVC is sufficient for new federated workloads.

## 8. Governance and sequencing

The repository's `AGENTS.md` requires a GitHub issue, an active CLAIM with covered paths and a `lane/*` branch; do not push directly to main or bypass Greenlane. Create one programme issue with child work items P0–P6, explicit owner, dependency and acceptance evidence. No agent should claim ownership of paths until the issue/claim mechanism confirms it. Release evidence must identify author, commit, test environment, runner, timestamps, exit codes and immutable artifact digests.

**Go/no-go decision:** production certification is `PASS` only if all C01–C12 are independently evidenced and the release owner approves the recorded manifest. Otherwise status is `NOT CERTIFIED` with blockers. This document is immediately usable to begin P0; it does not falsely assert that the estate has already met those gates.

## 9. Source references (repository, pinned main SHA above)

- `platform/estate/context/{broker,server,plan,claims,local_engine}.py`
- `bin/{estate-context-compile,estate-context-gate}`
- `.github/workflows/context-index.yml`
- `platform/mcp/estate-context-broker.yaml`
- `platform/unified-memory-server/{main,ranking}.py`
- `tests/test_estate_context_{broker,compile,server,claims}.py`
- `mcp/plugins/estate_memory.py`
- `AGENTS.md`

**Evidence note:** Source files were inspected through the connected GitHub repository. Current live GitHub Actions runs and cluster state have not been observed. Never promote source existence to operational certification.
