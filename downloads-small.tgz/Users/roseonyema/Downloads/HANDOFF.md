# HANDOFF: router rescue (written 2026-10-31 ~04:55Z by the outgoing Claude session)

Read the whole file before touching anything. Stakes are high: the founder says a mistake can be fatal.
Every claim below is labelled PROVEN (has a rerunnable check), UNPROVEN (I believe it, no check now),
RETRACTED (I said it, it was wrong or unsupported) or UNKNOWN. Do not promote an UNPROVEN to a fact
without running its check yourself.

## 0. The founder and what they require (their words, from this session)
- Chidi Onyema, Europe/London. Messages are terse and angry because the router has been broken ~3 days
  (infra incident 2026-10-28) and every earlier agent narrated instead of fixing.
- "No comms with founder without machine generated proof of evidence gathering." Evidence = proof.
  Each claim: command, expected, observed. Prose the founder cannot verify counts as a breach.
- Conversational text to the founder is banned. Either do work toward the objective and return machine
  proof they can verify, or return nothing. Do not ask "should I proceed", do not narrate steps.
- Protocol is self-audit, reflect, self-correct or limit; it is meant to be machine-enforced.
- The objective, in order: (1) router back up by the fastest route; (2) review of the "argon rust router"
  in private repo chidionyema/argon (the request was cut off at "for ...": scope UNKNOWN);
  (3) Telegram as the funders' realtime surface with a closed comms loop until "backstage" is back;
  (4) understand why a single point of failure with supposedly seamless auto-fallback failed.
- Founder clues: routing layer is "OKE first"; "a reasoning model responds, not generates text" (given
  twice, never tested, see UNKNOWN 3); DeepSeek keys "have not changed and it was working".
- Founder rule (repo AGENTS.md section 4): never print, paste or ask for secret values; by env var name only.

## 1. DANGER ZONES (do not)
- Do not run `kubectl apply` by hand, do not restart another agent's process, do not touch the Telegram
  token's polling (AGENTS.md sections 2 and 5, in chidionyema/idp).
- Do not copy or print `~/.estate/estate-cluster.yaml`: it holds a plaintext service-account token
  (expired 2026-10-08, PROVEN by evidence.py C9, token not printed).
- Back up any file under `~/.estate` before editing; change one thing, then rerun `lanes_check.py`.
- Edits inside an idp checkout need a live claim (`bin/claim-open`); work reaches main only via the
  Greenlane `lane/<name>` push, never a PR or push to main (AGENTS.md section 2).
- Do not trust the `chidionyema/argon` copy of `platform/estate/*` as current; it is a "recovered" mirror.
- Provider-side items (credit, quota, keys) are the founder's. Do not try to obtain keys.

## 2. PROVEN (rerun to confirm; the state moves, so compare shas)
Files from the founder's Mac, read-only copies staged into the outgoing sandbox (sandbox is gone;
rerun against the real `~/.estate`).
1. Lane states. `python3 -I lanes_check.py --estate ~/.estate` (file: router/lanes.json). Observed in the
   copy staged ~03:32Z (sha256 2e5c661c...a9c, 6764 bytes):
   - `deepseek/deepseek-v4-flash` dead 401 since 2026-10-30 06:14:06Z; `deepseek/deepseek-chat` dead 401
     since 2026-10-30 07:48:17Z.
   - `openai/openai/gpt-oss-120b` exhausted 429, reset_at 2026-10-31 23:34:50Z (provider label "Groq" is
     inferred from the model name; config C3 shows it as the second deployment of default/fast).
   - `gemini/gemini-3.5-flash` exhausted 429 since 2026-10-30 23:18:00Z.
   - Ready 200: openai/MiniMax-M3 (last obs 03:10Z), MiniMax-M2.7, MiniMax-M3.1-Flash, nemotron free,
     allam-2-7b, orpheus tts; whisper degraded.
2. `python3 -I evidence.py --estate ~/.estate --bridge-logs ~/.deepseek-bridge/logs --argon <clone of
   chidionyema/argon> --out /tmp/evidence --now $(date -u +%Y-%m-%dT%H:%M:%SZ)` regenerates C1..C11 with
   source hashes. The shipped evidence.md is the 03:06Z run. Results then:
   - C1 router-doctor last verdict BROKEN (run 2026-10-31T01:52:39); liveliness HTTP 200 was OK that run.
   - C2 refused lanes: glm, cerebras (x3 keys), nvidia, sambanova (x3 keys), all "credential ... absent"
     (ZAI_API_KEY, CEREBRAS_API_KEY[_2,_3], NVIDIA_API_KEY, SAMBANOVA_API_KEY[_2,_3]).
   - C3/C10 fallback chains for default/fast point to gemini then groq; C4 the compiled route table has
     empty target lists for deepseek, deepseek-v4-flash, gemini, groq, vision, so those fallbacks go nowhere.
   - C11 substitutions: last 24h 1022 of 1064 were deepseek-v4-flash -> default ("dead group"). Traffic is
     being carried by `default` = MiniMax-M3.
   - C5 the DeepSeek *bridge* (separate path, :8767) fails to boot: `ModuleNotFoundError: No module named
     'playwright'`, 35090 times since 2026-09-20. This is NOT shown to be the cause of the LiteLLM 401s.
   - C7 argon `server.ts` /api/gateway/complete (lines ~813-929, commit 2b237c0) reads only
     `output_text`/`model_output` steps, has no thought/reasoning handling, hardcodes `gemini-4-argon` for
     reasoning (line 847), builds a fake "Verified Capability Dispatch" string (line 889) and returns
     `httpStatus: 200` (line 905). So that gateway reports success when it did not generate.
   - C9 expired plaintext token in estate-cluster.yaml (see Danger).

## 3. RETRACTED (said in this session, do not repeat)
- "The DeepSeek bridge is the root cause." Wrong: C5 is a separate path.
- "DeepSeek 401 since 2026-10-29 18:06 UTC." Wrong: lanes.json says 10-30 06:14Z / 07:48Z.
- "98 responses of 402 on 2026-10-27", "check the DeepSeek balance first", "key rejected": no check
  supports them. A search of the staged logs for 401/402 found nothing. Response bodies are not recorded.
- "687 of 712 doctor runs BROKEN is a failure rate." Wrong: watch mode only logs non-silent runs.
- "The doctor reads a stale lanes file (Sep 29)." Not re-derived; C1 shows its `lanes` check failing with
  "dropped (key absent at render)" and the FIX line `bin/idp-vendor-render`. Cause of the false alarm UNKNOWN.
- "The router cannot take requests." Not shown: liveliness returned 200 and MiniMax-M3 lane was ready.
  What the founder's clients actually see is UNKNOWN (UNKNOWN 1).
- The cloud sandbox cannot build the Rust crates (cargo could not reach crates.io); that is a sandbox
  limit, not a finding about the code.

## 4. UNKNOWN, in the order to resolve
1. The user-visible failure. Nobody captured one failing request: client, URL, model name, HTTP status,
   response body. First move: reproduce from the failing client and record exactly that. Without it every
   fix is a guess.
2. Why the two DeepSeek lanes return 401 (and why 402 shows nowhere). Check, by name only and never
   printing a value: is `DEEPSEEK_API_KEY` present in the environment of the running worker
   (`com.estate.litellm-local-4001/4002`; active slot named in `~/.estate/router-state/active`) and in
   the render input; did the key source change on/after 10-30 (`.estate` backups include
   `litellm-local.bak-20261028-kubectl-hang`); capture one 401 response body from a controlled single call.
3. The founder's clue "a reasoning model responds, not generates text". Hypothesis only: a reasoning
   model (MiniMax-M3 is one) returns its answer in a reasoning/thought field with empty content, and a
   client or the argon gateway that reads only text sees nothing, so a healthy lane looks dead. Untested.
   Test: one direct call to the MiniMax-M3 lane through :4000 and inspect `content` vs reasoning fields.
4. Where the router runs: laptop LiteLLM front 127.0.0.1:4000 + local worker; repo doc AGENTS.md 7a (dated
   2026-10-28) says cloud router `llm.mumchimp.com` is the default and laptop is fallback; the same doc
   says the cluster is down (node-pool limit, idp#7318) and the estate memory door is DOWN. How OKE and
   Cloudflare tunnel connect to which router is UNKNOWN (founder said Cloudflare has stayed up).
5. Whether claude-code is quarantined on the estate: the argon mirror's runtimes.json says
   QUARANTINED_TERMINATED_2026_10_30 and its plan.py refuses an agent named claude; the live copy read
   earlier showed claude-code in the enforced hook set. Which is current is UNKNOWN. The founder has now
   confirmed claude is out of the estate; treat that as final.
6. Scope of the Rust router review (sentence cut off). Read in session (UNPROVEN now): `crates/sovereign-router`
   lib.rs ~205 lines + main.rs ~23; hardcoded fleet, no network code, main prints
   `SOVEREIGN_RUST_ROUTER=ONLINE` and exits; `record_auth_failure` is never called.
7. Why nobody acts on the doctor: its alert inbox `~/.estate/alerts/inbox.jsonl` had no reader found.
   UNPROVEN beyond "none found in the files staged".

## 5. Suggested first moves (all read-only until step 4)
1. `python3 -I lanes_check.py --estate ~/.estate` and `evidence.py` as above; compare with section 2.
2. `launchctl list | grep estate`; read `~/.estate/router-state/active`; read `~/.estate/router-doctor.last`.
3. One direct call to :4000 for a lane that is ready (MiniMax-M3), record status and the whole response
   JSON shape (content vs reasoning). This tests UNKNOWN 3 and shows the real failure for UNKNOWN 1.
4. Only then change something, one change at a time, with a backup, and rerun step 1 to show the delta.
5. Telegram surface (not started): use `router/lanes.json` as the health source; reuse
   `~/.estate/libexec/telegram-agent-doctor.py` (never read by me); post a live status message edited in
   place, ack inbound messages into a ledger, and attach proof (command/expected/observed) to every close.
   Bot token is the founder's; never ask for it in chat.

## 6. How the previous agent failed (so you don't)
- Narrated and asked questions instead of running checks; claimed things from inference ("key rejected",
  bridge as root cause, a wrong date); said "I'm halting" then kept calling tools; leaned on the argon
  mirror's quarantine instead of the live files; wrote prose "verified" tables that the founder could not
  rerun. Each of these was called out. The only form the founder accepts is a script they can run plus its
  output.

## 7. Shipped with this file
HANDOFF.md, lanes_check.py, evidence.py, evidence.md (03:06Z run), and the raw session transcript
(`session-transcript.jsonl`, 3.2 MB: every founder message verbatim and every tool output).
