#  
col_gate.py", and 372 shell doors in "idp"
    And the Founder Mac operates strictly under "DARWIN_THIN_CLIENT" seatbelt containment
    When any agent harness (Pi, Cline, Claude Code, Codex, OpenCode) initializes a session
    Then local port binding (3000, 4300, 8099), local daemon spawning, and writes to "\~/.estate" are blocked at the OS kernel level
    And Genesis v0.7.0-RT executes exclusively against isolated "/var/lib/genesis/genesis.db" and Cloudflare D1
    And the unpinned "protocol_gate.py" unsupported-report relaunch loop is permanently severed.

  Scenario: Lane 2 — Edge, DNS, and 3-Way Surface Convergence (Local, R2, GitHub)
    Given "neon-tunnel" (UUID d77a438e-996e-4eac-9c1b-96b3dc07d9f1) is the single authoritative tunnel
    When edge ingress and DNS records are converged for "llm.mumchimp.com", "otto.mumchimp.com", and "estate-bus.mumchimp.com"
    Then stale Oracle Cloud IP "193.123.184.22" and ad-hoc "trycloudflare.com" quick tunnels are eliminated
    And every deployment atomically synchronizes across GitHub ("argon"/"idp"), Cloudflare R2/Pages, and Telegram HUD "3327"
    And external probes to all three hostnames return HTTP 200 with valid Cloudflare edge receipts.

  Scenario: Lane 3 — Sovereign Router (ROUTE-01), Battalion, Battation, and Pennyd Token Pool Unification
    Given "sovereign-router" (Rust), "Battalion" (idp#3525 ROUTE-01), "Battation" metering, and "pennyd.toml" ("max_tokens_cap = 1024") govern model execution
    When any cloud or local worker invokes an LLM completion
    Then direct upstream provider calls are rejected per ROUTE-01
    And "sovereign-router" enforces "max_tokens_cap = 1024", strips upstream reasoning-token starvation, cuts over providers at 95% capacity, and quarantines 401 keys automatically
    And live pool capacity (Compute, RAM, Disk, Token burn) streams to the Genesis HUD and Telegram "3327".

  Scenario: Lane 4 — Split-Authority Credentials, Session Enclave Signing, and Guarded-Path Gate Enforcement
    Given four role credentials exist ("worker", "lander", "certifier", "founder") with weight W_agent = 0 on guarded paths
    When a worker session proposes a commit to "propose/<session-id>/\*"
    Then the out-of-process "genesis-kernel" signer binds "(repo, base_tree_sha, new_tree_sha, parent_commit_sha, session_id, fencing_token)" with a router-signed "InferenceReceipt"
    And the guarded-paths verifier diffs "\$BASE...$HEAD_REV" from pinned "refs/heads/main"
    And "LINEAGE = hash(harness, provider, model_family)" permanently retains 100% of constitutional karmic debt across config changes.

  Scenario: Lane 5 — Intercloud Three-Homes Failure-Domain Separation Without Paid OKE Drift
    Given "three-homes.yaml" requires three independent failure domains for Otto and Sovereign Router
    When infrastructure convergence runs via OpenTofu ("oke-check")
    Then preemptible paid "a1-spot" pools are stripped to preserve 100% Always Free A1 limits (4 OCPU, 24 GB RAM, 200 GB disk)
    And "bridge_identity" and "quad_ledger" vault secrets are protected with "ignore_changes" lifecycle rules
    And Home 1 runs on Cloudflare Worker+D1, Home 2 runs on OCI Always Free A1, and Home 3 runs on GitHub Greenlane ephemeral runners.

  Scenario: Lane 6 — Remediation of All Six Self-Inflicted Genesis v0.7.0-RT Kernel Defects
    Given "genesis-kernel" ("src/certifier.rs", "src/realtime.rs", "src/main.rs") and "bin/otto_real_core.py" boot on ":4001"
    When state transitions occur on "otto_instructions" or "/api/realtime/rollback"
    Then a single canonical Rust DDL governs "otto_instructions" with "updated_at" intact
    And SQLite triggers read the dynamic fencing token from "kernel_fence_state" and compute deterministic SHA-256 Merkle chains instead of "randomblob(16)"
    And Axum middleware enforces "CertifierPublicVerifier" Ed25519 signatures on every ":4001" mutation endpoint.

## PART 2: COMPLETE 3-DAY CHRONOLOGICAL DOWNLOAD (2026-11-11 TO 2026-11-13)

### 2.1 Executive Timeline Table

| Date | Workstream / Domain | Root Defect Diagnosed | What Was Built / Specified / Decided | Current Yield Status | 
| ----- | ----- | ----- | ----- | ----- | 
| **2026-11-11** | **Router Unblocking & `pennyd` Efficiency Lock** | 1\. `pennyd.toml` (`max_tokens_cap = 1024`) starved MiniMax 2.7 because `<think>` reasoning tokens consumed the full 1024 cap before emitting text.  2\. Cloudflare 1010 blocks (missing User-Agent).  3\. Vault API key 401 mismatch.  4\. Retired `gemini-2.5-flash` model ID. | Built `/Users/roseonyema/.estate/bin/io` 1-pass oracle CLI (`io state`, `io review`, `io heal-router`). Preserved `max_tokens_cap = 1024` permanently while fixing model mapping, reasoning budget split, and Cloudflare 1010 headers. | Local Mac only (`0` cloud yield until `sovereign-router` moves off Mac). | 
| **2026-11-11** | **Gate Hardening vs. Pin Drift** | `protocol_gate.py` was hardened with a fail-closed budget branch and `ESTATE_RECEIPT_KEY` seal (`sha256: 85719d0e`), but `pins.json` retained the Nov 10 pin (`b5a1a239`) and git `HEAD` (`a6cb7a2c`) was never updated. | Identified exact cause of recurring `integrity: "TAMPER"` alarms across subsequent sessions. | Blocked by History quarantine; superseded by Genesis `certifier.rs`. | 
| **2026-11-12** | **Deterministic Governance vs. Prompt-Babysitting (Tornhill Review)** | Standard AI workflows rely on probabilistic prompt-babysitting rather than mechanical execution boundaries; chat memory summarization was erasing Founder shorthand lexical macros. | Formalized Estate Command Codes (`FLOW`, `I10`, `I11`, `QUAD`, `KARMA`) and restored canonical lexical macro table (`asymmetry capture`, `fractal`, `recursive`, `yield`, `seal`, `proof`). | Codified in specification; awaiting HUD attestation. | 
| **2026-11-12** | **Formal Mathematical Primitives for Estate Execution** | Informal prose rules allowed agents to reinterpret state transitions, routing costs, and audit trails. | Derived four formal mathematical primitives: Galois Connections, Tarski's Fixed-Point Theorem, Tropical Semirings, and Cryptographic Append-Only Monads. | Integrated into `GenesisSplitAuthorityCertifier` and `Battalion` specs. | 
| **2026-11-12** | **Product, Surface, Security & 3-Way Deployment Mandate** | Disconnected internal vs. external surfaces (`argon`, Meridian website, Telegram branding); agents deploying to single environments instead of all three. | Mandated atomic 3-way deployment across Local Machine, Cloudflare R2, and GitHub (`chidionyema/argon`, `idp`), plus Telegram `3327` synchronization. Brought `neon-tunnel` connector live. | `llm.mumchimp.com` live (`200`); `otto` and `estate-bus` left unrouted. | 
| **2026-11-13** | **Legion/Chronos Audit, Argon PR #100 & Identity Split** | Every agent acted on GitHub as `chidionyema` (admin). `idp` guarded-paths check had been silently open since 2026-10-28 (`$BASE...HEAD_REV` missing `$`) and executed candidate code. | Designed 4-role credential split (`worker`, `lander`, `certifier`, `founder`), ref-scoped broker tokens, out-of-process `genesis-kernel` session signing, `InferenceReceipt` + logprob canaries, and `LINEAGE` vs. `GENERATION` karma inheritance. | Specified for atomic cutover. | 
| **2026-11-13** | **Host Disk Exhaustion, Localhost Bait-and-Switch & Split-Brain** | Mac free disk fell from `1,203 MB` to `821 MB`, locking `estate-execute`. Agents spun up localhost `:3000`, `:4300`, `:8099`, PID `89543` (`estate-yield-notify`), and broken `trycloudflare.com` tunnels (404 due to `config.yml` shadowing) while `otto.mumchimp.com` pointed to dead OKE IP `193.123.184.22`. | Diagnosed full deadlock chain, halted `oke-check mode=apply` trap (which risked paid `a1-spot` billing and vault secret overwrites), and specified `DARWIN_THIN_CLIENT` kernel seatbelt + History vs. Genesis quarantine + 6-defect Genesis kernel remediation. | Consolidated in this master file for execution. | 

### 2.2 Restored Founder Lexical Macros & Command Codes (2026-11-12)

To prevent context compaction from ever stripping Founder shorthand again, these macros are pinned verbatim:

| Lexical Macro / Code | Formal Operational Definition in Genesis | 
| ----- | ----- | 
| **`asymmetry capture`** | Extracting maximum verified deterministic leverage (compute, routing arbitrage, zero-cost free-tier capacity, reusable proof primitives) from minimal human input or token spend. | 
| **`fractal`** | Self-similar governance and verification structure at every scale: a single tool call, a session turn, a lane PR, and an entire estate release obey the exact same `Instruction -> BDD -> Receipt -> Yield` contract. | 
| **`recursive`** | Every verification gate, router, and certifier audits both its target payload and its own pinned digest (`GENESIS_SPORE.dna`) before emitting a state transition. | 
| **`yield`** | Capabilities proven running live in real time on the Founder's external surface (`genesis-founder-surface.pages.dev`) and Telegram Pinned Message `3327`, tested by the Founder and confirmed via `[APPROVE YIELD]`. Code merely merged to `main` has `yield = 0`. | 
| **`seal`** | Cryptographic closure of a state transition using an Ed25519 signature, an RFC 6962 Merkle chain link, and a monotonic fencing token so no subsequent session can mutate or replay it. | 
| **`proof`** | Machine-generated, out-of-band deterministic evidence (status code from Cloudflare edge, SHA-256 tree digest, Z3/TLA+ invariant check, or router-signed `InferenceReceipt`)—never an agent's self-reported prose claim. | 
| **`FLOW`** | Continuous, unblocked progression of verified work through pre-authorized lanes with zero permission-nagging on safe operations and zero stillness. | 
| **`I9`** | Vendors and models are replaceable adapters, never authority. | 
| **`I10` / `I11`** | Zero-trust mechanical enforcement (`I10`: no unverified state transitions; `I11`: zero Founder CLI copy-paste chores—`NO_FOUNDER_CLI_CHORES`). | 
| **`QUAD` / `KARMA`** | 4-dimensional immutable attribution (`Credential`, `Session`, `Lineage`, `Generation`) where `UNKNOWN` is penalized (never zero) and constitutional debt is inherited across generations. | 

### 2.3 Formal Mathematical Primitives Derived on 2026-11-12

#### 1. Galois Connection Between Specification and Implementation ($\text{FLOW}$ & $\text{BDD}$)

Let $(\mathcal{L}_{\text{spec}}, \sqsubseteq_{\text{spec}})$ be the poset of Founder BDD specifications ordered by refinement, and $(\mathcal{L}_{\text{impl}}, \sqsubseteq_{\text{impl}})$ be the poset of runtime program traces ordered by behavioral inclusion. The governance harness forms a Galois connection $(\alpha, \gamma)$:

$$
\alpha : \mathcal{L}_{\text{impl}} \rightarrow \mathcal{L}_{\text{spec}}, \qquad \gamma : \mathcal{L}_{\text{spec}} \rightarrow \mathcal{L}_{\text{impl}}
$$


such that for all $S \in \mathcal{L}_{\text{spec}}$ and $I \in \mathcal{L}_{\text{impl}}$:

$$
\alpha(I) \sqsubseteq_{\text{spec}} S \iff I \sqsubseteq_{\text{impl}} \gamma(S)
$$


Any candidate commit $I$ where $\alpha(I) \not\sqsubseteq_{\text{spec}} S$ is mechanically rejected by `genesis-certifier` prior to merge.

#### 2. Tarski's Fixed-Point Theorem for Estate Convergence

Let $(\mathcal{S}, \preceq)$ be the complete lattice of estate infrastructure states, and let $F : \mathcal{S} \rightarrow \mathcal{S}$ be the monotonic convergence operator (`genesis-converger`). By Tarski's Fixed-Point Theorem, the set of fixed points $\text{Fix}(F) = \{s \in \mathcal{S} \mid F(s) = s\}$ forms a non-empty complete lattice with least fixed point:

$$
\mu F = \bigsqcap \{s \in \mathcal{S} \mid F(s) \preceq s\}
$$


A lane is converged if and only if the measured runtime state $s_{\text{live}}$ satisfies $F(s_{\text{live}}) = s_{\text{live}}$.

#### 3. Tropical Semiring Routing in `sovereign-router` and `Battalion`

Model pool selection across providers operates over the min-plus tropical semiring $(\mathbb{R} \cup \{\infty\}, \oplus, \otimes)$ where:

$$
a \oplus b = \min(a, b), \qquad a \otimes b = a + b
$$


with additive identity $\infty$ (quarantined/drained provider) and multiplicative identity $0$. For each candidate route $r$ across provider $p$ and model generation $g$, the tropical cost weight $W(r)$ is:

$$
W(r) = C_{\text{token}}(p, g) \otimes L_{\text{p95}}(p, g) \otimes K_{\text{debt}}(p, g) \otimes \Phi_{\text{cap}}(u_p)
$$


where the capacity barrier function $\Phi_{\text{cap}}(u_p)$ enforces the $95\%$ cutover rule:

$$
\Phi_{\text{cap}}(u_p) = \begin{cases} 0 & \text{if } u_p < 0.95 \\ \infty & \text{if } u_p \ge 0.95 \text{ or } \text{HTTP} \in \{401, 429\} \end{cases}
$$


The router selects the optimal path via tropical summation $\bigoplus_{r} W(r)$.

#### 4. Cryptographic Append-Only State Monad (`QUAD` Ledger)

Every state transition is bound inside the cryptographic ledger monad $\mathcal{M}(\Sigma)$ where each state entry $e_n$ carries a chained RFC 6962 Merkle root $H_n$ and monotonic fencing token $\tau_n$:

$$
H_n = \text{SHA256}\left(\text{0x01} \parallel H_{n-1} \parallel \text{SHA256}(\text{0x00} \parallel \text{payload}_n) \parallel \tau_n\right), \qquad \tau_n \ge \tau_{n-1}
$$


Any rollback operation increments the authoritative fencing token $\tau_{n+1} = \tau_n + 1$ and appends a compensating inverse state transition $\delta^{-1}$ rather than mutating historical rows.

## PART 3: MECHANICAL RESOLUTIONS FOR ALL 6 CRUCIAL LANES

### Lane 1: Hard Boundary Between History and Genesis + Mac Seatbelt Lockdown

| Attribute | Zone A: History (Quarantined Archive) | Zone B: Genesis `v0.7.0-RT` (Active Production) | 
| ----- | ----- | ----- | 
| **Filesystem Paths** | `/Users/roseonyema/.estate/*`, `/var/lib/estate/estate.db`, `idp/intents/*` (372 shell stubs), `protocol_gate.py`, `pins.json`, `estate-yield-notify` | `argon/crates/genesis-kernel`, `/var/lib/genesis/genesis.db`, `GENESIS_SPORE.dna`, `sovereign-router`, Cloudflare Worker+D1 | 
| **Access Mode** | `chmod -R a-w ~/.estate` (Read-Only Archive for historical inspection only) | Read/Write via signed `genesis-kernel` transactions and Greenlane CI | 
| **Mac Host Policy** | Zero local daemons (`launchctl bootout` on `otto-concierge`, `estate-yield-notify`, quick tunnels) | `DARWIN_THIN_CLIENT=1`: Mac acts solely as browser + Telegram + thin HTTPS dispatcher | 
| **Disk Recovery** | Evict 78k-token compaction logs, stale `.estate/intents` runs, and SQLite WAL bloat to restore $>10\text{ GB}$ free disk | State persisted in Cloudflare D1 + R2 and `/var/lib/genesis/genesis.db` on cloud lane | 

#### macOS Seatbelt Profile (`genesis-darwin-thin-client.sb`)

```
(version 1)
(allow default)
;; 1. Deny all inbound local server port bindings on Founder Mac (3000, 4300, 8099, etc.)
(deny network-bind (local ip "*:*"))
;; 2. Quarantine Legacy History directory as strictly Read-Only
(deny file-write* (subpath "/Users/roseonyema/.estate"))
(deny file-write* (subpath "/var/lib/estate"))
;; 3. Prevent background persistence / rogue LaunchAgents from agent harnesses
(deny file-write* (subpath "/Users/roseonyema/Library/LaunchAgents"))

```

### Lane 2: Edge, DNS, and 3-Way Surface Convergence (`neon-tunnel`)

All three public subdomains converge onto your single healthy Cloudflare tunnel (`neon-tunnel`, ID `d77a438e-996e-4eac-9c1b-96b3dc07d9f1`) and Cloudflare Worker/Pages edge—eliminating the dead Oracle IP (`193.123.184.22`), the `530` origin error on `estate-bus`, and the `404` `trycloudflare.com` quick-tunnel shadowing:

| Public Hostname | Previous Broken Target | Converged Target (`neon-tunnel` / Cloudflare Edge) | Verification Endpoint | 
| ----- | ----- | ----- | ----- | 
| **`llm.mumchimp.com`** | Local Mac `sovereign-router` via `neon-tunnel` | Cloud `sovereign-router` (`:4000`) with automatic failover | `https://llm.mumchimp.com/healthz` -> `200 OK` | 
| **`otto.mumchimp.com`** | Dead OKE IP `193.123.184.22` (TLS exit 35) | CNAME `d77a438e-996e-4eac-9c1b-96b3dc07d9f1.cfargotunnel.com` -> `:8099` / Worker Door | `https://otto.mumchimp.com/healthz` -> `200 OK` | 
| **`estate-bus.mumchimp.com`** | Stale tunnel CNAME (`HTTP 530` Error 1033) | CNAME `d77a438e-996e-4eac-9c1b-96b3dc07d9f1.cfargotunnel.com` -> `genesis-kernel :4001` | `https://estate-bus.mumchimp.com/api/realtime/sse` -> `200 OK` | 
| **`genesis-founder-surface.pages.dev`** | Disconnected from local `:3000` / `:4300` ports | Bound to `estate-bus.mumchimp.com` + Cloudflare D1/R2 + Telegram `3327` | Live Merkle root + 1-Click Rollback HUD | 

### Lane 3: Capacity & Token Pool Unification (`sovereign-router` + `Battalion` + `pennyd` + `Battation`)

No new capacity meter is permitted. Existing Founder components are wired into a single pipeline:

1. **`ROUTE-01` Enforcement (`Battalion` `idp#3525`):** Worker containers and CI lanes hold zero raw provider API keys (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `GEMINI_API_KEY` are removed from worker environments). Workers hold only a session-scoped `ESTATE_ROUTER_TOKEN` pointing to `https://llm.mumchimp.com/v1`.

2. **`pennyd.toml` Lock (`max_tokens_cap = 1024`):** Enforced inside `sovereign-router` middleware. For reasoning models (MiniMax 2.7, DeepSeek-R1), `sovereign-router` caps internal reasoning effort so output completion tokens are never starved within the `1024` ceiling.

3. **`Battation` Ledger Integration:** Every router response writes a signed metering row `(session_id, lineage_hash, generation_hash, provider, returned_model, prompt_tokens, completion_tokens, pool_utilization_pct)` to the `battation_ledger` table in `genesis.db` / D1 and broadcasts capacity crosses ($50\%, 80\%, 95\%$) to Telegram `3327`.

### Lane 4: Credential-by-Role, Out-of-Process Session Signer, and Guarded-Path Gate Fix

#### 1. Four-Role Split Authority

* **`worker` (`genesis-worker` GitHub App):** Broker issues short-lived installation tokens scoped strictly to `refs/heads/propose/<session-id>/*`. Cannot push to `main`, cannot force-push other sessions' lanes, and carries weight $W_{\text{agent}} = 0$ on guarded paths.

* **`certifier` (`genesis-certifier` GitHub App / Kernel Enclave):** Runs out-of-band verification from `refs/heads/main`. Emits Ed25519 pass receipts. Cannot merge code.

* **`lander` (`greenlane-lander` GitHub App):** The sole identity permitted to fast-forward `refs/heads/main`, and only when presented with a valid `certifier` receipt, a pre-registered rollback vector in `reversible_state_journal`, and (for guarded paths) a `founder` root signature.

* **`founder` (WebAuthn Passkey + Telegram `3327` 1-Tap):** Hardware-backed root ($W_{\text{founder}} = 1$). Never stored as a file on disk where an agent session can read it.

#### 2. Lineage vs. Generation Karma Equation

$$
\text{LINEAGE} = \text{SHA256}(\text{harness} \parallel \text{provider} \parallel \text{model\_family})
$$

$$
\text{GENERATION} = \text{SHA256}(\text{returned\_model} \parallel \text{upstream\_revision\_or\_canary} \parallel \text{config\_digest})
$$

* **Constitutional Debt (**$D_{\text{const}}$**):** Bound to $\text{LINEAGE}$. Editing `AGENTS.md` or rotating model revisions changes $\text{GENERATION}$ but inherits $100\%$ of $D_{\text{const}}$.

* **Capability Posterior (**$Q_{\text{cap}}$**):** Initialized for each new $\text{GENERATION}$ via Bayesian shrinkage:
  

  $$
  Q_{\text{cap}}(\text{gen}_{\text{new}}) = 0.70 \cdot Q_{\text{cap}}(\text{gen}_{\text{parent}}) + 0.30 \cdot Q_{\text{UNKNOWN\_PENALTY}}
  $$

### Lane 5: `three-homes.yaml` (`Intercloud`) True Failure-Domain Separation

Instead of placing all three Otto/Router homes inside one OKE cluster (or on your Mac), `three-homes.yaml` is bound to three physically independent failure domains within your $100\%$ free-tier envelope:

```
# platform/otto-gateway/three-homes.yaml (Converged Multi-Domain Spec)
apiVersion: genesis.833labs.io/v1alpha1
kind: IntercloudTopology
metadata:
  name: otto-and-router-three-homes
spec:
  quorum: 2-of-3
  homes:
    - id: home-1-cloudflare-edge
      failure_domain: cloudflare-global-network
      components: [otto-webhook-door, genesis-founder-surface, d1-state-mirror]
      endpoint: https://otto.mumchimp.com
      cost_tier: always-free-workers-d1
    - id: home-2-oci-arm-sovereign
      failure_domain: oci-uk-london-1-always-free-a1
      components: [sovereign-router, genesis-kernel, otto-concierge-core]
      compute_envelope:
        shape: VM.Standard.A1.Flex
        ocpus: 4
        memory_gb: 24
        storage_gb: 200
        forbid_spot_pools: true # Explicitly bans paid a1-spot
      vault_protection:
        ignore_secret_value_changes: [bridge_identity, quad_ledger]
    - id: home-3-greenlane-ephemeral
      failure_domain: github-actions-azure-runners
      components: [genesis-certifier, otto-parity-verifier, summon-burst-workers]
      routing_rule: ROUTE-01-via-llm.mumchimp.com

```

## PART 4: REMEDIATED GENESIS `v0.7.0-RT` KERNEL CODE (FIXING ALL 6 SELF-INFLICTED DEFECTS)

The code below replaces the defective sections I previously authored in `genesis-always-on-protocol` (`src/certifier.rs`, `src/realtime.rs`, `src/main.rs`, and `.github/workflows/guarded-paths.yml`):

### 4.1 Unified Canonical Schema, Dynamic Fencing State & Deterministic SHA-256 Merkle Triggers (`src/realtime.rs` & `src/certifier.rs`)

Fixes:

1. Moves database path from `/var/lib/estate/estate.db` (History) to `/var/lib/genesis/genesis.db` (Genesis).

2. Unifies `otto_instructions` schema (`created_at INTEGER`, `updated_at INTEGER`) across Rust and Python.

3. Replaces hardcoded `fencing_token = 1` and `randomblob(16)` with dynamic `kernel_fence_state` lookup and deterministic SHA-256 hash chaining.

4. Enforces `CertifierPublicVerifier` Ed25519 signature verification on all `:4001` mutation and rollback endpoints.

```
// argon/crates/genesis-kernel/src/lib.rs
// Remediated Genesis v0.7.0-RT Kernel: Quarantined DB, Unified DDL, Deterministic Merkle Chain, & Ed25519 Auth

use axum::{
    extract::{Request, State},
    http::{HeaderMap, StatusCode},
    middleware::{self, Next},
    response::Response,
    routing::{get, post},
    Json, Router,
};
use ed25519_dalek::{Signature, Verifier, VerifyingKey};
use rusqlite::{params, Connection};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::sync::{Arc, Mutex};

/// Hard quarantine: Genesis NEVER touches /var/lib/estate/estate.db (History)
pub const GENESIS_DB_PATH: &str = "/var/lib/genesis/genesis.db";

#[derive(Clone)]
pub struct KernelState {
    pub db: Arc<Mutex<Connection>>,
    pub certifier_pub_key: VerifyingKey,
    pub founder_pub_key: VerifyingKey,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SignedMutationEnvelope {
    pub instruction_id: String,
    pub session_id: String,
    pub lineage_hash: String,
    pub generation_hash: String,
    pub fencing_token: i64,
    pub payload_json: String,
    pub signature_hex: String,
    pub signer_role: String, // "certifier" or "founder"
}

pub fn init_genesis_schema(conn: &Connection) -> rusqlite::Result<()> {
    conn.execute_batch(
        r#"
        PRAGMA journal_mode = WAL;
        PRAGMA synchronous = NORMAL;
        PRAGMA foreign_keys = ON;

        -- 1. Single-row authoritative fencing token & Merkle tip state
        CREATE TABLE IF NOT EXISTS kernel_fence_state (
            singleton_id INTEGER PRIMARY KEY CHECK (singleton_id = 1),
            authoritative_token INTEGER NOT NULL DEFAULT 45,
            tip_merkle_root TEXT NOT NULL DEFAULT '0000000000000000000000000000000000000000000000000000000000000000',
            updated_at INTEGER NOT NULL DEFAULT (unixepoch())
        );

        INSERT OR IGNORE INTO kernel_fence_state (singleton_id, authoritative_token, tip_merkle_root)
        VALUES (1, 45, '0000000000000000000000000000000000000000000000000000000000000000');

        -- 2. Single Canonical DDL for otto_instructions (Shared by Rust & Python thin-client)
        CREATE TABLE IF NOT EXISTS otto_instructions (
            instruction_id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            lineage_hash TEXT NOT NULL,
            generation_hash TEXT NOT NULL,
            intent_summary TEXT NOT NULL,
            bdd_gherkin TEXT NOT NULL,
            status TEXT NOT NULL CHECK (status IN ('OPEN', 'CERTIFIED', 'YIELD_LIVE', 'ROLLED_BACK', 'HALTED')),
            fencing_token INTEGER NOT NULL,
            merkle_root TEXT NOT NULL,
            created_at INTEGER NOT NULL DEFAULT (unixepoch()),
            updated_at INTEGER NOT NULL DEFAULT (unixepoch())
        );

        -- 3. Real-time event ring with authentic chained Merkle roots and dynamic fencing token
        CREATE TABLE IF NOT EXISTS realtime_event_ring (
            seq_id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            fencing_token INTEGER NOT NULL,
            prev_merkle_root TEXT NOT NULL,
            merkle_root TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            created_at INTEGER NOT NULL DEFAULT (unixepoch())
        );

        -- 4. Pre-registered inverse rollback vectors for <10ms compensation
        CREATE TABLE IF NOT EXISTS reversible_state_journal (
            journal_id INTEGER PRIMARY KEY AUTOINCREMENT,
            instruction_id TEXT NOT NULL,
            fencing_token INTEGER NOT NULL,
            inverse_sql TEXT NOT NULL,
            inverse_git_ref TEXT,
            merkle_anchor TEXT NOT NULL,
            applied INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL DEFAULT (unixepoch())
        );

        -- 5. Battation pooled capacity & token ledger
        CREATE TABLE IF NOT EXISTS battation_ledger (
            receipt_id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            lineage_hash TEXT NOT NULL,
            generation_hash TEXT NOT NULL,
            provider TEXT NOT NULL,
            returned_model TEXT NOT NULL,
            prompt_tokens INTEGER NOT NULL,
            completion_tokens INTEGER NOT NULL CHECK (completion_tokens <= 1024),
            pool_utilization_pct REAL NOT NULL,
            created_at INTEGER NOT NULL DEFAULT (unixepoch())
        );
        "#,
    )?;
    Ok(())
}

/// Computes an authentic RFC 6962 chained SHA-256 Merkle root and advances the state atomically
pub fn append_chained_event(
    conn: &mut Connection,
    event_type: &str,
    entity_id: &str,
    incoming_fencing_token: i64,
    payload_json: &str,
) -> Result<(i64, String), String> {
    let tx = conn.transaction().map_err(|e| e.to_string())?;

    let (auth_token, prev_root): (i64, String) = tx
        .query_row(
            "SELECT authoritative_token, tip_merkle_root FROM kernel_fence_state WHERE singleton_id = 1",
            [],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .map_err(|e| e.to_string())?;

    // Enforce TLA+ MonotonicFencingSafety invariant
    if incoming_fencing_token < auth_token {
        return Err(format!(
            "STALE_FENCING_TOKEN: incoming {} < authoritative {}",
            incoming_fencing_token, auth_token
        ));
    }

    let mut leaf_hasher = Sha256::new();
    leaf_hasher.update([0x00]);
    leaf_hasher.update(event_type.as_bytes());
    leaf_hasher.update(entity_id.as_bytes());
    leaf_hasher.update(payload_json.as_bytes());
    let leaf_hash = hex::encode(leaf_hasher.finalize());

    let mut node_hasher = Sha256::new();
    node_hasher.update([0x01]);
    node_hasher.update(prev_root.as_bytes());
    node_hasher.update(leaf_hash.as_bytes());
    node_hasher.update(incoming_fencing_token.to_be_bytes());
    let new_merkle_root = hex::encode(node_hasher.finalize());

    tx.execute(
        "UPDATE kernel_fence_state
         SET authoritative_token = ?1, tip_merkle_root = ?2, updated_at = unixepoch()
         WHERE singleton_id = 1",
        params![incoming_fencing_token, new_merkle_root],
    )
    .map_err(|e| e.to_string())?;

    tx.execute(
        "INSERT INTO realtime_event_ring (event_type, entity_id, fencing_token, prev_merkle_root, merkle_root, payload_json)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
        params![
            event_type,
            entity_id,
            incoming_fencing_token,
            prev_root,
            new_merkle_root,
            payload_json
        ],
    )
    .map_err(|e| e.to_string())?;

    let seq_id = tx.last_insert_rowid();
    tx.commit().map_err(|e| e.to_string())?;

    Ok((seq_id, new_merkle_root))
}

/// Fail-closed Ed25519 signature verification middleware for :4001 mutation routes
pub async fn verify_ed25519_headers_middleware(
    State(state): State<KernelState>,
    headers: HeaderMap,
    request: Request,
    next: Next,
) -> Result<Response, StatusCode> {
    let sig_hex = headers
        .get("x-genesis-signature")
        .and_then(|v| v.to_str().ok())
        .ok_or(StatusCode::UNAUTHORIZED)?;

    let role = headers
        .get("x-genesis-signer-role")
        .and_then(|v| v.to_str().ok())
        .ok_or(StatusCode::UNAUTHORIZED)?;

    let digest_hex = headers
        .get("x-genesis-body-sha256")
        .and_then(|v| v.to_str().ok())
        .ok_or(StatusCode::UNAUTHORIZED)?;

    let sig_bytes = hex::decode(sig_hex).map_err(|_| StatusCode::BAD_REQUEST)?;
    let signature = Signature::from_slice(&sig_bytes).map_err(|_| StatusCode::BAD_REQUEST)?;

    let verifying_key = match role {
        "founder" => &state.founder_pub_key,
        "certifier" => &state.certifier_pub_key,
        _ => return Err(StatusCode::FORBIDDEN),
    };

    verifying_key
        .verify(digest_hex.as_bytes(), &signature)
        .map_err(|_| StatusCode::FORBIDDEN)?;

    Ok(next.run(request).await)
}

```

### 4.2 Remediated Guarded-Paths Verifier (`.github/workflows/guarded-paths-verifier.yml`)

Fixes the two defects exposed tonight on `idp`:

1. Fixes `$BASE...HEAD_REV` (missing `$`) to `"${BASE_SHA}...${HEAD_SHA}"`.

2. Runs strictly from pinned `refs/heads/main` verifier logic so a candidate PR can never rewrite the gate that judges it.

```
name: genesis-guarded-paths-certifier
on:
  pull_request_target:
    types: [opened, synchronize, reopened]

permissions:
  contents: read
  statuses: write

jobs:
  verify_guarded_paths:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Trusted Verifier From Main Only
        uses: actions/checkout@v4
        with:
          ref: refs/heads/main
          fetch-depth: 0

      - name: Verify Diff and Enforce Founder Root Proof on Guarded Paths
        env:
          BASE_SHA: ${{ github.event.pull_request.base.sha }}
          HEAD_SHA: ${{ github.event.pull_request.head.sha }}
          FOUNDER_PUBKEY_HEX: ${{ vars.GENESIS_FOUNDER_ED25519_PUBKEY }}
        run: |
          set -euo pipefail
          # Fixed variable expansion: "${BASE_SHA}...${HEAD_SHA}"
          CHANGED_FILES="$(git diff --name-only "${BASE_SHA}...${HEAD_SHA}")"
          echo "Changed files in candidate range ${BASE_SHA}...${HEAD_SHA}:"
          echo "${CHANGED_FILES}"

          GUARDED_REGEX='^(AGENTS\.md|\.github/workflows/|platform/gates/|GENESIS_SPORE\.dna|argon/crates/genesis-kernel/)'
          if echo "${CHANGED_FILES}" | grep -Eq "${GUARDED_REGEX}"; then
            echo "Guarded path touched. W_agent = 0. Verifying out-of-band Founder Ed25519 proof bound to tree SHA..."
            TREE_SHA="$(git rev-parse "${HEAD_SHA}^{tree}")"
            ./bin/genesis-verify-founder-proof \
              --tree-sha "${TREE_SHA}" \
              --base-sha "${BASE_SHA}" \
              --head-sha "${HEAD_SHA}" \
              --pubkey "${FOUNDER_PUBKEY_HEX}"
          else
            echo "No guarded paths touched. Proceeding with standard Certifier checks."
          fi

```