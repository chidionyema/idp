# xrec — Evidence-Graded Explanation Records

Tamper-evident, evidence-graded records for multi-surface agent estates.
One gate, one ledger, honest surfaces.

Specs: [`spec/EXPLANATION-RECORD-v0.md`](spec/EXPLANATION-RECORD-v0.md) (record
format, chain, retention) · [`spec/MULTI-SURFACE-v0.2.md`](spec/MULTI-SURFACE-v0.2.md)
(surface classes, transports, collaboration model) ·
[`spec/STATE-SYNC-v0.3.md`](spec/STATE-SYNC-v0.3.md) (signed snapshots, git
inbox transport, host-safeguard breaker, escalation cards).

## v0.3 additions

```sh
xrec snapshot --out-dir ./state     # signed estate ground truth for session init
xrec inbox-scan --dir inbox/live    # git-transport envelopes through the same gate
xrec cards                          # 🔴 dangling / 🟠 failures, Telegram-ready
xrec breaker --disk-gb 5 --load5 20 # host-safeguard circuit breaker policy
```

The breaker refuses new claims on a resource-starved host — the failure class
that wedged the estate at 1.9 GB free / load 42. If your Mac is already in that
state, fix resources first or `xrec breaker --off` deliberately (it's policy,
recorded in the snapshot).

## What it enforces (not documents — enforces)

- **Proof over claims.** An outcome can seal as `success` only with verified
  system or human evidence. Self-report-only success is structurally impossible.
- **Cross-surface corroboration.** A self-report must be backed by verified
  evidence from a *different agent on a different surface*. A web chat claiming
  "pushed" stays C-grade until a daemon's `git rev-parse` lands as A-grade.
- **Capability honesty at the gate.** Instructions can declare a required
  capability; agents register signed capability sets. A CONSULT-class web
  surface cannot claim a `git_push` instruction — the gate refuses.
- **Fencing + leases.** Monotonic fencing tokens kill stale/replayed claims;
  leases with TTL kill double-execution and zombie ownership.
- **Tamper evidence.** Hash-chained events and records, HMAC-SHA256 signatures
  (Ed25519 behind a feature flag), SQLite triggers making sealed history
  insert-only, and `xrec verify` re-walking every link.
- **Fail-closed redaction.** Secret shapes never enter the ledger; payloads
  marked no-log abort the write.
- **Crash recovery.** Unsealed records surface as `dangling` and must be
  resolved (resume or abort) — never silently dropped.
- **EU AI Act Art. 12 floor.** Retention below 4380h is refused; purges require
  an export manifest and are themselves recorded as attested records.

## Build

```sh
rustup default stable        # 1.96+ tested
cargo build --release        # binaries: xrec (CLI), xrec-mcp (MCP adapter)
cargo test                   # 30 tests: tamper, replay, crash, redaction, leases...
```

## 60-second walkthrough

```sh
B=./target/release/xrec
$B agent register --id anthropic:cli:mac-1 --vendor anthropic --class execute \
    --capability code --capability git_push
$B agent register --id runtime:daemon:mac-1 --vendor local --class host --capability observe
$B issue --id INST-20261105-0001 --by founder --surface telegram \
    --expect "push fix to argon-sync" --class ops.git --target-capability git_push
# -> INST-20261105-0001 token=1
RID=$($B open --instruction INST-20261105-0001 --token 1 --agent anthropic:cli:mac-1)
$B event --record $RID --kind self_report --actor agent --action claim_pushed \
    --payload '{"commit":"da1536c"}' --agent anthropic:cli:mac-1 --surface execute
$B event --record $RID --kind verified_system --actor daemon --action git_rev_parse \
    --payload '{"rev":"da1536c"}' --agent runtime:daemon:mac-1 --surface host
$B close --record $RID --status success --summary "pushed; daemon verified rev"
$B verify          # OK: N records, M events, head sha256:…
$B render --record $RID --out record.md
```

Try to cheat: close with only the self-report → refused. Re-token → refused.
Edit the DB → `verify` names the broken link.

## Mounting surfaces

**Claude Code / Codex / Kimi CLI** (any MCP client), e.g. `.mcp.json`:

```json
{"mcpServers": {"xrec": {
  "command": "/usr/local/bin/xrec-mcp",
  "env": {"XREC_DB": "/opt/estate/xrec.db"}
}}}
```

Tools exposed: `xrec_issue`, `xrec_open`, `xrec_event`, `xrec_close`,
`xrec_verify`, `xrec_dangling`, `xrec_render`, `xrec_agents`.

**Web chats (Gemini/DeepSeek/AI Studio):** CONSULT class — they receive a
signed paste-block envelope and answer in schema; the hub validates and records.
Never execution. See MULTI-SURFACE-v0.2 §2.

**Telegram:** approvals and instructions enter as `human`/`govern` events via
the bot middleware calling the same library.

## Layout

```
spec/    format + multi-surface specs (the contract)
src/     lib: canonical, crypto, redact, schema, store, render
src/bin/xrec-mcp.rs   MCP stdio adapter
tests/   integration battery — every failure mode in spec §6
```

License: Apache-2.0. Dependencies: rusqlite (bundled SQLite), serde, sha2, hmac,
clap, thiserror, regex, chrono — all permissively licensed open source.
