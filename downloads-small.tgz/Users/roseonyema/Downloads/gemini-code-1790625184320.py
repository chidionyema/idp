# --- CURRENT (BROKEN) PATTERN ---
try:
    from pobr.missing_gate import evaluate_receipt  # Importerror silently swallowed or unhandled
except ImportError:
    pass

def handle_admit(receipt_path):
    # Missing verification step
    return {"status": "ok"}  # Bypasses gating entirely