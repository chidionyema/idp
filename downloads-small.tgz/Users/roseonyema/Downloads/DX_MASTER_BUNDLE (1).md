# DIAGNOSTIC PACKAGE — MASTER BUNDLE (2026-11-09)
One file: vision, architecture, constraints, all trial numbers, experiment designs, reproducibility.

---

## 1. Product definition
Commercial-grade, stack-agnostic agent diagnostics: seamlessly re-measure/debug all aspects of live infra, any stack, read-only by default, acquisition-grade quality.

### Binding constraints (founder, 2026-11-09)
1. **Rust-first, greenfield** — legacy stack is NOT a design constraint
2. **Enforcement by substrate, not prompting** — controller is deterministic code; skills are probe libraries the runtime loads; LLM only maps unstructured outputs into evidence schema (no random walk)
3. **Non-blocking** — no polling loops or blocking commands that make agents unresponsive to founder steers
4. **Visibility** — typed probe events → thin-event spine; Prometheus-compatible metrics; founder-surface plugin contract (war room/CLI/WeChat: live progress, verdicts, cost burn, steering injection)
5. **Scientific method** — hypotheses, controlled trials, real numbers, published reports
6. **Machine-time** — estimates in hours
7. Read-only by default; every check = stable id, severity, verdict, evidence, remediation hint

---

## 2. Architecture
Single contract — everything is a typed PROBE:
```
Probe { id, target_selector, preconditions, cost_model, discriminates:[H...],
        run()->Evidence, evidence_schema, remediation_hint }
```
- Skills = probe libraries (docker, TLS, backups, OCI, systemd...); new stack = new probes, zero controller changes
- Controller = VoI policy over explicit belief state (hypothesis graph + posteriors)
- Termination = class-posterior ≥0.95 AND evidence-backed (prior-only victory banned; HEALTHY requires every fault class actively suppressed below risk floor EPS=0.002)
- Dual-space governance (unexplained observations spawn new hypotheses — SHELDON)
- Adversarial-feedback layer (evidence provenance + channel-trust)
- Fault-signature memory (symptom vector → confirmed fault → remediation → outcome; calibrates priors; commercial dataset)

---

## 3. Trial numbers (sandbox, reproducible)

### v2 — ladder strategies, 5 targets × 30 trials, 62 faults
- A exhaustive: 19.83±3.2 probes, 913.1ms mean wall, det 62/62, FP 0
- B map→reduce→probe: 20.4±2.81 probes, 859.8ms, det 62/62, FP 0
- Finding: B probe savings −2.9% (refuted), wall −5.8%; static ordering has a regime boundary

### v3 — 10 targets × 10 trials, 21 faults
- A: 45.1 probes, 1497.5ms · B: 45.5 probes, 1374.7ms · det 21/21 both, FP 0 both
- Wall advantage of parallel map confirmed (−8.2%)

### v4 — VoI controller (C) vs fixed ladders (A/B), 3 regimes × 15 trials, 48 faults
| Regime | A cost/wall | B cost/wall | C cost/wall | C det | C FP | C ECE |
|---|---|---|---|---|---|---|
| R1 healthy cheap | 86.8 / 223.0ms | 87.1 / 124.0ms | **86.8 / 56.0ms** | 8/8 | 0 | 0.0009 |
| R2 sick cheap | 81.5 / 667.0ms | 82.4 / 562.0ms | 115.6 / 908.0ms | 32/32 | 0 | 0.0011 |
| R3 sick expensive | 388.7 / 666.0ms | 389.6 / 558.0ms | 730 / 908.0ms | 32/32 | 0 | 0.0011 |

- C: det 48/48, FP 0 everywhere, ECE ≤0.0011 (bar was 0.05), R1 wall −54.8% vs best
- C cost: +0.0% R1, **+41.8% R2, +87.8% R3** — with sharp deterministic probes the fixed ladder is near-optimal; VoI pays for its own stochastic caution (degraded confirmation needs repeated samples at likelihood 0.9)
- Three controller bugs found & fixed en route (wrong termination event; prior-only victory; sequential wall artifact) — full record in REPORT_2.md

### Steer-injection trial (non-blocking proof), n=20
- Steer fired at random mid-sweep moments → preemption latency mean 19.678042900000037ms, max 39.10019899990402ms (slice budget 300ms)
- Agent never unresponsive: preemption = current slice finishes

---

## 4. Experiment designs queued

### v5 — regimes where VoI value binds (2h)
- V5a NOISY PROBES: latency jitter; prediction: A/B single-sample thresholds accumulate FPs, C posterior gating stays ~0
- V5b SIGNATURE MEMORY: lopsided priors from fault-signature store; prediction: C cost −20%+
- V5c REDUNDANT EXPENSIVE: cost-40 probe duplicating cheap info; prediction: A pays, C skips
- Acceptance: accuracy ≥ best(A,B) all regimes; cost −20% in V5b/c; ECE <0.02; 15 trials/regime

### v6 — steering under load
- Full sweep + steer storm (10 steers/s); measure preemption p99, dropped-steer count (target: 0)

---

## 5. Research base
MAP (map-before-act; 22/25 ARC-AGI-3) · Model-First Reasoning · A-MapReduce · SCULPT (constraint-pruned MCTS; ~70% space eliminated per constraint) · SSDP (85–90% node reduction) · AID hypothesis-grounded probing (89% resolved ≤2 probes) · SHELDON dual-space (+26.7pts, 4.5× novel solutions) · Fleet of Agents (~35% of SOTA cost) · VoI policy layer
Open problems carried into design: mapping cost budget, learned constraints, corrupted-feedback robustness, premature-reduction safeguard.

---

## 6. Reproduce
```
python3 mock_service.py <port> <name> <statedir>   # ×5 (ports 9101–9105)
# write state_<port>.json: {"mode":"ok|http500|corrupt|degraded"} to inject; kill process for crash
# harness + controllers: session notebook; raw JSON: trial_results_v2/v3/v4d_controller.json, steer_trial.json
```

## 7. Roadmap (hours)
- v5 trials: 2h → controller hardened: 2h → Rust single-binary port + adapters (docker/systemd/OCI/TLS/backups): 8–12h (needs cargo) → live estate run: 2h → commercial report format: 2h

---
Reports: REPORT_1.md (v2/v3), REPORT_2.md (v4 + failure analysis + v5 design) · Raw: dx_lab/*.json
