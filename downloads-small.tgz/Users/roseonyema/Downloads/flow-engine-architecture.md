# THE FLOW ENGINE — architecture (v1, technical-lead draft)

Status: design for founder review. Not a deployment order. Every claim carries a provenance
status per the dossier discipline (DECLARED / SOURCE_EXISTS / DEPLOYED / EFFECT_VERIFIED).
Date: 2026-11-09.

## 0. The concept

One engine. Any surface in, any agent inside, verified yield out.

- **FLOW Engine** = the spine. It owns exactly one aggregate — the **Instruction** — and a
refinement pipeline that carries it from raw words to externally-verified operational effect.
- **Legion** = the workforce plane. Any admitted agent can serve as **commander** (executes the
plan node itself) or as **legionary** (one unit in a dispatched formation). Formations are
data, declared per plan node.
- **The Tree of Life is the pipeline.** Founder vision enters at Keter (crown). Each sefirah is
a typed artifact + a gate. Nothing reaches Malkuth (operational reality) except through
every gate. The metaphor is load-bearing, not decorative: it is the literal stage list.

## 1. Non-negotiable principles (inherited from the dossier)

1. **One aggregate.** The Instruction is event-sourced: append-only, hash-chained, replayable.
Every projection (UI, dashboard, Telegram summary, agent context) is a *view* of the event
stream. Never the other way round. (Kills F05/F11: catalogue≠state, probe≠goal.)
2. **Statuses never collapse.** DECLARED / SOURCE_EXISTS / CI_PASS / REVIEWED / DEPLOYED /
REACHABLE / EFFECT_VERIFIED / STALE / UNKNOWN / BLIND / BLOCKED / RETIRED are a typed enum
on every receipt. "Done" is a composition of specific receipts, never a flag.
3. **No new stack without measured comparison.** Reuse NATS, Temporal, Greenlane, claim-gate,
Hermes, Argon, estate-graph, pennyd, Rego. Build thin runners and schemas. Retire dupes.
4. **The founder is never the message bus.** Instruction intake is durable at ingress; recovery
is machine-owned and bounded; the 600s productive-stagnation invariant is law.
5. **Every model call flows through pennyd.** Economics and attribution are consequences of
topology, not discipline.

## 2. The Sefirot pipeline (stages = typed artifacts + gates)

| # | Sefirah | Artifact produced | Gate (who/what verifies) | Model class |
| --- | --- | --- | --- | --- |
| 1 | KETER | `instruction.json` — origin signature, raw text, chronology, principal | schema + origin auth | none |
| 2 | CHOKMAH | `clarification.json` — bounded Q&A rounds (≤3) until intent unambiguous | ambiguity score below threshold | cheapest (triage alias) |
| 3 | BINAH | `spec.md` — typed spec: goals, non-goals, constraints, interfaces | spec lint + plan-mode review | cheap-chat |
| 4 | CHESED | `acceptance.bdd` — Gherkin scenarios, machine-executable | scenarios parse + cover every spec goal | cheap-chat |
| 5 | GEVURAH | `authorization.json` — budget, risk class, policy decision (Rego), human-decision points | DoF/policy engine + founder tap for high-risk | none (deterministic) |
| 6 | TIFERET | `plan.json` — task tree, formation per node, owners, leases, deps, verify cmd | plan validator + impact vs topology | mid (reasoning) |
| 7 | NETZACH | `execution` — Legion formation runs on Temporal | per-node BDD + receipts | per-alias routing |
| 8 | HOD | `verification.json` — independent verifier identity, evidence hashes | verifier ≠ author (enforced) | judge pattern |
| 9 | YESOD | `deployment.json` — exact source→image→digest→route chain | GitOps readback ≠ desired | none |
| 10 | MALKUTH | `yield.json` — external effect evidence + secondary gains (friction removed, cost delta, class corrections) | effect prober + human spot-check for P0 journeys | none |

Rules:

- A stage may **fail forward** only into a truthful state: BLOCKED (reason, owner, retry bound),
NEEDS_HUMAN (question routed to founder surface), or RECOVERY_PENDING. Never silent.
- Stage transitions are pure artifact→artifact transforms; every artifact is content-hashed and
committed to git (source of truth) with its receipt in the event log.
- Clarification is mandatory for vague input (Chokmah) — this is where "feed it any prompt,
even vague" becomes mechanical instead of hopeful.

## 3. Legion — formations as data

Formation is a property of a plan node. Research consensus: prefer code-driven flow when the
shape is known; pay for a director model only when the breakdown depends on the input.

| Formation | Semantics | Use when | State rule |
| --- | --- | --- | --- |
| SOLO | Commander executes the node itself | task fits one context, single owner | full task context |
| PIPELINE | fixed sequence, output→input | known stages | previous output only |
| PARALLEL/FORK-JOIN | shards, join via reducer | independent subtasks, merge needed | shard sees its brief; joiner sees all |
| SWARM (best-of-N) | N independent attempts, judge picks | correctness-critical, cheap shards | task only, no peer view |
| SUPERVISOR | director decomposes at runtime, reviews returns | shape depends on input | workers see director's brief |
| ROUND TABLE | group conversation, shared transcript | design/debate, cross-surface collaboration | full transcript |

Enforcement of the research failure classes:

- Fan-out cap + per-worker token ceilings (pennyd keys per legionary class).
- Empty-step detector: a formation whose node returns no artifact fails loudly (checked_turns).
- Director failures degrade to PIPELINE of the same workers (deterministic fallback).
- Handoffs carry full provenance (who handed to whom, instruction_id, lease epoch).

## 4. Layers

- **L0 Event spine** — NATS JetStream (existing) as transport; event store = append-only
hash-chained log (pennyd decision-log construction, generalised). The Instruction aggregate
lives here. Projections: Argon UI, Telegram digest, agent context packs, dashboards.
- **L1 Ingress plane** — universal intake contract: every adapter emits `InstructionReceived`
with origin signature. Adapters: Hermes/Telegram (existing), Argon web+voice (existing),
CLI, email, and **relay adapters** for opaque SaaS agents (Gemini/ChatGPT/Z.ai web): bounded
intake via shared-drive relay (existing observatory pattern) + write-back with explicit
capability labels (COM-06: known disconnection, never silent absence). Outbox at ingress;
instruction survives surface death.
- **L2 Refinement engine** — the Sefirot runners. Thin: each runner is deterministic code that
(a) validates the previous artifact, (b) calls a model via pennyd when needed, (c) validates
the next artifact, (d) appends receipts. No orchestration framework; the pipeline IS a saga
(orchestrated, Temporal — existing).
- **L3 Legion plane** — Temporal workflows (existing) execute plan trees; claim-gate + leases
with fencing epochs (existing, extended with stale-writer rejection); capacity registry;
workers = any admitted agent per universal onboarding (idp#7794), patch-only by gate, not
by convention.
- **L4 Verification plane** — BDD execution, deployment readback (source→image→digest→route),
effect probers. Provenance enum enforced at this layer and nowhere else.
- **L5 Surfaces** — Argon Founder Surface = the founder's war room; Telegram = mobile
command; both are projections of L0.
- **L6 Governance** — policy-as-data (Rego, existing), 600s stagnation detector, per-key waste
breakers, DoF with a lawful emergency path (the idp#7800 recursion class must be impossible
by construction: repair path pre-authorized and separately scoped).
- **L7 Economics** — pennyd mandatory for all model traffic; per-instruction cost attribution
via request→instruction_id binding; proof protocol (ADOPTION.md) governs every optimization.

## 5. The Round Table (real-time, cross-surface)

- Per-instruction **war room**: a CRDT shared document (Yjs class) over WebSocket/SSE — Argon's
existing SSE hub is the transport. Humans and agents are both principals; every mutation also
appends to the event log (CRDT = fast path, log = truth; divergence alarm on mismatch).
- **Conversation mining**: every adapter normalizes messages into the event log; a projection
feeds estate-graph. Founder correction in ANY surface becomes a superseding event with
temporal provenance (CTX-04); later sessions see corrections, not archaeology.
- Voice/phone/CLI/desktop all render the same war room; surface-specific adapters only.

## 6. Failure-mode map (dossier §7 classes → design response)

| Class | Example | Design response |
| --- | --- | --- |
| F01 typed work unit missing | YAML intents failed | Instruction + plan.json + receipts = the typed unit; crossing vendors via universal admission |
| F03 false-green router | green probe, wrong lane | Provenance enum on every receipt; prober bound to instruction, not to lane health |
| F05 many truths | catalogue vs live | Single event-sourced aggregate; all surfaces projections |
| F06 transport≠conversation | NATS ACK ≠ applied | Receipt requires application evidence; COM-03 simulated in acceptance suite |
| F07 gate paralysis | DoF self-denial | Pre-scoped repair authority; policy conflicts surface as NEEDS_HUMAN with lawful path |
| F08 worker not real | Legion manifest only | D7 acceptance: off-host mission with kill+takeover fencing |
| F11 probe≠goal | drill success, 14 down | Effect verification at Malkuth only; probes graded separately and visibly |
| F12 agent thrash | rescan loops, no yield | pennyd waste breakers + 600s invariant + cost-per-yield metric |

## 7. Reuse / build / retire (initial, to be validated by measurement)

- **Reuse**: NATS JetStream, Temporal, Greenlane, claim-gate, Hermes, Argon surface + SSE,
estate-graph, pennyd, Rego gates, SigNoz/Langfuse.
- **Build (thin)**: instruction envelope + artifact schemas; sefirot runners; stagnation
detector; CRDT war room; relay adapters; effect probers; provenance enum plumbing.
- **Retire/consolidate**: Git peer-bus candidate (closed PRs — NATS wins); handwritten YAML
intent library (ruled out in idp#7794); parallel memory stores → one event-sourced
projection; any dashboard not fed by L0.

## 8. Delivery — smallest measurable vertical slice first (D7)

**Slice 1 (acceptance demo)**: founder issues vague instruction from Telegram → Chokmah
clarification (1 round) → Binah spec → Chesed BDD (3 scenarios) → Gevurah auto-authorized →
Tiferet plan (SOLO node) → Netzach: one off-host legionary executes → PR → Greenlane → deploy
to staging → Hod: independent verifier runs BDD → Yesod: digest readback → Malkuth: effect
probe passes → founder sees full causal chain in Argon. **Injected failure**: legionary killed
mid-task; lease expires at 600s; successor resumes from checkpoint with fencing; no duplicate
side effect. Cost attributable to the instruction in pennyd.

**Phases** (order = dependency, all slices independently demonstrable):

0. Event spine + instruction envelope — ~40h
1. Ingress normalization (Telegram + Argon) — ~30h
2. Sefirot 1–6 (refinement to plan) — ~60h
3. Legion on Temporal + formations + fencing — ~70h
4. Verification plane + provenance enum — ~40h
5. War room CRDT + conversation mining — ~50h
6. Chaos suite + acceptance scenarios (dossier §11) — ~60h

## 9. Open decisions for the founder

1. Effect prober hosting: extend Pi/node pool vs small always-on ARM box (cost approval per
governance mandate).
2. War room CRDT library choice (Yjs vs Automerge) — decide at Phase 5 with a spike.
3. Whether Malkuth human spot-check is required for every P0 journey or sampled.
4. Round Table participation policy: which agent classes may speak unprompted (anti-noise).