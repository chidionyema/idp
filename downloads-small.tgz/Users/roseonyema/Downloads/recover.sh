#!/usr/bin/env bash
# recover.sh v2 - generated from recover-agent-work.yaml. Non-destructive: no reset/clean/delete/force-push. Pushes only to private repos.
set -u
mkdir -p "$HOME/claude-forensics"
echo; echo "=== 1. discover ==="; (
python3 - <<'PY'
import json,glob,os,collections,datetime
h=os.path.expanduser('~')
rows=[]
for p in glob.glob(h+'/.cline/data/sessions/*/*.json'):
    if p.endswith('.messages.json'): continue
    try: d=json.load(open(p))
    except Exception: continue
    rows.append((d.get('started_at',''),d.get('session_id'),d.get('status'),d.get('model'),d.get('cwd'),(d.get('prompt') or '')[:90].replace('\n',' ')))
rows.sort()
print('cline sessions:',len(rows),collections.Counter(r[2] for r in rows))
for r in rows[-20:]: print(' ',r[0][11:16],r[1],r[2],r[3],'|',r[5])
pi=glob.glob(h+'/.pi/agent/sessions/*/*.jsonl')
pi.sort(key=os.path.getmtime)
print('pi sessions:',len(pi))
for f in pi[-8:]:
    print(' ',datetime.datetime.fromtimestamp(os.path.getmtime(f)).strftime('%m-%d %H:%M'),round(os.path.getsize(f)/1e6,1),'MB',os.path.basename(f)[:60])
PY
) 2>&1 | tee -a "$HOME/claude-forensics/recover-v2.log"
echo; echo "=== 2. snapshot-agent-state ==="; (
OUT="$HOME/claude-forensics/recovery-$(date +%Y%m%d)"; mkdir -p "$OUT/cline" "$OUT/pi" "$OUT/tmp"
cp -Rn "$HOME/.cline/data/sessions" "$OUT/cline/" 2>/dev/null
for f in sessions.db sessions.db-wal teams.db cron.db cron.db-wal; do cp -n "$HOME/.cline/data/db/$f" "$OUT/cline/" 2>/dev/null; done
cp -n "$HOME/.cline/data/logs/cline.log" "$HOME/.cline/data/logs/hub-daemon.log" "$OUT/cline/" 2>/dev/null
cp -Rn "$HOME/.pi/agent/sessions" "$HOME/.pi/agent/state" "$OUT/pi/" 2>/dev/null
cp -Rn /private/tmp/claude-501 "$OUT/tmp/" 2>/dev/null
mkdir -p "$OUT/estate"; cp -Rn "$HOME/.estate/intents" "$OUT/estate/" 2>/dev/null
      echo "snapshot at $OUT"; du -sh "$OUT"
) 2>&1 | tee -a "$HOME/claude-forensics/recover-v2.log"
echo; echo "=== 3. pin-cline-checkpoints ==="; (
python3 - <<'PY'
import json,glob,os,subprocess
h=os.path.expanduser('~')
n=ok=miss=0
for p in glob.glob(h+'/.cline/data/sessions/*/*.json'):
    if p.endswith('.messages.json'): continue
    try: d=json.load(open(p))
    except Exception: continue
    cwd=d.get('cwd'); cp=(d.get('metadata') or {}).get('checkpoint') or {}
    refs=[x.get('ref') for x in cp.get('history',[])]+[(cp.get('latest') or {}).get('ref')]
    for i,r in enumerate(dict.fromkeys(x for x in refs if x),1):
        n+=1
        if cwd and subprocess.run(['git','-C',cwd,'cat-file','-e',r+'^{commit}'],capture_output=True).returncode==0:
            subprocess.run(['git','-C',cwd,'update-ref','refs/recovery/cline/%s-%d'%(d['session_id'],i),r]); ok+=1
        else:
            miss+=1; print('MISSING',d.get('session_id'),i,r[:10])
print('checkpoints',n,'pinned',ok,'missing',miss)
PY
) 2>&1 | tee -a "$HOME/claude-forensics/recover-v2.log"
echo; echo "=== 4. commit-dirty-worktrees ==="; (
TS=$(date +%Y%m%d); OUT="$HOME/claude-forensics/recovery-$TS"; mkdir -p "$OUT"
EXCL=(':(exclude).env*' ':(exclude)*.pem' ':(exclude)*.key' ':(exclude)*secret*' ':(exclude)node_modules')
roots=$(python3 -c "
import json,glob,os
s=set()
for p in glob.glob(os.path.expanduser('~/.cline/data/sessions/*/*.json')):
    if p.endswith('.messages.json'): continue
    try: s.add(json.load(open(p)).get('cwd') or '')
    except Exception: pass
print('\n'.join(x for x in s if x))")
{ for r in $roots; do git -C "$r" worktree list --porcelain 2>/dev/null | awk '/^worktree /{print $2}'; done; ls -d "$HOME"/.estate/worktrees/* /private/tmp/idp-* "$HOME"/Documents/code/.lanes/*/ 2>/dev/null; } | sed 's#/$##' | sort -u | while read -r d; do
        [ -e "$d/.git" ] || continue
  [ -d "$d" ] || continue
  cd "$d" || continue; name=$(basename "$d")
  if [ -z "$(git status --porcelain 2>/dev/null)" ]; then echo "clean   $name"; continue; fi
  cur=$(git rev-parse --abbrev-ref HEAD); br="recovery/${name}-${TS}"
  git diff HEAD > "$OUT/${name}.diff.patch" 2>/dev/null
  git checkout -b "$br" >/dev/null 2>&1 || git checkout "$br" >/dev/null 2>&1 || { echo "could not branch $name; patch saved"; continue; }
  git add -A -- . "${EXCL[@]}" >/dev/null 2>&1
  git -c user.name=recovery -c user.email=recovery@local commit -q -m "recovery: WIP from $cur at $TS" && echo "COMMITTED $name on $br (from $cur)" || echo "nothing committed $name"
done
) 2>&1 | tee -a "$HOME/claude-forensics/recover-v2.log"
echo; echo "=== 5. push-private-only ==="; (
roots=$(python3 -c "
import json,glob,os
s=set()
for p in glob.glob(os.path.expanduser('~/.cline/data/sessions/*/*.json')):
    if p.endswith('.messages.json'): continue
    try: s.add(json.load(open(p)).get('cwd') or '')
    except Exception: pass
print('\n'.join(x for x in s if x))")
for r in $roots; do
  cd "$r" || continue
  if [ "$(gh repo view --json isPrivate -q .isPrivate 2>/dev/null)" = "true" ]; then
    git push origin 'refs/recovery/*:refs/recovery/*' 2>&1 | tail -2
    for b in $(git for-each-ref --format='%(refname:short)' 'refs/heads/recovery/*'); do git push -u origin "$b" 2>&1 | tail -1; done
  else
    echo "NOT PUSHED $r (repo not confirmed private; recovery refs and branches are local only)"
  fi
done
) 2>&1 | tee -a "$HOME/claude-forensics/recover-v2.log"
echo; echo "=== 6. report ==="; (
ls -1 "$HOME/claude-forensics/recovery-$(date +%Y%m%d)" && echo "recovery refs:" && git -C "$HOME/Documents/code/idp" for-each-ref --count=60 'refs/recovery/*' 'refs/heads/recovery/*' --format='%(refname:short) %(objectname:short)'
) 2>&1 | tee -a "$HOME/claude-forensics/recover-v2.log"
