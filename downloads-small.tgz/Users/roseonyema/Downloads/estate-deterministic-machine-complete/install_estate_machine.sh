#!/usr/bin/env bash
set -euo pipefail
# install_estate_machine.sh
# Complete One-Command Local Cutover for chidionyema/idp

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_REPO="${1:-$(pwd)}"

echo "=================================================================="
echo " INSTALLING ESTATE DETERMINISTIC MACHINE INTO: ${TARGET_REPO}"
echo "=================================================================="

echo "[1/6] Evicting background agent daemons & locking Chrome remote debugging port..."
pkill -9 -f "claude|codex|opencode|legion-run|chronos|otto_real_core|genesis-mycelium" 2>/dev/null || true
defaults write com.google.Chrome RemoteDebuggingPort -int 0 2>/dev/null || true

echo "[2/6] Deleting hallucination-generating Pi extensions (read-shunt, epistemic-firewall, 00-shift-left, pi-governance)..."
rm -f "${TARGET_REPO}/extensions/read-shunt.ts" \
      "${TARGET_REPO}/extensions/epistemic-firewall-hook.ts" \
      "${TARGET_REPO}/extensions/00-shift-left-enforcer.ts"
rm -rf "${TARGET_REPO}/extensions/pi-governance"

echo "[3/6] Installing Founder Catalog, GBNF Grammar, Estate Machine, and Subsystem Gates..."
mkdir -p "${TARGET_REPO}/catalog" \
         "${TARGET_REPO}/schemas" \
         "${TARGET_REPO}/bin" \
         "${TARGET_REPO}/extensions/active-focus-memory" \
         "${TARGET_REPO}/.githooks"

cp -f "${SCRIPT_DIR}/catalog/founder-catalog.yaml" "${TARGET_REPO}/catalog/founder-catalog.yaml"
cp -f "${SCRIPT_DIR}/schemas/worker_slot.gbnf" "${TARGET_REPO}/schemas/worker_slot.gbnf"
cp -f "${SCRIPT_DIR}/bin/estate_machine.py" "${TARGET_REPO}/bin/estate_machine.py"
cp -f "${SCRIPT_DIR}/extensions/active-focus-memory/index.ts" "${TARGET_REPO}/extensions/active-focus-memory/index.ts"
cp -f "${SCRIPT_DIR}/.githooks/pre-commit" "${TARGET_REPO}/.githooks/pre-commit"
cp -f "${SCRIPT_DIR}/.githooks/pre-push" "${TARGET_REPO}/.githooks/pre-push"

chmod +x "${TARGET_REPO}/bin/estate_machine.py" \
         "${TARGET_REPO}/.githooks/pre-commit" \
         "${TARGET_REPO}/.githooks/pre-push"

if git -C "${TARGET_REPO}" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git -C "${TARGET_REPO}" config core.hooksPath .githooks
fi

echo "[4/6] Removing dead .github/workflows/oke-check.yml workflow..."
rm -f "${TARGET_REPO}/.github/workflows/oke-check.yml"

echo "[5/6] Isolating clean commit 6ed3d165 (dropping Breach B2 commit 937dda9d) if present in git..."
if git -C "${TARGET_REPO}" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  if git -C "${TARGET_REPO}" cat-file -e 6ed3d165^{commit} 2>/dev/null; then
    echo "Verified commit 6ed3d165 exists locally; ready for clean cherry-pick onto main."
  fi
fi

echo "[6/6] Running Estate Deterministic Machine self-test..."
python3 "${TARGET_REPO}/bin/estate_machine.py" self-test
echo "=================================================================="
echo " DONE: Estate Machine installed and verified GREEN."
echo "=================================================================="
