#!/usr/bin/env bash
# Live end-to-end smoke of a real Tempo node process (port of tools/smoke_e2e.py).
#
# Proves, against actual subprocesses and HTTP:
#   1. First run writes a starter config and exits cleanly.
#   2. Boot: server serves /healthz, /state.
#   3. Signed ingest (HMAC over canonical body) accepted; state derives alive.
#   4. Replay of the same signed event -> 409; signature reuse -> 401.
#   5. Tampered log -> boot REFUSED (nonzero exit, forensics on stderr).
#   6. Restore from a byte-identical backup -> boots clean again.
#
# Run:  ./tools/smoke_e2e.sh   (exit 0 = PASS)
# Requires: cargo (to build if needed), curl, openssl, python3 (canonical JSON).
set -euo pipefail
cd "$(dirname "$0")/.."

PORT=${SMOKE_PORT:-8130}
BASE="http://127.0.0.1:${PORT}"
TMP=$(mktemp -d)
PROC=""
trap 'if [ -n "$PROC" ]; then kill "$PROC" 2>/dev/null || true; fi; rm -rf "$TMP"' EXIT

PASS=0; FAIL=0
check() { # name, cond(0/1), detail
  if [ "$2" = "0" ]; then PASS=$((PASS+1)); echo "PASS  $1";
  else FAIL=$((FAIL+1)); echo "FAIL  $1 ${3:+[$3]}"; fi
}

# Build once (debug is enough for the smoke; release is for deployment).
TARGET_DIR="${CARGO_TARGET_DIR:-$PWD/target}"
if [ ! -x "$TARGET_DIR/debug/tempo" ] && [ ! -x "$TARGET_DIR/release/tempo" ]; then
  cargo build -p tempo-server >/dev/null
fi
if [ -x "$TARGET_DIR/release/tempo" ]; then BIN="$TARGET_DIR/release/tempo"; else BIN="$TARGET_DIR/debug/tempo"; fi
echo "smoke: using $BIN"

CFG="$TMP/estate.json"
LOG="$TMP/events.jsonl"

# 1. first run: config generation
"$BIN" --config "$CFG" >/dev/null 2>&1 || true
[ -f "$CFG" ]; check "first-run config generated" $? "$(head -c 200 "$CFG" 2>/dev/null)"
python3 - "$CFG" "$PORT" "$TMP" <<'PY'
import json, sys
cfg_path, port, tmp = sys.argv[1], int(sys.argv[2]), sys.argv[3]
cfg = json.load(open(cfg_path))
cfg["server"] = {"host": "127.0.0.1", "port": port}
cfg["log_path"] = f"{tmp}/events.jsonl"
json.dump(cfg, open(cfg_path, "w"))
PY
KEY=$(python3 -c "import json;print(json.load(open('$CFG'))['device_keys']['bangle2'])")

wait_health() {
  for _ in $(seq 1 100); do
    kill -0 "${PROC:-0}" 2>/dev/null || return 1
    if curl -s -m 1 "$BASE/healthz" | grep -q '"ok":true'; then return 0; fi
    sleep 0.2
  done
  return 1
}

# 2. boot + health
"$BIN" --config "$CFG" --host 127.0.0.1 --port "$PORT" >/dev/null 2>&1 &
PROC=$!
wait_health; check "server boots and reports healthy" $?

curl -s "$BASE/state" | grep -q '"state":"unknown"'
check "state endpoint alive snapshot" $?

# 3. signed ingest
BODY=$(python3 - "$KEY" <<'PY'
import json, sys
key = sys.argv[1]
ev = {
    "schema": "tempo.event.v1", "principal_id": "alice", "channel": "body_primary",
    "signal": "heart_rate", "value": 72, "unit": "bpm",
    "ts": "2026-11-09T10:00:00.000Z", "seq": 1, "confidence": 1.0,
    "purpose": "health", "device_id": "bangle2",
}
canon = json.dumps(ev, sort_keys=True, separators=(",", ":"))
print(json.dumps({"body": canon, "sig": __import__("hmac").new(key.encode(), canon.encode(), __import__("hashlib").sha256).hexdigest()}))
PY
)
EVENT=$(python3 -c "import json,sys;print(json.loads(sys.argv[1])['body'])" "$BODY")
SIG=$(python3 -c "import json,sys;print(json.loads(sys.argv[1])['sig'])" "$BODY")

RESP=$(curl -s -w "\n%{http_code}" -X POST "$BASE/ingest" \
  -H "Content-Type: application/json" -H "X-Tempo-Device: bangle2" -H "X-Tempo-Sig: $SIG" \
  --data-binary "$EVENT")
CODE=$(echo "$RESP" | tail -1); DATA=$(echo "$RESP" | head -1)
[ "$CODE" = "200" ] && echo "$DATA" | grep -q '"ok":true'
check "signed ingest accepted" $? "$RESP"

curl -s "$BASE/state" | grep -q '"state":"alive"'
check "state derives alive from signed ingest" $?

# signature reuse on a different event -> 401
EVENT2=${EVENT/\"seq\":1/\"seq\":2}
CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/ingest" \
  -H "Content-Type: application/json" -H "X-Tempo-Device: bangle2" -H "X-Tempo-Sig: $SIG" \
  --data-binary "$EVENT2")
[ "$CODE" = "401" ]; check "signature reuse rejected" $? "got $CODE"

# 4. exact replay -> 409
CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/ingest" \
  -H "Content-Type: application/json" -H "X-Tempo-Device: bangle2" -H "X-Tempo-Sig: $SIG" \
  --data-binary "$EVENT")
[ "$CODE" = "409" ]; check "event replay rejected 409" $? "got $CODE"

# backup while healthy (runbook step)
cp "$LOG" "$TMP/backup.jsonl"
kill "$PROC" 2>/dev/null; [ -n "$PROC" ] && wait "$PROC" 2>/dev/null || true; PROC=""

# 5. tamper -> boot refused
sed -i '0,/"value":72/s//"value":73/' "$LOG"
"$BIN" --config "$CFG" --verify-only > "$TMP/verify.out" 2> "$TMP/verify.err" || RC=$?
[ "${RC:-1}" != "0" ]
check "tampered log refuses boot" $?
grep -q "TEMPO BOOT REFUSED" "$TMP/verify.err" 2>/dev/null || grep -q "FAIL" "$TMP/verify.out"
check "forensics on stderr/stdout" $? "$(cat "$TMP/verify.err" "$TMP/verify.out" 2>/dev/null | head -1)"

# 6. restore -> boots clean
cp "$TMP/backup.jsonl" "$LOG"
"$BIN" --config "$CFG" --host 127.0.0.1 --port "$PORT" >/dev/null 2>&1 &
PROC=$!
wait_health; check "restored log boots clean" $?
SEQ=$(curl -s "$BASE/healthz" | python3 -c "import json,sys;print(json.load(sys.stdin).get('seq',0))")
[ "$SEQ" -ge 3 ]; check "chain continues after restore" $? "seq=$SEQ"

kill "$PROC" 2>/dev/null || true; [ -n "$PROC" ] && wait "$PROC" 2>/dev/null || true; PROC=""

echo
if [ "$FAIL" -gt 0 ]; then echo "SMOKE FAILED: $FAIL failing checks"; exit 1; fi
echo "SMOKE PASS: $PASS/$PASS checks green"
