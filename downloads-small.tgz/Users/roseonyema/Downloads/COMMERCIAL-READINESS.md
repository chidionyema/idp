# idp: what stands between it and a sellable product

Scope, so the weight is right: I read about forty files of the repo (AGENTS.md, README, the
enforcement and verifier specs, the epistemic and trajectory gates, `policy.py`, `fsm.py`, the
Definition of Done, the operating model, the EU AI Act memo). I could not run the repo on the Mac, so
nothing below is a measurement of the live system. Legal points are quoted from the repo's own memo,
which calls itself a draft for legal review; I have not checked them against the law.

## Already at a standard a buyer can see

- **Rules have gates, gates have fixtures.** README: "a rule that has no gate is not a rule here",
  each with a must-fail and a must-pass fixture. This is the strongest asset. Most vendors can't say it.
- **One of each layer** (AGENTS.md s6), with the measured reason: the estate built the same
  capability five to ten times.
- **Evidence over assertion** (s3), an audit trail of commit plus trace (IAT), scoped agent identity
  (SAI), a hash-chained signed receipt log (`sovereign/engine/receipts.py`), a verifier door with a
  Sigstore seal, break-glass with a TTL cap, an incident register.
- **Licence gate** and Apache-2.0, so "built to be sold" is checked, not claimed.
- **Honest limits in the code.** The epistemic gate says what it can't prove. Keep that habit; it
  is what a security reviewer trusts.

## Gaps a diligence reviewer hits first (largest risk first)

| # | Gap | Evidence | Fix |
|---|---|---|---|
| 1 | The laws are not in the repo | `docs/reference/laws-and-guards.md` and the AGENTS.md routing comment send you to `~/AGENTS-FULL.md`, a file in the founder's home | Move it into the repo; add a gate that no shipped doc names a `~/` path outside the repo |
| 2 | The enforcement summary page renders blank | The generated `laws-and-guards.md` says "The 0 laws", guards tree at `?`, 2 guard rows | The generator must exit non-zero on zero laws. A report that cannot fail is the thing AGENTS.md forbids |
| 3 | Founder-machine paths in the rules | AGENTS.md hardcodes `~/Documents/code/estate-graph`, `~/Documents/code/estate-secrets` and `ghcr.io/chidionyema/`, against its own no-hardcoding law (46) | Parameterise; extend `cloud-agnostic-gate` to catch account and path strings |
| 4 | Gate-status tables are hand-written and dated | DoD v2.1 lists bootstrap, demo, security-scan, coverage and latency gates as not existing on 2026-08-25 | Re-measure today and generate the table from CI, never by hand |
| 5 | Security suppressions are large | `.gitleaksignore` is 61 KB and `.trivyignore.yaml` 19 KB; each line is a finding someone silenced | Audit every entry; add an owner, a reason and an expiry; fail CI on an expired one |
| 6 | "Done" means the founder used it | DoD Gate 1 and the Solo Founder Amendment | Keep client-zero. Make the receipt a per-tenant acceptance receipt so a customer can issue one |
| 7 | Claims are found by English regex | `epistemic_firewall.py` `CLAIM_PATTERNS` match first-person English | Typed claims (the protocol patch) for structured agents; regex stays as backstop for free text |
| 8 | Claims aren't persisted or signed | `docs/tickets/2026-09-15-dod-v3-claim-graph.md`: scoped, not built | Do its steps 1 and 2 (`claims`, `verifications` in `catalog/estate.db`) |
| 9 | Single-machine assumptions | Transcripts in `~/.pi` and `~/.claude`, ledger in `~/.estate`, pf egress lock, Mac CPU thresholds | Multi-tenant isolation tests before any hosted offer; `capability.yaml` annotates `tenant_isolated`, I saw no test of it |
| 10 | Docs and gates drift | The epistemic spec names fixture `three-readings-one-source`; the repo has `one-source-three-times`. README says AGENTS.md holds the rules table; it doesn't | A gate that every file path and fixture a spec names exists |
| 11 | Legal position unreviewed | The EU AI Act memo says AI literacy (Art. 4) had "nothing done, 18 months overdue" on 2026-08-25 | Counsel reviews the memo; record the current state of Art. 4 and Art. 50 |

## The sellable verifiers the founder already asked for

The claim-graph ticket names four verifiers with no schema anywhere: sellable, installable-fast,
procurement-passable, owned. First-cut criteria, each graded by something the repo already measures:

- **sellable:** a person who is not the founder completes one defined end-to-end job on a clean
  machine from the docs alone; licence gate green; no `~/` or account strings in shipped files (gaps 1, 3).
- **installable-fast:** `bin/estate-bootstrap` on a clean machine in under 5 minutes, the DoD's own bar.
- **procurement-passable:** one generated evidence pack: SBOM and image signatures, High+ vulnerability
  count (DoD asks 0), suppression audit (gap 5), egress allow-list, model-provider list, EU AI Act
  classification memo with a review date, incident register.
- **owned:** no dependency whose licence blocks a sale, and nothing that only works under the
  founder's accounts or tenancy.

These are proposals for you to edit, not agreed criteria.

## Order, smallest first

1. Gaps 2 and 1 (the blank page, the home-dir file): hours.
2. Gap 4, then 5, then 3: re-measure, audit, parameterise.
3. Land the protocol patch in `observe`, publish its gate events to `/fleet`, read a week of decisions.
4. Gap 8 (claims tables), then the four verifiers.
5. Gap 11 with counsel; gap 9 before any hosted offer.
