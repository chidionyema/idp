# THE ESTATE — Full Solution Blueprint v1.0 (2026-11-10)
One system. Every component below has exactly one job, one interface, one proof path.
Status: [D] designed · [R] reference-proven · [W] Rust-written, pending compile · [P] pending build

## The stack (top = founder, bottom = metal)
L0 PRINCIPAL   Founder — voice-first, Telegram/WeChat, the only principal. Approves spend
               and irreversible actions in Telegram only (governance law).
L1 SURFACE     Genesis founder dashboard + Telegram voice notes [P: 8-12h]
               (spooler delivers; piper TTS on VM; 60-90s briefs; survives dead sessions)
L2 POLICY      intercloud (Rust) [W+R] — lane registry, free-first placement, Telegram paid-gate,
               hysteresis, churn drills, DR 3-2-1, placement receipts
               rank plane (Rust, in muster) — R1 Roman ledger + R2 Solomonic contract tiers
L3 ORCHESTRATE Muster (Rust) [W+R] — RunSpec IR, event log + replay, kernels K1-K5,
               24 formations as data, actor supervision, receipt chaining, dismissal rite
L4 MODEL DOOR  pennyd (Rust) [built, needs cargo test] — sole key holder, aliases,
               budgets=leases, cheap-first cascade, identity law, decision log
L5 CONTROL PL  k3s + Crossplane + Karmada + Flux on OCI 2/12 [P: 26-38h] —
               intercloud runs HERE as controller; decides -> Crossplane converges ->
               observed readiness anchors receipts
L6 LANES       free: OCI A1, GCP micro, Northflank, IBM k8s, GH-runner burst ·
               paid (last resort, Telegram-gated): Hetzner CAX21 $7.49/mo ·
               forbidden: Mac (client only)
L7 STATE       Neon Postgres · Turso SQLite · Upstash Redis · R2 escrow (3-2-1) ·
               estate-secrets vault · Tailscale mesh fabric
L8 TRUTH       The receipt layer cuts across L1-L7: muster receipt chain x pennyd decision
               log x Crossplane observed readiness x intercloud placement receipts —
               every claim anchors to at least one external, machine-generated source.

## One goal's full journey (the closed loop)
goal -> inscribe RunSpec (terms, budget, proof) -> intercloud places it (free-first,
Telegram-gated) -> Muster conjures formation -> every model call through pennyd (alias,
budget ceiling, decision-log entry) -> step N+1 blocked until receipt N verifies on BOTH
chains -> yield = artifact + chained receipt + decision-log anchor -> Crossplane keeps
infra converged to the placement -> scorecard updates ranks (R1/R2 min policy) ->
dream-cycle consolidates -> voice brief to founder in Telegram -> receipts archived.

## What exists right now
- muster: full crate, 11 tests (5 kernels, 24 formations, doctrine runtime, rank plane) [W]
- intercloud: full crate, 10 tests (registry, placement, gate, hysteresis, DR, drills) [W]
- references: both logic-proven green (Python test benches) [R]
- SECURITY_REVIEW.md: 17 adversarial findings, 4 fixed, rest scheduled [D]
- pennyd: built, structural verification green; cargo test pending [W]
- bundle: estate-rust-bundle.zip, CI-ready (Makefile, clippy -D warnings, ci.yml)

## The build order — PIECE BY PIECE (founder revision 2026-11-09: no big bang; pennyd done)
Integration contract between pieces = the receipt layer (L8) ONLY. Each piece stands alone.

PIECE 1 — INFRA LANE (the substrate everything runs on)  [est. 14-20h post-unblock]
  k3s on OCI 2/12 + Tailscale · Crossplane core + providers (oci/hetzner/cloudflare/tailscale)
  · Flux · Lane + Approval CRDs · intercloud (Rust) deployed as controller · pennyd deployed
  on the control plane (it is built; rides in this piece for free until its dedicated lane
  is Telegram-approved) · churn-drill receipts live.
  EXIT CRITERIA: `intercloud status` returns health verdicts per lane; a probe workload is
  placed free-first with an observed-readiness-anchored receipt; killing a lane in a drill
  produces GAP_VERDICT receipts. Nothing on the Mac except a client.
PIECE 2 — LEGION (Muster)  [est. 12-16h]
  Engine deployed on the lane · kernels wired into Chain · pennyd as sole model door
  (aliases scout/reason/break/judge; per-formation keys) · first real formation runs:
  Phalanx + one Obsidio campaign end-to-end on real infra · every step dual-chain verified
  · rank plane consuming pennyd decision log.
  EXIT CRITERIA: cargo test 21/21 on CI; one campaign yield = artifact + chained receipt +
  decision-log anchor, third-party verifiable; ranks updated and routing on them.
PIECE 3 — GENESIS VOICE-FIRST SURFACE  [est. 8-12h]
  Dashboard + Telegram voice notes; consumes receipts/scorecard only (never the raw log).
  EXIT CRITERIA: founder hears a 60-90s session brief on Telegram; dead session still delivers
  (file persists); brief cites machine-generated summary hash.
Total: 34-48h machine time post-unblock, $7.49/mo optional lane (Telegram-gated).

## Original monolithic order (superseded, kept for reference)
0. UNBLOCK (founder, ~10 min): waive founder-pause in Terminal.app + mumchimp Cloudflare
   token -> dof-gate reopens -> 13 queued PRs land
1. VERIFY  (~2h machine): cargo test both crates on any Rust host -> 21/21; then bot-commit
   CI path so every future PR self-tests
2. CONTROL PLANE (26-38h): platform repo -> k3s+Crossplane+providers -> Flux -> Lane/Approval
   CRDs -> intercloud as controller -> observed-readiness anchoring (fixes C2/C3/H4)
3. ORCHESTRATION (10-14h): kernels wired into Chain, doctrine packs loaded, Muster on k3s
4. SURFACE (8-12h): voice-first dashboard + Telegram voice notes
5. LIVING-FOREVER LOOP (4-6h): quarterly provider-churn drills wired to receipts
Total machine time post-unblock: ~50-72h. Money: $7.49/mo (one lane, Telegram-approved).

## Non-negotiables (already law)
$0-first · Mac is a client · receipts over claims · Telegram-only spend approval ·
PR discipline with FMEA rows · no stub without a declared seam · founder decides.
