# TESTING BUNDLE — muster + intercloud (2026-11-09)
Two zero-dependency Rust crates. Logic proven green via reference implementations;
this bundle is the compile+test handoff.

## Run on any Rust host (Mac, VM, CI)
  unzip estate-rust-bundle.zip
  cd muster && make ci        # fmt + clippy -D warnings + 11 tests
  cd ../intercloud && make ci # fmt + clippy -D warnings + 10 tests

## Expected: 21/21 green
  muster: sha256_vectors, complete_run_verifies (fractal K1 chain, 4 receipts),
          tamper_detected, event_tamper_detected, crash_resume
  intercloud: sha256_vectors, free_first_and_capacity, telegram_gate_refuses_other_channels,
              hysteresis_reclaim, churn_drill_finds_gaps, receipt_tamper_detected

## CI path (estate-native): each crate is a repo with .github/workflows/ci.yml.
Bot-commit can deliver workflow files (bypasses the OAuth workflow-scope blocker).
