# SECURITY & ADVERSARIAL REVIEW — estate rust bundle (2026-11-09)
Reviewer stance: everything below was attacked, not admired. Status: O = open (fix required), F = fixed this pass, A = accepted with rationale.

## CRITICAL
C1. Uncompiled code is unproven code. No rustc in authoring sandbox; structural gates only.
    Exploit: compiler rejects entire design at first build. Fix: cargo test on a Rust host, then clippy -D warnings in CI. Status: O (execution paths documented in TESTING.md).
C2. Hash chains are tamper-EVIDENT, not tamper-PROOF. A forger who controls the writer can rebuild the whole chain from genesis.
    Exploit: rewrite events+receipts, consistent chain, no alarm. Fix (already in design, must stay mandatory): anchor chain heads EXTERNALLY — pennyd decision-log req-ids (cross_anchor), git commit, spooler receipts. Any verify() without external anchor is diagnostic only. Status: O, enforced by design docs; add a test asserting verify fails when dlog anchor is missing.
C3. Telegram paid-gate trusts its caller. approve_paid() accepts any string as "receipt"; nothing binds it to a founder-signed Telegram message.
    Exploit: any code holding &mut Engine approves paid spend. Fix: approval input must be a spooler-verified message (signature check), engine holds no approve path otherwise. Status: O — documented single-writer assumption; production controller must verify the signature.

## HIGH
H1. Public invariants. muster::Ctx fields pub (receipts/events/done replaceable by any holder) — tests already bypass encapsulation. intercloud::Workload.paid_ok set only by engine but field pub.
    Exploit: external mutation invalidates chains/placement silently. Fix: pub(crate) fields + accessor methods; only mint/verify APIs public. Status: F (intercloud paid_ok now engine-set; full encapsulation next pass).
H2. Hand-rolled SHA-256. Correct per FIPS vectors, but unaudited; no fuzzing; integer ops only (no timing side channels for our threat model) but Merkle-Damard construction.
    Exploit: subtle carry/rotation bug = silently broken chains. Fix: keep vectors test; switch to ring/rustcrypto when deps allowed; property-test against std vectors. Status: O.
H3. Kernels not wired into the fractal Chain. Node enum = Step|Formation only; K2-K5 execute standalone. Seq recipes reference nodes like "debate-lead" with no existence check.
    Exploit: a formation def names a ghost node -> runtime panic or silent skip. Fix: validate_recipes() over formations(); wire kernels as Node variants in next milestone. Status: F (validation required below), wiring O.
H4. Receipt log flooding. Every denied/held placement mints a receipt; unbounded loop of place() attempts = unbounded log.
    Exploit: disk exhaustion via governance failure noise. Fix: per-run receipt budget (Praetor gate), receipts spill to capped side-log. Status: O.
H5. f64 capacity arithmetic. alloc/release drift over thousands of cycles; lanes flap healthy/down during hysteresis window -> reclaim churn between lanes.
    Exploit: capacity drift -> placement decisions on false free space. Fix: integer milli-CPU/milli-GB; require target lane stable for N ticks before reclaim. Status: O (documented; not fixed to keep diff reviewable).

## MEDIUM
M1. dr_check cloud names were case-sensitive ("GitHub" vs "github" bypass) — FIXED this pass (lowercased).
M2. Rank weights hardcoded (0.30/0.20/0.20/0.15/0.15); founder-tunable weight not implemented. Fix: weights in registry config with loud validation. Status: O.
M3. Python reference implementations share the author's blind spots — not independent verification. Fix: property-based tests (proptest) for chain/verify/placement invariants; differential testing Rust-vs-Python once Rust compiles. Status: O.
M4. Hetzner CAX21 ~$7.49/mo figure is UNVERIFIED (from pasted fleet analysis); confirm current pricing before the Telegram approval. PAYG-Oracle-4/24 reprieve also unverified — do not build on either. Status: O (verification required, one search).
M5. Gate predicate is Fn(&Ctx) — pure over observed state, good; but Gate::check result is not itself receipted when Veto. Veto halts by convention only; a caller can ignore the enum.
    Fix: make run-loop unmountable — after Veto, engine refuses further receipts for the run (enforced, not advisory). Status: O.

## LOW / ACCEPTED
L1. Single-threaded MVP: no races by construction; multi-writer future must re-audit. Status: A.
L2. Mock lane stands in for pennyd (no network in sandbox): seam is a stub BY ENVIRONMENT, declared in code; production impl behind trait. Status: A (declared).
L3. Forbidden-lane 'prefer' cannot override (test added); Mac remains unplaceable. Status: F + test.
L4. load_registry: unknown verb / negative resources / paid-without-cost / empty registry all refused loudly (tests). Status: F.

## VERDICT
Logic invariants proven in reference (21/21 checks green); Rust compile+test is the single blocking proof (C1). No claim of "tested" until cargo test returns 11+10 green. No stubs added: every mock seam is declared and trait-bound for replacement.
