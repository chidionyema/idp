# LEGION / Muster — System Design v0.1
Status: design doc v0.2, awaiting founder approval (build-order). No code before approval.
v0.2: Rank plane generalized — TWO ranking systems shipped (Roman + Solomonic), RankingSystem interface, packs can add more.
v0.3: Dual-register vocabulary — every doctrine term ships {codename, plain_register}; external surfaces use plain operational English (NOT legalese), mythos stays internal.
v0.4: Register softened further per founder — plain speech, no legalese; PR discipline standing: all changes as PRs, failure-pack law (name FMEA rows + tests per row), founder merges.
v0.5: Tri-register vocabulary per founder — codename (mythos, internal), plain register (default external), legalese register (for legal customers, selectable per deployment/customer).
v0.6: Modular fractal architecture made explicit — recursion rule + uniform interface at every scale.

## 1. Design principles
P1 Receipt-gated execution: a run advances only on a verified receipt (muster hash-chain) cross-anchored to pennyd decision-log request-ids. No verified step, no next step.
P2 Sole model door: pennyd (port 4000) holds every provider key; Muster holds zero keys and speaks only the OpenAI-compatible surface. No formation is retargetable by prompt — only by governed TOML change.
P3 Data over code: providers/models/aliases/fallbacks, key ACLs, doctrine packs, formation definitions are hot-reload data (<=5s), validated loudly at load.
P4 Kernels over implementations: 5 execution kernels; all 21 formations + combinations are compositions expressed as data. Never 21 bespoke implementations.
P5 $0 infra, no Mac dependency: Oracle Always Free ARM VM always-on; GitHub-hosted runners are burst cavalry (Ala); Mac is a client only.
P6 The founder is the only principal: every muster inscribes terms before dispatch — goal, budget, proof requirement, failure terms. No operation without the pact.

## 2. Architecture
Doctrine packs (Roman | Goetic | VSM | ICS | Immune | ...)     <- skins, conformance-tested
  | compile to
Muster Engine (Rust, single binary)                            <- brain
  - RunSpec IR, event log (sqlite append-only, sha256-chained), replay
  - Scheduler + actor supervision (restart | escalate | terminate per rank)
  - 5 execution kernels; formation compositions
  - WASM tool sandbox with fuel metering
  - Proof layer: receipts, Inquisitor, dismissal rite
  | per-formation keys, aliases only
Pennyd (pure-Rust edge daemon)                                 <- spinal cord, sole model door
  - auth per key, alias resolve, cache, shape, cheap-first cascade
  - hard budget ceilings = leases; hash-chained decision log
Rank plane: scorecard from decision log + receipts; Elo; demotion (Triarii); routing table
Dispatch: estate-execute door (MCP) -> legion x formation x mode; VM + GH-runner burst

## 3. Core data models (Rust)
RunSpec  { run_id, goal, doctrine, formation, roles: [UnitSpec], leases, budget_usd,
           proof_requirements, stopping_rule, dismissal_terms }
UnitSpec { unit_id, office (from doctrine), rank, kernel_role, key_alias_scope,
           model_aliases: [scout|reason|break|judge], supervision: RestartStrategy }
Receipt  { run_id, step_id, prev_hash, kind, command/evidence, exit_status,
           evidence_hash, pennyd_req_ids: [u64], ts }          <- sha256 chain
Event    { seq, type (Mustered|StepStarted|ReceiptVerified|GatePassed|Dismissed|...), payload, hash }
ScoreRecord { office, window, success, cost, p50, p95, audit, uptime, composite, elo }

## 4. Execution kernels (the only 5)
K1 CHAIN    sequential/DAG with strict contracts (topo-ordered, all-upstream merge — supersedes army.py edge bug)
K2 SCATTER  map-reduce over N cheap units (probe fan-out, aggregate, discard individuals)
K3 DEBATE   bounded adversarial loop + judge (hard turn budget, judge receipt required)
K4 BRACKET  tournament with Elo updates (cost-aware utility, never raw pass@k)
K5 GATE     deterministic/approval gate; emits GatePassed event; HITL via estate-execute

Formation = data: { kernel(s), topology params, stopping rule, proof requirement, doctrine names }

Fractal recursion rule (modular fractal architecture):
- Uniform interface at EVERY scale: RunSpec in -> receipts out. Unit, squad, formation,
  legion, estate — same shape, same proof semantics, same contracts.
- Any node in any kernel may be a Unit OR a Formation (composite component). K1 Chain with
  composite nodes = Phalanx of Phalanxes; Legate Staff = tree where leaves are formations.
- A formation is a primitive at the next scale up: Obsidio = loop of formations; the estate
  itself = a muster of legions (the founder is the only principal at every level).
- Recursion depth is bounded by contract tier (never engage above your station = depth cap) —
  security and structure are the same rule at every scale.

## 5. Formation library (21 = compositions)
Line:      Phalanx=K1; Cohort=K2+verified-vote; Echelon=K2->K1->K1; Ala=K2 on GH runners (short TTL)
Maneuver:  Velites=K2 cheap; Maniple=K2+blackboard-claims; Wedge=K3-lead then K2 flood; Exploratores=K2 breadth
Contest:   Pincer=K3; Tournament=K4; RedTeam=K3 attacker vs target artifact; Inquisitor=K3 vs claims (funded skeptic)
Command:   LegateStaff=tree of K1; PrimusPilus=K1 graded on delegation quality; Praetor=K5 only (no LLM scope)
Defensive: Testudo=any kernel inside quarantine wrapper; Triarii=shadow K1 (demoted scope); Castra=K1+snapshot events
Siege:     Fabri=K1 producing reusable automation; Obsidio=loop{K2->K3->K1->K3} on budget clock; Migratio=post-run K1 over logs -> skills
Combos:    Pincer-of-Wedges, Velites->Tournament->Echelon, Testudo+Auxilia, Obsidio(Maniples,Praetor), Castra under Inquisitor

## 6. Component responsibilities
Muster engine: event log + replay = crash-proof casts; actor supervision; scheduling; kernel interpreter; receipt minting; dismissal rite (receipt + teardown + snapshot; missing dismissal -> dead-man switch fires).
Proof layer: chain verify (muster), cross-verify vs pennyd decision log (req-ids, cost, lane), Inquisitor verification runs, self-test command.
Pennyd bridge: formations reference key ids, never raw keys; alias discipline enforced (unknown alias -> 400 discovery); lease sync (budget_usd -> key daily ceiling); decision-log tail = scorecard feed.
Doctrine runtime: pack = {rank schema, formation templates, ontology, comm protocol, leases, state vocabulary}; conformance suite requires expressibility of assign/supervise/budget/prove/demote/dismiss; packs compile to IR.
Rank plane: composite 30 success/20 cost/20 latency/15 audit/15 uptime (founder-tunable); Elo from K4; promotion/demotion = ACL-scope config PR (hot reload); routing table consumed by estate-execute classifier; demoted -> shadow keys, never deleted.

## 6b. Tri-register vocabulary
Every doctrine term ships THREE registers; the active register is selectable per surface and
per customer segment (legal customers get the legalese register):
  oath           -> terms (plain) -> covenanted undertaking (legalese)
  pact           -> contract      -> instrument of engagement
  summon         -> engage        -> direct the performance of
  spirit/unit    -> unit          -> contracted agent
  station/tier   -> contract tier -> class of engagement
  breach         -> breach        -> material breach of covenant
  close out      -> close out     -> termination and discharge
  brass vessel   -> escrow        -> escrowed quarantine
  book of offices-> capability registry -> schedule of offices
  receipt        -> receipt       -> attested instrument of record
Also standing: PR discipline — every change lands as a PR (no direct pushes); a PR touching a
critical service names affected FMEA rows and the exact test per row (failure-pack law); merges rest with the founder.
  oath -> contract terms        pact/covenant -> contract / engagement
  summon -> engage/commission    spirit -> unit/agent
  station of the pact -> contract tier    oath-breaking -> contract breach
  dismissal rite -> contract close (termination rite)    brass vessel -> escrow/quarantine
  triangle -> isolation sandbox (kronos ring)    circle -> governance perimeter
  book of offices -> capability registry (legion.yaml)    seal/sigil -> verified signature (receipt)
  binding -> terms enforcement    office -> role    legion -> fleet service
  doctrine pack -> operating doctrine    conjurer/principal -> principal (unchanged)

## 7. Key flows
Muster lifecycle: inscribe RunSpec -> engage (dispatch via estate-execute) -> operate (step-gate loop) -> prove (receipts) -> contract close (rite) -> muster-out (scorecard write, dream-cycle feed).
Step gate: step N+1 dispatch blocked until receipt(N) verifies on both chains; pennyd req-ids matched to decision log entries (tokens/cost/lane).
Crash recovery: replay event log from last snapshot (Castra); LLM steps resolve via cached req-id (no re-pay); idempotency keys on side effects.
HITL: Praetor K5 gate -> founder approval via estate-execute intent; approval itself becomes a chained event.

## 8. Failure modes (FMEA, every row gated per pennyd gate law)
F1 event-log corruption -> chain verify fails -> run frozen, receipt chain pinpoints tamper (test: flip byte, verify refuses)
F2 pennyd unreachable -> no receipts minted -> run pauses, never falsifies progress (test: blackhole port 4000)
F3 judge compromise -> cross-check decision-log req-ids + Inquisitor re-verify (test: forged judge output)
F4 budget exhaustion -> hard ceiling; Obsidio loop exits with partial receipts, never silent (test: $0 budget key)
F5 sandbox escape attempt -> WASM fuel + capability list; breach -> unit terminated, fence event (test: fuel bomb)
F6 runaway swarm -> SCATTER fan-out cap from RunSpec; dead-man switch (test: 10x declared fan-out)
F7 prompt-injected retarget -> impossible by construction; only TOML change retargets (identity law)
F8 session death without dismissal -> 2x beat interval = DOWN; reconstitution from log, founder alerted

## 9. Security model
Keys exist only in pennyd process env; Muster config references key ids. WASM fuel metering caps tool spend. Quarantine (Testudo) wraps third-party units; outputs promoted only via verification. Fence patterns native (two-tier HARD/REVIEW, pre-check + git-measured post-check — pi_bridge patterns canonized). Unknown key 401; unknown alias 400 with discovery; budgets hard ceilings.

## 10. Interfaces
CLI: muster inscribe|conjure|prove|receipt --verify|scorecard|dismiss
MCP door: estate-execute intents (goal -> classifier -> legion x formation x mode)
Discovery: legion.yaml v2 (existing schema + offices/formations/rank blocks) = Book of Offices
Founder surface: pennyd /dash + FleetView (existing)

## 11. Deployment
Single binary on Oracle ARM VM (systemd unit in deploy/ pattern); GH-runner burst mode for Ala; launchd unit retained for laptop client plane only. $0 throughout; kustomize manifests reusable for later HA.

## 12. Phases (machine time; decision points marked)
A. RunSpec IR + event log + receipt chain + replay + K1 (Phalanx) + pennyd bridge + dual-verify  12-16h
B. Actor supervision + WASM fuel + K2/K3/K4 (Velites, Pincer, Tournament)                 14-18h
C. Doctrine runtime + conformance suite + Roman & Goetic packs                             8-10h
D. Rank plane: RankingSystem interface + R1 Roman + R2 Solomonic + Elo + routing + demotion  10-12h
E. Dismissal rite, dead-man switch, FMEA test suite, eval harness, hardening              8-10h
Total: 52-66h, $0 infra. Merge-gated inputs: agent-foundry#5 (ArmyNodeSpec), idp#7733 (legion kit).

## 13. Open decisions (founder)
1. Approve this design -> I write the Phase-3 proposal (scope, hours, risks, decision points)?
2. Greenfield Muster (recommended) vs extend agent-foundry?
3. Rank weights: keep 30/20/20/15/15 or add training-contribution term?
4. Third-party formations: Testudo-only, or Testudo + paid attestation?
