# Handover for Gemini, 2026-11-13 14:14Z (all facts read today)

## 1. The Mac (founder paste, 14:01Z)
- pennyd router: pid 67569, binary ~/.estate/bin/pennyd, config ~/.estate/pennyd/pennyd.toml, 4 MB RSS
- pennyd SOURCE / binary: not on GitHub in any repo. The binary ~/.estate/bin/pennyd exists only on the Mac.
- pennyd CONFIG: on GitHub only in UNMERGED idp PR #8036 (branch backup/cleanup-20261113-idp @ 13b00af89), path platform/estate/pennyd/:
  - pennyd.toml
  - deepseek.toml, gemini.toml, groq.toml, minimax.toml, openrouter.toml, zai.toml
  - keys.toml: NOT included
- PR #8036 is a 100+ file worktree consolidation (backstage, workflows, AGENTS.md), not a router PR. It is not landable as-is.
- Local model processes (ollama/llama/mlx/litellm/vllm/lmstudio): NONE running. The models are not what is eating memory.
- 61 active launch jobs in ~/Library/LaunchAgents; 34 agent processes running
- The cage: launch job ai.estate.dsh-caged. Its source is in no repo.
- Still unknown: the top memory consumer. Run:
  `ps -axo rss=,comm= | sort -rn | head -15 | awk '{r=$1; $1=""; printf "%6d MB%s\n", r/1024, $0}'; memory_pressure | grep percentage`

## 2. Sovereign router (argon main, read 14:07Z)
- What it is: an OpenAI-compatible front on 127.0.0.1:4102 that forwards to another router
- Default upstream: https://llm.mumchimp.com, a Cloudflare tunnel back to the Mac (pennyd / local LiteLLM). It returns 530 when the Mac is offline.
- Fallback: estate-active-slot, the port named in ~/.estate/router-state/active (local LiteLLM, ports 4000-4100)
- Needs LITELLM_API_KEY, decrypted from ~/.estate/sovereign-router/LITELLM_LAPTOP_KEY.yaml. Without it, it exits with "DEGRADED no_upstream_credential".
- Sources: crates/sovereign-router/src/daemon.rs:38-48, crates/sovereign-router/src/main.rs:19-46, bin/launchd/sovereign-router
- VERDICT: if pennyd is down, sovereign-router is down too. Two routers, one dependency.
- To make it independent with config only, no code:
  - SOVEREIGN_ROUTER_UPSTREAM = a real provider's OpenAI-compatible base URL
  - SOVEREIGN_ROUTER_FALLBACK_UPSTREAMS = a second provider
  - Supply that provider's key. The wrapper only loads LITELLM_API_KEY, so it must be changed to load the provider key.

## 3. Previous agent (DSH web) state, from its transcript at 13:26
- Its handover idp/docs/HANDOVER-20261113.md is NOT on GitHub (404 on main). It exists only on the Mac.
- Its last push failed with non-fast-forward. The result is a local commit 2e1307a39 with 20 changed files on a diverged branch on the Mac. Do not force-push it.
- The founder has retired DSH web.

## 4. GitHub state
- sovereign-router source: argon main, crates/sovereign-router/ (last change 9448371, 2026-11-03)
- Waiting to land, not merged:
  - idp ready/bdd-proof-same-tree-I-0413: Greenlane proof refusal, sha vs tree
  - idp ready/dof-total-repair-scope-I-0413: DoF deadlock
  - argon ready/turn-render-utc-time
- Known broken: argon has 7 test_genesis_clamp tests failing since #104
- Agent apps to revoke: https://github.com/settings/installations
  - MiniMax Code, Cursor, Google AI Studio, ChatGPT Codex Connector, coderabbitai
  - Keep: Vercel, Cloudflare, estate-agents

## 5. Founder constraints
- Never kill Chrome
- No command over 100 s
- Zero spend
- Agents: no git access; bash allowed but capped at 100 s; caged, with the cage controlled from the founder surface (for real experiments)
- Protect first: copy ~/.estate off the laptop, because it holds the only copy of pennyd
