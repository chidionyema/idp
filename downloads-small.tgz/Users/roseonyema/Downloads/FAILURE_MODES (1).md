# Tempo v2.0 — Failure Modes, Detection, Response and Recovery (Rust build)

Status: **executed-verified** unless explicitly marked otherwise. Every row's
"Verified by" column names the Rust test (or check) that proves it. Run the
proof with:

```bash
./run_tests.sh                  # fmt + clippy + 187 tests
./tools/smoke_e2e.sh            # boot/refuse/restore loop against live processes
```

The only rows NOT yet verified by execution are the hardware-gated ones
(F-HW-3's radio loop), which require the physical BLE spike; they are marked
`hardware-gated` (the backoff ladder logic itself is unit-tested).

Severity classes:
- **S1** — data loss or silent integrity compromise
- **S2** — authority compromise or false liveness signal
- **S3** — availability loss with safe failure (node down, feature degraded)
- **S4** — cosmetic / observability gaps

---

## 1. Hash log integrity (F-LOG-*)

| ID | Failure | Detection | System response | Recovery | Verified by |
|---|---|---|---|---|---|
| F-LOG-1 | Log record edited in place (value/ts/hash field) | `HashLog::verify()` recomputes the SHA-256 chain; line-numbered detail | `HashLog::new` returns `ChainError`; `Estate::new` returns `BootRefusal`; process prints `TEMPO BOOT REFUSED` and exits nonzero; dashboard banner via `log.ok=false` | Restore from backup + checkpoint anchor (runbook R1) | `log::tests::given_value_tamper…`, `given_ts_tamper…`, `given_hash_field_tamper…`; `estate::tests::given_tampered_log_when_booted_then_refused`; `e2e::given_backup_restore_runbook…`; smoke step 5 |
| F-LOG-2 | Disk full on append | IO error from write/fsync | Error propagates; in-memory head UNCHANGED; chain on disk consistent; ingest halted (fail-closed) | Free space, retry the same event — seq/chain accept it | `log::tests::given_disk_full_when_appended_then_error_and_chain_consistent`, `given_disk_full_recovered_when_same_event_retried_then_succeeds` |
| F-LOG-3 | Torn write (crash mid-append, no trailing newline) | Final line fails parse/chain AND lacks newline | Recovery-on-open truncates to last good boundary; boot continues from last valid record | Automatic; un-checkpointed tail events lost (documented RPO, section 8) | `log::tests::given_torn_write_midline_when_reopened_then_recovered_to_last_good`, `given_torn_write_keeps_good_prefix_when_reopened_then_ok` |
| F-LOG-4 | Node loss / silent tail truncation (restore of older file) | Signed checkpoint anchors a seq/hash the chain no longer reaches | `verify_checkpoints()` fails; `Estate::new` QUARANTINES log+ckp (renamed, never deleted), writes `.incident`, refuses boot | Restore anchored backup (R1); quarantine preserves evidence | `log::tests::given_truncated_history_when_checkpoints_verified_then_anchors_not_present`; `estate::tests::given_truncated_anchored_history_when_booted_then_quarantined_and_refused` |
| F-LOG-5 | Checkpoint record forged/altered | Ed25519 signature over `{seq, hash}` fails | Boot refused | Regenerate checkpoints from a verified chain (R2) | `log::tests::given_tampered_checkpoint_sig_when_verified_then_detected`, `given_wrong_checkpoint_key_when_verified_then_signature_invalid` |
| F-LOG-6 | Log file deleted but `.ckp` remains | Anchored history "not present" during checkpoint walk | Boot refused (no silent fresh start) | Restore (R1) | `log::tests` checkpoint suite + estate boot path |
| F-LOG-7 | Log file deleted entirely (no checkpoints) | `HashLog` starts empty at genesis | Boot succeeds as a fresh log; operator alert: absence of `.ckp` alongside a previous seq count is detectable via the external anchor copy (see R3) | Restore from off-node anchor copy (R3) | By design; documented residual risk |
| F-LOG-8 | Unreadable block / IO error during verify | IO error caught, reported in detail | `verify()` returns false with io-error detail; maintenance loop logs to stderr | Fix disk; re-run `--verify-only` | `log::tests::given_missing_directory_when_opened_then_error_not_panic`; implementation review |
| F-LOG-9 | Concurrent appends interleave | Design: one internal Mutex around append; one writer per line | Strictly monotonic seqs under 8-thread contention | n/a | `log::tests::given_eight_thread_contention_when_appending_then_strictly_monotonic` |
| F-LOG-10 | Unbounded log growth | Measured, not aspirational: ~1 event/min ≈ 70 MB/yr | Documented archive procedure (R4); not automated in v2.0 | Snapshot + archive per runbook | README runbook R4 |

## 2. Secure time (F-TIME-*)

| ID | Failure | Detection | System response | Recovery | Verified by |
|---|---|---|---|---|---|
| F-TIME-1 | Wall clock jumps backwards (NTP step, VM restore) | Expected wall = prev wall + monotonic delta; wall trails it by > 1s | `trusted_now()` holds at the previous-sample projection (never rewinds); event recorded in `skew_events` | Operator investigates NTP; confidence recovers after skew state is bounded by policy | `timeutil::tests::given_backward_wall_jump_when_trusted_now_then_holds_at_projection`, `given_mixed_samples_when_trusted_now_then_monotonic` |
| F-TIME-2 | Host time unsynchronised (chrony down) | `sync_source()` returns false | `time_confidence() == "low"`, surfaced on `/state` and dashboard; TTL-bound authority decisions flagged | Restore chrony/ntp | `timeutil::tests::given_unsynced_source_when_confidence_then_low`, `given_skew_when_confidence_then_medium` |
| F-TIME-3 | Wall clock jumps forwards | Monotonic delta smaller than wall delta | Accepted (forward time is safe for freshness; cannot resurrect state because last_seen uses max()) | n/a | `state::tests::given_old_timestamp_when_accepted_then_no_resurrection` |
| F-TIME-4 | Device timestamp in the future/past (spoof) | Device ts vs node-stamped `received_ts` delta > 300s | Device ts NEVER used for freshness; skew recorded as engine note | n/a | `state::tests::given_device_ts_far_behind_when_accepted_then_noted` |

## 3. Ingest pipeline (F-ING-*)

| ID | Failure | Detection | System response | Recovery | Verified by |
|---|---|---|---|---|---|
| F-ING-1 | Replayed event (same/older per-channel seq) | Per-channel monotonic seq guard | Rejected; `replay_rejected` audit in hash log; HTTP 409; state untouched | n/a | `state::tests::given_replayed_seq_when_accepted_then_rejected`; `estate::tests::given_duplicate_seq_when_ingested_then_replay_rejected`; `http::tests::given_replayed_event_when_posted_then_409`; smoke step 4 |
| F-ING-2 | Stale timestamp injection to resurrect state | `last_seen = max(prev, received_ts)` | Cannot rewind any channel | n/a | `state::tests::given_old_timestamp_when_accepted_then_no_resurrection` |
| F-ING-3 | Malformed/malicious event (bad schema, closed-list violation, unknown field, NaN) | Strict schema validation at the boundary | Dropped; `ingest_rejected` audit with reason; HTTP 400; no crash | n/a | `schema::tests` (19 cases); `estate::tests::given_schema_violation_when_ingested_then_rejected_and_audited` |
| F-ING-4 | Event on unknown channel | Channel membership check in engine | Rejected (`unknown_channel`), audited | Fix config or sender | `state::tests::given_unknown_channel_when_accepted_then_rejected` |
| F-ING-5 | Oversized HTTP payload | 64 KB body cap | HTTP 413 before parse | n/a | `http::tests::given_oversized_body_when_posted_then_413` |
| F-ING-6 | Device clock skew | received_ts vs device ts delta | Device ts never authoritative; note recorded | Fix device | `state::tests::given_device_ts_far_behind_when_accepted_then_noted` |
| F-ING-7 | Non-object JSON body | Type check before validate | 400/audited, no crash | n/a | `http::tests::given_invalid_json_when_posted_then_400` |

## 4. Liveness state (F-STATE-*)

| ID | Failure | Detection | System response | Recovery | Verified by |
|---|---|---|---|---|---|
| F-STATE-1 | Single-channel spoof attempts to assert full liveness | Cross-channel corroboration: body channel required for full confidence | Presence-only yields `alive` + `confidence=reduced`; authority overlay never exceeds what fresh state allows | n/a | `state::tests::given_presence_only_when_derived_then_alive_reduced` |
| F-STATE-2 | Clock skew degrades time trust | `time_confidence()` | Surfaced on `/state`; medium after skew | n/a | `timeutil::tests::given_skew_when_confidence_then_medium` |
| F-STATE-3 | Planned-offline window expires | Window bounds checked per derive | Ladder resumes (stale→anomaly→dormant) | n/a | `state::tests::given_planned_offline_when_derived_then_wins_over_ladder`, `given_planned_offline_when_body_fresh_then_body_wins` |
| F-STATE-4 | Snooze abuse (attacker suppresses anomaly) | Snooze requires Ed25519 challenge-response; bounded 60s–12h; audited | Unsigned/foreign-key snooze impossible | Rotate key | `http::tests::given_challenge_then_signed_command…`, `given_impostor_key_when_command_signed_then_401`; `estate::tests::given_snooze_when_issued_then_bounded_and_audited` |
| F-STATE-5 | Snooze expiry unnoticed | Snooze has explicit `until`; derive falls through to ladder | State re-enters anomaly automatically | n/a | `state::tests::given_snooze_when_derived_then_anomaly_suppressed` + expiry semantics in `derive()` |

## 5. Identity and authority (F-AUTH-*)

| ID | Failure | Detection | System response | Recovery | Verified by |
|---|---|---|---|---|---|
| F-AUTH-1 | Deepfake "authorisation" (voice/face/photo) | Not an input at all | Impossible by construction: only Ed25519/HMAC key possession is an authority channel | n/a | architecture invariant; `identity::tests` prove the key path |
| F-AUTH-2 | Challenge replay | Single-use nonce store | `nonce reuse` rejection; nonce burned on success only | n/a | `identity::tests::given_replayed_challenge_when_verified_then_reuse_rejected` |
| F-AUTH-3 | Cross-scope power grab; co-sign recorded before request | Seq-vs-seq comparison (former bug #1 fixed) | `execute_cross_scope` denies: time lock + quorum co-sign strictly after request seq, never self-signed; all denials audited | n/a | `policy::tests::given_cross_scope_request…`, `given_cosign_recorded_after_request_when_executed_then_valid_but_never_before`, `given_self_cosign_when_recorded_then_rejected`, `given_requester_mismatch_when_executed_then_denied` |
| F-AUTH-4 | Absence concentrates authority | Policy overlay on engine state | anomaly: U2→U1; dormant: everything → U0-frozen; alive unfreezes | n/a | `policy::tests::given_anomaly_when_u2_then_suspended_to_u1`, `given_dormant_then_frozen_then_alive_unfreezes` |
| F-AUTH-5 | Challenge flood (memory) | Open-challenge cap 10k + lazy purge | Issuance refuses when saturated | n/a | `identity.rs` cap; code review |
| F-AUTH-6 | Tampered challenge fields (action swap) | Canonical byte comparison against issued record | `challenge mismatch` rejection | n/a | `identity::tests::given_tampered_action_when_verified_then_rejected`, `given_correctly_signed_but_altered_challenge…` |
| F-AUTH-7 | Command replay over HTTP | Nonce single-use across the store | 401 with reuse reason | n/a | `http::tests::given_replayed_command_when_executed_then_401_with_reuse_reason` |
| F-AUTH-8 | Wrong key / impostor signature | Ed25519 verify against enrolled pubkey | 401 | Re-enroll (R5) | `identity::tests::given_wrong_key_when_verified_then_rejected`; `http::tests::given_impostor_key_when_command_signed_then_401` |
| F-AUTH-9 | U3 privilege escalation attempt | `grant()` refuses | `PolicyError`; U3 out of scope for v1 (needs FIDO2 step-up) | n/a | `policy::tests::given_u3_when_granted_then_refused` |

## 6. Bus and backpressure (F-BUS-*)

| ID | Failure | Detection | System response | Recovery | Verified by |
|---|---|---|---|---|---|
| F-BUS-1 | Slow consumer, queue overflow | Bounded deque + per-queue drop counter | Drop-oldest; loss forwarded to the estate callback; `bus_loss` audit in hash log | Consumer restart | `bus::tests::given_slow_consumer…`, `given_loss_callback…`; `estate::tests::given_bus_backpressure_when_published_then_loss_audited_in_log` |
| F-BUS-2 | Loss-callback sink itself failing | Guarded callback (append error -> stderr) | Warning on stderr; bus keeps serving | Fix audit path | `bus.rs`/`estate.rs` callback guard; code review |
| F-BUS-3 | Subscriber pattern misconfig (never matches) | Publish to zero queues = no-op | No unbounded buffering exists by design | Fix pattern | `bus.rs` design; `bus::tests::given_topic_filter…` |

## 7. Network presence and hardware (F-NET-*, F-HW-*)

| ID | Failure | Detection | System response | Recovery | Verified by |
|---|---|---|---|---|---|
| F-NET-1 | Router swap / vendor change | Protocol-layer sources (DHCP leases, `ip neigh`) | Presence continues on any router | n/a | `network::tests` parser suite |
| F-NET-2 | Malformed router output | Line-tolerant parsers | Garbage lines skipped, never fatal | n/a | `network::tests::given_garbage_lines_when_parsed_then_skipped` |
| F-NET-3 | MAC spoof / clone | Single spoofed channel cannot assert full confidence; presence is corroborating-only | Reduced confidence at best | Investigate; rotate keys if hostile | architecture invariant |
| F-HW-1 | BLE band dies / out of range | Freshness window expiry | stale→anomaly ladder; snooze tap path | Reconnect or replace band | `e2e::given_dropout_then_silence_when_derived_then_authority_downgrades_with_audit` |
| F-HW-2 | Vendor cloud dependency sneaks in | Adapter boundary: standard GATT UUIDs only | Vendor-cloud data cannot enter the live path | n/a | architecture invariant; `ble::tests` standard-characteristic tests |
| F-HW-3 | BLE reconnect storm | Backoff+jitter ladder capped at 300s | Capped retry, reconnect counter for forensics | n/a | `ble::tests::given_reconnect_storm_when_delays_drawn_then_capped_and_counted`; radio loop `hardware-gated` (needs physical spike) |
| F-HW-4 | Misconfigured characteristic UUID | Unknown-char lookup | Fail loud (error), never silent | Fix config | `ble::tests::given_unknown_characteristic_when_handled_then_fails_loud` |

## 8. Operations (F-OPS-*)

| ID | Failure | Detection | System response | Recovery | Verified by |
|---|---|---|---|---|---|
| F-OPS-1 | Config missing required keys | `Estate::new` validation + `config::validate` | `ConfigError` with key name, boot aborts | Fix config | `estate::tests::given_missing_channels_config_when_booted_then_refused`; `config::tests` |
| F-OPS-2 | Port already bound | `serve()` bind error | Process exits nonzero (compose restarts per policy) | Free port / change config | `http::serve` error path; compose `restart: unless-stopped` |
| F-OPS-3 | Crash loop | compose restart policy + json-file logging with caps | Service restarts; logs capped (10 MB x 3) | `docker compose logs tempo` | docker-compose.yml |
| F-OPS-4 | Backup restore drift | Boot verifies chain + checkpoint anchors | Refuse on mismatch; quarantine on anchor mismatch | R1 runbook | `e2e::given_backup_restore_runbook…`; smoke steps 5–6 |
| F-OPS-5 | Signing key file lost/corrupt | Boot: key load failure or checkpoint signature failure vs regenerated key | Refuse/quarantine — never silently re-anchor | Restore key backup (0600) or deliberate re-anchor (R2) | `estate::load_signing_key`; F-LOG-5 tests |
| F-OPS-6 | First-run misconfiguration | Starter config generated with random device secrets; boot waits for intentional edit | Exit 0 with next-step instructions | Edit config, re-run | `config::tests::given_missing_config_when_load_or_create…`; smoke step 1 |
| F-OPS-7 | Container runs as root / privilege escalation | Dockerfile non-root uid 10001, `no-new-privileges` | Runtime blocked | n/a | Dockerfile / compose |
| F-OPS-8 | Dashboard stale/misleading data | Poll loop over `/state` + `/events`; log.ok banner | Shows live values or explicit degraded banner | Refresh/restart | `dashboard/index.html` (textContent-only, no XSS surface) |

---

## 9. Recovery runbooks

**R1 — restore from backup + checkpoint (S1 path)**
1. Stop the node. Confirm the tampered/quarantined log is preserved
   (`*.quarantine-*` or copy aside) for forensics.
2. Restore `events.jsonl` AND `events.jsonl.ckp` AND `events.jsonl.sign` from
   the latest backup taken while healthy (the smoke test proves this loop).
3. `tempo --config <cfg> --verify-only` — must print
   `log: OK (ok); checkpoints: OK (ok)`.
4. Start the node; confirm `/healthz` `log_ok: true`.

**R2 — deliberate re-anchor after key loss**
1. Verify the current chain with `--verify-only` (chain OK, checkpoints fail).
2. Move the `.ckp` and `.sign` files aside; document the incident.
3. Boot: a new signing key is generated; the first checkpoint anchors the
   verified chain head. The old checkpoint file remains as evidence.
4. This is an operator-authorised act and must be recorded in the estate's
   external incident log — the node cannot distinguish it from F-LOG-5, by design.

**R3 — off-node anchor (anti-F-LOG-7)**
Copy `events.jsonl.ckp` (and optionally the last N MB of `events.jsonl`) to a
second machine on every checkpoint. A node that loses its disk can then prove
how much history it lost, and an attacker cannot erase history without also
defeating the off-node copy.

**R4 — log archival**
Snapshot `events.jsonl` (and `.ckp`) while the node is stopped or after a
`--verify-only` pass; move the snapshot off-node; keep the live file. The
chain makes an archived prefix independently verifiable forever.

**R5 — key enrollment / rotation**
1. Generate on an offline machine:
   `cargo run --release --example keygen` (or any Ed25519 tool) and print
   the private + public hex.
2. Put the PUBLIC hex into `principals.<name>.pubkey_hex`; keep the private
   key offline (it signs snooze/authority challenges only).
3. Rotation = replace pubkey_hex; old key stops verifying at the next
   challenge (single-use nonces mean no session to revoke).

## 10. Residual risks (honest register)

- Single-node availability: v2.0 is one node by design. RTO after host loss =
  operator-driven restore (minutes), RPO = un-checkpointed tail (bounded by
  `checkpoint_every`; at the default 500 events ≈ ≤ 8h of 1/min telemetry;
  set lower for tighter RPO). Signed-token active/passive failover is the
  spec's Phase-1 item and is NOT in this release.
- F-HW-3's radio loop (the actual HCI reconnection against a physical band)
  needs the BLE spike; the tested ladder logic is the contract the spike must
  honour.
- Log archival (R4) and off-node anchoring (R3) are documented procedures, not
  automated jobs, in v2.0.
- `time_sync: "trust"` (default) assumes the host syncs its clock. Set
  `"time_sync": "chrony"` to have confidence reflect reality.
- The HTTP server is `tiny_http` behind 4 worker threads: a deliberate
  minimal-dependency choice for a single-node internal API, not a CDN-tier
  web server. Put a reverse proxy in front if you expose it beyond localhost.
