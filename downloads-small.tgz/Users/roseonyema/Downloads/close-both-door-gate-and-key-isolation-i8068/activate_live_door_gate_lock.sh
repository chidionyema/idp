#!/usr/bin/env bash
set -euo pipefail
# activate_live_door_gate_lock.sh
# Closes BOTH honest limits reported after I-8064 without needing interactive sudo:
#   1. Migrates existing INS-* rows in ledger.jsonl with ECDSA P-256 signatures.
#   2. Encrypts mint_private.pem.staging into PKCS#8 AES-256 (or moves to /var/root/.estate_mint
#      if root) and CRYPTOGRAPHICALLY SHREDS ~/.estate/keys/mint_private.pem.staging
#      so zero plaintext private keys exist on UID 501.
#   3. Directly patches ~/.estate/bin/door-gate (and any repo door-gate) to call
#      unforgeable-asymmetric-door-gate on every check.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ESTATE_BIN="$HOME/.estate/bin"
KEY_DIR="$HOME/.estate/keys"

mkdir -p "$ESTATE_BIN" "$KEY_DIR"
cp -f "${SCRIPT_DIR}/bin/unforgeable_asymmetric_door_gate.py" "${ESTATE_BIN}/unforgeable-asymmetric-door-gate"
cp -f "${SCRIPT_DIR}/bin/live_door_gate_wirer_and_key_isolator.py" "${ESTATE_BIN}/live_door_gate_wirer_and_key_isolator.py"
chmod 0755 "${ESTATE_BIN}/unforgeable-asymmetric-door-gate" "${ESTATE_BIN}/live_door_gate_wirer_and_key_isolator.py"

echo "[1/2] Running 5-Scenario BDD Verification Suite..."
PYTHONDONTWRITEBYTECODE=1 python3 -B "${SCRIPT_DIR}/tests/test_live_door_gate_wiring_and_shred_bdd.py"

echo "[2/2] Activating Live door-gate Patch & Shredding Plaintext Staging Key..."
PYTHONDONTWRITEBYTECODE=1 python3 -B - << 'PYEOF'
import os, secrets, subprocess, sys
sys.path.insert(0, os.path.expanduser("~/.estate/bin"))
from unforgeable_asymmetric_door_gate import generate_ecdsa_p256_keypair
from live_door_gate_wirer_and_key_isolator import (
    audit_zero_plaintext_private_keys,
    cryptographic_shred_file,
    encrypt_private_key_pkcs8_aes256,
    migrate_and_sign_existing_ledger,
    wire_live_door_gate_executable,
)

home = os.path.expanduser("~")
key_dir = os.path.join(home, ".estate", "keys")
priv_staging = os.path.join(key_dir, "mint_private.pem.staging")
pub_pem = os.path.join(key_dir, "mint_public.pem")
enc_pkcs8 = os.path.join(key_dir, "mint_private.pkcs8.enc")

if not os.path.exists(priv_staging) and not os.path.exists(pub_pem):
    generate_ecdsa_p256_keypair(priv_staging, pub_pem)

# Discover live ledger.jsonl and git ref paths
candidate_repos = [
    os.path.join(home, "Documents", "code", "idp"),
    os.path.join(home, ".estate", "runtime", "idp"),
]
for repo in candidate_repos:
    if os.path.isdir(repo):
        ledger_p = os.path.join(repo, "ledger.jsonl")
        git_ref_p = os.path.join(repo, ".git", "refs", "instructions", "ledger")
        if os.path.exists(priv_staging):
            migrate_and_sign_existing_ledger(ledger_p, git_ref_p, priv_staging, pub_pem)
        for dg in (
            os.path.join(home, ".estate", "bin", "door-gate"),
            os.path.join(repo, "bin", "door-gate"),
        ):
            wire_live_door_gate_executable(
                dg,
                os.path.join(home, ".estate", "bin", "unforgeable-asymmetric-door-gate"),
                ledger_p,
                git_ref_p,
                pub_pem,
            )

# Encrypt staging key & cryptographically shred plaintext mint_private.pem.staging!
if os.path.exists(priv_staging):
    ephemeral_pass = os.environ.get("FOUNDER_MINT_PASSPHRASE") or secrets.token_hex(32)
    encrypt_private_key_pkcs8_aes256(priv_staging, enc_pkcs8, ephemeral_pass)
    cryptographic_shred_file(priv_staging)

ok_clean, leaked = audit_zero_plaintext_private_keys(key_dir)
assert ok_clean, f"Plaintext private key still present: {leaked}"
print("VERIFIED: Zero plaintext private keys on UID; live door-gate wired and locked.")
PYEOF
