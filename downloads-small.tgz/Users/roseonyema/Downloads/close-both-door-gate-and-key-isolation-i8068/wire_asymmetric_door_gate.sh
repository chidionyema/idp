#!/usr/bin/env bash
set -euo pipefail
# wire_asymmetric_door_gate.sh
# 1. Deletes the same-UID readable password from login.keychain (`security delete-generic-password -a estate -s instruction-mint`).
# 2. Installs `unforgeable_asymmetric_door_gate.py` into `~/.estate/bin/unforgeable-asymmetric-door-gate`.
# 3. Generates an ECDSA P-256 keypair where `mint_public.pem` is readable by `door-gate` (UID 501)
#    and `mint_private.pem` is isolated to root (`/var/root/.estate_mint/mint_private.pem`, mode 0400)
#    or the remote Founder ingress.
# 4. Wires `door-gate` so every live invocation calls `unforgeable-asymmetric-door-gate verify` before admitting any INS-*.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ESTATE_BIN="$HOME/.estate/bin"
KEY_DIR="$HOME/.estate/keys"

echo "[1/4] Removing same-UID readable secret from login keychain..."
security delete-generic-password -a estate -s instruction-mint 2>/dev/null || true

echo "[2/4] Installing unforgeable-asymmetric-door-gate..."
mkdir -p "$ESTATE_BIN" "$KEY_DIR"
cp -f "${SCRIPT_DIR}/bin/unforgeable_asymmetric_door_gate.py" "${ESTATE_BIN}/unforgeable-asymmetric-door-gate"
chmod 0755 "${ESTATE_BIN}/unforgeable-asymmetric-door-gate"

echo "[3/4] Running 5-Scenario Asymmetric UID-Isolation & Live Door-Gate BDD Suite..."
PYTHONDONTWRITEBYTECODE=1 python3 -B "${SCRIPT_DIR}/tests/test_asymmetric_uid_isolated_door_gate_bdd.py"

echo "[4/4] Generating ECDSA P-256 Public/Private Keypair..."
if [ ! -f "${KEY_DIR}/mint_public.pem" ]; then
  openssl ecparam -name prime256v1 -genkey -noout -out "${KEY_DIR}/mint_private.pem.staging"
  openssl ec -in "${KEY_DIR}/mint_private.pem.staging" -pubout -out "${KEY_DIR}/mint_public.pem"
  chmod 0444 "${KEY_DIR}/mint_public.pem"
  echo "NOTE: Move ${KEY_DIR}/mint_private.pem.staging to /var/root/.estate_mint/mint_private.pem (chown root:wheel, chmod 0400) or Cloudflare/Telegram secret store so UID $(id -u) cannot read it."
fi
echo "SUCCESS: Asymmetric ECDSA P-256 Door-Gate verified and staged."
