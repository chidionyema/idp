# IDP Autonomous Media Department — implementation charter v1

**Date:** 2026-10-28  **Repository:** `chidionyema/idp` **Inspected main:** `2285593f0a4da6c3aebb895a1e55cd3fcf6eee83` **Status:** PROPOSED; NOT DEPLOYED OR CERTIFIED.

## 1. Executive mandate

Establish an autonomous Media Department as the first reusable operating model for autonomous estate departments. Its remit spans live estate film, real-time virtual worlds, agent avatars, interactive product demonstrations, media production, research, prototyping, proposals, visual quality and operational maintenance. It must **discover work proactively, research, prototype, evaluate, propose, execute authorized changes, verify outcomes, and learn**. A recurring research report without a tested artifact is not a completed deliverable.

## 2. Non-negotiable estate constraints

1. `AGENTS.md` and `docs/epics/2026-10-25-estate-master-epic.md` are the programme authority: structured contracts, shared memory, evidence, metric-driven improvement, named deciders and no duplicate infrastructure.
2. ADR `docs/decisions/0037-the-film-is-a-deterministic-twin-of-the-event-spine.md` is **accepted**. Live estate film is a deterministic projection of actual events. No generative video in the core truth path. Generative media is permitted only as a separately labelled optional creative/export lane, subject to new governance decisions where needed.
3. `docs/specs/2026-10-23-estate-as-movie-director-engine.md` establishes the scene contract, voice causality, real artifact pane, Fleet/Face surfaces, S0–S4 and rollback criteria. `docs/research/2026-10-25-virtual-world-vs-realtime-film.md` establishes virtual worlds as a *second renderer* of the same scene contract, not an alternative source of truth.
4. Reuse existing NATS JetStream, Temporal, Dagster, estate-execute, claim/approval doors, context broker, unified memory, Fleet, Face and research engine. New tools require measured superiority and an integration/removal plan.
5. The department must not publish, spend beyond cap, modify production, impersonate an agent, or issue a live steering command without existing policy authorization.

## 3. Research findings and selection rules

- Google Research, 2026-09-24, *Automating coherent long-form video generation*: hierarchical multi-agent pre-production, keyframe/video/audio specialists, continuity tracking and closed-loop multimodal judging. Adopt **planning and evaluation patterns**, not generative footage for live estate truth. https://www.research.google/blog/coherent-long-form-video-generation/
- NVIDIA, 2026-09-16, *How to Use AI Agents to Prepare 3D Scenes for Simulation*: Blender MCP, OpenUSD, semantic labels, physics, visual preflight and SimReady validation. Candidate for *offline authoring and simulations*; not a reason to install a GPU-heavy live world stack. https://developer.nvidia.com/blog/how-to-use-ai-agents-to-prepare-3d-scenes-for-simulation/
- OpenAI Agents SDK: tracing, specialist handoffs and durable Temporal integration. Reuse estate Temporal as orchestrator rather than create a competing workflow service. https://openai.github.io/openai-agents-python/running_agents/
- Existing repo comparison: Three.js (already used in Fleet) as first renderer; three-vrm only if character fidelity is required; Colyseus only if authoritative multiplayer state is proven necessary; Playwright as the real-browser truth anchor; Blender/OpenUSD as offline asset format; optional generated clips via model-neutral provider adapter after benchmark/licence review.
- Prior research-engine failure is concrete: `platform/research-engine/objective-adapter.py` documents a wrong research lane producing zero admitted claims, and requires founder Continue/Park. The new department must autonomously advance **within bounded delegated authority** and terminate in experiments, proposals and measurable outcomes rather than passively waiting after a report.

## 4. Reusable department operating contract

`Objective -> Opportunity -> Hypothesis -> ResearchEvidence -> ExperimentPlan -> PrototypeArtifact -> IndependentEvaluation -> Proposal -> GovernedChange -> ProductionVerification -> Outcome -> Learning`

Mandatory envelope on every artifact/event: `schema_version`, `department_id`, `objective_id`, `run_id`, `parent_run_id`, `kind`, `state`, `source_ref`, `source_revision`, `evidence_refs`, `artifact_uri`, `artifact_sha256`, `created_at`, `expires_at`, `authority`, `policy_decision`, `budget_cap_usd`, `spend_usd`, `evaluator_id`, `verdict`, `reason`. Nullable fields must be explicitly declared by schema and validated at the relevant transition. Never accept an untrusted generated assertion as a production observation.

States: `NEW, TRIAGED, RESEARCHING, PROTOTYPING, EVALUATING, PROPOSED, APPROVED, SHIPPING, VERIFYING, OPERATING, LEARNING, BLOCKED, PARKED, REJECTED`. The runtime enforces legal transitions. No `RESEARCHING -> SHIPPING`; no `PROPOSED -> APPROVED` without the existing authorization door; no `VERIFYING -> OPERATING` without independent evidence.

**Execution model:** a single durable department workflow instantiated by configuration; typed task queues and capability-scoped workers. Agents are replaceable workers, not independent organizations. Each action names its decider and writes an immutable run/event reference. Queueing is idempotent by `(objective_id, action_kind, input_revision)`. Retry with exponential backoff and finite maximum; poison items go to an existing dead-letter mechanism; cancellation propagates. Enforce per-objective and per-day budgets, concurrency and time ceilings at the existing router/execution boundary. A verifier cannot certify its own prototype.

## 5. Department capabilities

| Capability | Inputs | Concrete output | Gate |
|---|---|---|---|
| Portfolio governor | Founder objectives, estate signals, observed gaps | Ranked bounded opportunity queue | Objective provenance, budget, no duplicates |
| Research scout | Versioned research questions, web/repo sources | Source-linked comparison, falsifiable hypothesis | Source quality, currency, relevance |
| Technical/creative director | Scene contract, user goals | Storyboard, shot grammar, world interaction plan | Causal truth, feasibility |
| Prototype studio | Approved experiment plan, sandbox | Working code/demo, visual capture, digest | Sandbox, licences, reproducibility |
| Independent evaluator | Prototype, acceptance fixtures | Structured scorecard, adversarial results, verdict | No self-approval |
| Delivery and operations | Approved proposal | Governed PR, deployed artifact, rollback record | CI, policy, live smoke test |
| Learning loop | Runtime outcome and cost | Updated experiment record and future policy proposal | Measured delta, provenance |

## 6. Flagship acceptance scenario

Founder opens Fleet and sees an avatar accurately representing an agent's *actual* work; speaks a directive; the existing voice/intent gate changes the agent's real work; the world shows the resulting real task, test, commit and deployment transitions; the founder opens a genuine deployed URL in a real browser; the sequence replays deterministically as film. Avatar animations without backing event IDs are forbidden. A screenshot is never a substitute for the real running application. Promotional generative footage, if produced, is labelled and isolated from the live state renderer.

## 7. Work packages, owners, evidence and release gates

### M0 — Measured baseline (no new runtime)
Inventory actual code, active workloads, tests, GitHub issues, past research/science department failures, event contracts, Fleet/Face hooks, runtime resource ceilings, and existing media dependencies. Capture source SHA, command outputs, observed caller graphs and deployment status. **Pass:** a machine-readable capability matrix with `implemented`, `observed_live`, `tested`, `unknown` and `broken` fields, and a ranked non-duplication gap list. Never infer deployment from YAML.

### M1 — Department contract and BDD
Add versioned JSON Schemas for objective, opportunity, experiment, artifact, review, decision, outcome and event; deterministic state machine; compatibility/migration policy. **Pass:** tests reject missing source refs, illegal transitions, budget overflow, stale provenance, duplicate idempotency keys and unauthorized writes.

### M2 — Durable autonomy runtime
Integrate existing Temporal/Dagster and JetStream, router budgets, issue/claim workflow and estate-execute. Configure signal subscriptions and scheduled scans with backpressure, dedupe, finite retries, cancellation and pause/kill switch. **Pass:** same input replay does not duplicate PRs, expenditure or publication; restart resumes safely; poison work does not block other objectives.

### M3 — Media studio and scene renderers
Integrate existing Go director and scene contract with Fleet/Face; prototype one browser-native agent/avatar scene using Three.js and real event-driven state; attach real Playwright browser proof. **Pass:** deterministic replay of ordered events; stale/out-of-order and fabricated events refused; actual founder directive correlated to downstream intent and result; graceful degraded mode when stream is unavailable.

### M4 — Research/prototype loop
Automatically identify one estate media gap, compare at least three candidate implementations (including doing nothing), execute one bounded prototype and produce a scored, inspectable proposal. **Pass:** independently runnable prototype, source citations, asset licences, measured latency/cost, known failure modes and a justified recommendation. A text-only report fails.

### M5 — Independent grading
Visual regression, narrative/scene continuity, event-to-avatar fidelity, accessibility, browser evidence, adversarial prompt injection, budget, licensing, recovery and SLO tests. **Pass:** no false positive for fabricated agent activity, missing authorization or unverified deployment. Human aesthetic judgment is an explicit review signal, not a fabricated numeric proof.

### M6 — Operate and learn
Expose a department page in Fleet/Face with objective queue, experiments, live run state, blockers, costs, prototypes, proposal decisions, deployments and outcome deltas. Monitor failure, backlog, budget, stale evidence and unattended liveness. **Pass:** a scheduled/event-driven unattended run progresses from objective to real evaluated prototype and proposal; approved change goes through governed shipping and outcome tracking; a rollback drill succeeds.

### M7 — Prove reusable department spine
Instantiate Research and Science in shadow mode with the same schemas/workflow/gates but their own evaluators and policies. **Pass:** both generate executable experiments with outcome measurements, no parallel scheduler/ledger/approval stack and no false operational status.

## 8. Initial proposed SLOs (validate against M0 baseline)

- 100% live avatar activity linked to real event IDs and revisions; 0 fabricated production states.
- 100% unauthorized tool/action requests refused at the authoritative execution boundary.
- 0 duplicate externally visible effects under retry and replay fixtures.
- 100% deterministic replay equivalence for core scene outputs (exact schema-defined equivalence).
- 100% proposals include executable artifact, independent scorecard, cost and source references.
- First evaluated prototype proposal within 24 hours of a bounded accepted objective *where budget, source access and capacity are available*.
- No uncapped external API spending; no indefinite retries; explicit pause/kill and rollback.
- Record baseline-to-treatment deltas for research time, prototype success, cost per accepted proposal and founder intervention count.

## 9. Certification evidence packet

For each gate store: immutable source revision, workflow run ID, test command and exit code, logs, signed/digested artifacts, independent evaluator identity, deployment identity, observed smoke test, cost and latency measurement, security result, rollback drill and final decision. **Production certified** is a computed result over evidence, not a manually assigned label. Fail closed for unsupported production claims; remain useful in read-only/degraded mode.

## 10. Governance and initial action

Before modifying repository code, create a GitHub issue, acquire the AGENTS.md claim/heartbeat, inspect concurrent work and use `lane/<name>` branches with `estate-execute lane-submit`. First PR: M0 baseline + M1 schemas and BDD only. No direct push to `main`.

**Current access blocker:** attempted to create the governing issue via the connected GitHub app on 2026-10-28; GitHub returned `403 Resource not accessible by integration`. The issue has **not** been created, no repository changes have been made, and no live workloads have been started. Granting GitHub Issues write permission or executing the issue creation through an authorized estate agent is required to initiate the governed implementation lane.

## 11. Definition of done

The Media Department is a persistent, bounded, observable autonomous operating capability that independently discovers and evaluates opportunities, produces working media artifacts, requests authorization only where policy requires, ships via estate gates, measures real-world outcomes and feeds lessons back into shared context/memory. A second department uses the same spine without copying infrastructure. No operational claim is made without execution evidence.
