# 1. Move to home to clear working directory issues
cd ~

# 2. Stop both the local router and the watchdog completely
launchctl bootout gui/$(id -u)/com.estate.litellm-local 2>/dev/null
launchctl bootout gui/$(id -u)/com.estate.watchdog 2>/dev/null

# 3. Bring the local router back up via launchd
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.estate.litellm-local.plist

# 4. Wait 15 seconds, then check its status code (should be 0 or running)
sleep 15
launchctl list | grep litellm-local