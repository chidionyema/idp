# RFC: IDP Estate-Wide Context and Knowledge Substrate

**Status:** Proposed / source-grounded engineering specification (2026-10-28). **Not** an implementation-complete or production-certified claim.

**Repository:** `chidionyema/idp`, `main`, inspected via connected GitHub source. **Scope:** all estate consumers, not merely epistemic evidence or Oracle.

## 0. Executive decision

**Extend, do not replace, the estate's existing context stack.** The repository already contains a substantial context compiler, policy broker, Gortex indexing pipeline, memory service, estate graph, catalog, and event capture. Building a new generic RAG stack would duplicate implemented functionality and violate the estate's one-engine design. The missing product is a *federated, task-specific context service* spanning code, operational state, structured topology, decisions, history, and authenticated evidence, using existing systems as authorities. A retrieval hit must never silently become an assertion of live truth.

**Architecture rule:** One policy entry point and common context envelope; multiple *source-of-truth adapters*, not a second ranker or universal vector store. Existing Gortex owns code ranking. Unified memory owns memory retrieval. Kubernetes/Git/CI own their live and historical state. Context compilation merges typed evidence under explicit authority and freshness rules.

## 1. Source-verified baseline

| Capability | Source | Verified from source | Not established |
|---|---|---|---|
| Policy broker | `platform/estate/context/broker.py` (764 lines) | freshness decisions; read-only tool allowlist; path and token budget decisions; secret scrubbing; provenance; engine client | live gateway bypass resistance, authorization correctness in deployed environment |
| MCP broker | `platform/estate/context/server.py` (767) | `estate_context` and `estate_context_status`; `/mcp`; claim lookup; index manifest; metrics; source excerpt handling | live service availability, agent coverage |
| Compiler | `platform/estate/context/plan.py` (609), `bin/estate-context-compile` (725) | deterministic ContextPlan, engine order preservation, token budget, source digests, catalog/affected-graph integration | representative real-world retrieval quality |
| Local fallback | `platform/estate/context/local_engine.py` (195) | Gortex CLI adapter and freshness reporting | whether installed on all agent hosts |
| CI index build | `.github/workflows/context-index.yml` (220) | pins Gortex v0.64.11; checks index commit and live smart_context answer; publishes signed OCI artifact | latest workflow success; whether all intended repositories indexed |
| Broker deployment | `platform/mcp/estate-context-broker.yaml` (239) | private loopback Gortex sidecar; broker container; OCI index pull; PVC | actual pod health; authenticated gateway routing |
| Broker verification | `bin/estate-context-gate` (901); `tests/test_estate_context_broker.py` (316); `tests/test_estate_context_compile.py` (645) | source includes fail-case tests, policy gates, catalog checks | tests not executed in this review |
| Unified memory | `platform/unified-memory-server/main.py` (1337), `ranking.py` (95) | memory write/read/history/search/recall/brief, embedding status/backfill, harness prefetch/consolidate | live embedding backend health; retrieval quality |
| Memory MCP adapter | `mcp/plugins/estate_memory.py` | structured memory ingest; R1/R2/R3 probe and trust tier | end-to-end operational success |
| Estate topology | `bin/idp-affected-graph`, `bin/catalog-projection`, Backstage entity providers | code and catalog paths exist and compiler consumes their results | completeness and edge correctness |
| Conversational graph | `platform/llm/graph_capture.py`, `bin/estate-graph-drain` | router capture and graph-drain pipeline exists | full coverage, durability and quality |
| Evidence | `bin/estate-claim-check`, Aevum and local gates | claim re-execution and evidence recording | semantic entailment, unified authority |

**Source links:**
- https://github.com/chidionyema/idp/blob/main/platform/estate/context/broker.py
- https://github.com/chidionyema/idp/blob/main/platform/estate/context/server.py
- https://github.com/chidionyema/idp/blob/main/platform/estate/context/plan.py
- https://github.com/chidionyema/idp/blob/main/.github/workflows/context-index.yml
- https://github.com/chidionyema/idp/blob/main/platform/unified-memory-server/main.py
- https://github.com/chidionyema/idp/blob/main/platform/mcp/estate-context-broker.yaml

## 2. System boundaries and invariants

1. **No new code indexer or ranker.** Use the existing Gortex versioned code index and its smart_context, symbol, and graph tools. Other source-specific retrieval engines may rank within their own domains; cross-domain merging uses deterministic policies, not a duplicate semantic ranker for code.
2. **No shadow memory store.** Unified memory remains the source for remembered decisions, preferences, incidents and measurements. Index projections may be rebuilt from authoritative data but cannot become write authorities.
3. **No operational assertions from cached documents.** Questions with `requires_live=true` must query live authoritative APIs or return `UNKNOWN/UNAVAILABLE`; historical context is supplemental.
4. **One broker for client-facing context.** Add capabilities to existing MCP broker, preserving existing `estate_context` contract. Never expose private engine credentials to consumers.
5. **Evidence is typed.** Every result identifies source type, immutable revision or observation time, method, and confidence *category*; no uncalibrated numeric confidence scores.
6. **No silent fallback.** Every unavailable source appears as a coverage gap. A partial result cannot be labelled complete.
7. **Read-only context retrieval.** Retrieval never mutates cluster, repository, tickets, or memory. Any remedial action passes the existing execution and authorization plane.
8. **Isolation by principal.** All adapters enforce caller identity, repository scope, namespace and data classification. Retrieval cache keys include the authorization scope and relevant revision.
9. **Budget before generation.** Token/latency/fanout limits are enforced before returning material; refusal reports the measured or bounded reason.
10. **Traceable decisions.** Each answer includes query ID, policy decisions, sources used, omissions, freshness status and reproducible reference IDs.

## 3. Query contract

Expose a new versioned tool `estate_context_resolve_v1` through the existing MCP broker. Keep `estate_context` and `estate_context_status` backward compatible. The following is a **proposed** API, not an existing implementation:

```json
{
  "query": "What would break if the unified-memory service were restarted?",
  "intent": "impact_analysis",
  "scope": {"repositories": ["chidionyema/idp"], "namespaces": ["estate"]},
  "temporal": {"mode": "live", "as_of": null, "max_age_seconds": 60},
  "evidence": {"minimum": "source_attributed", "require_independent_witness": false},
  "limits": {"token_budget": 4000, "deadline_ms": 5000, "max_sources": 24},
  "claim": {"issue": 0, "agent": ""}
}
```

**Request validation:** query 1–4096 Unicode characters; intent from enumerated list (`code_navigation`, `change_impact`, `runtime_diagnosis`, `incident_analysis`, `decision_recall`, `policy_lookup`, `estate_question`); temporal mode `commit|as_of|live`; `as_of` required for historical time travel; commit SHA required for commit mode unless broker resolves a pinned commit; deadline 250–30000ms; token budget 256–32000; max_sources 1–100. Reject unknown scopes and invalid combinations. Do not make `claim.issue=0` a privileged bypass: read-only access policy must explicitly define whether claims are required, based on existing broker governance.

Response shape:

```json
{
  "schema_version": "1.0",
  "query_id": "opaque-request-id",
  "status": "PARTIAL",
  "answerability": "SUPPORTED_WITH_GAPS",
  "as_of": "2026-10-28T12:00:00Z",
  "context_plan": {"items": [], "used_tokens": 0, "plan_hash": "sha256:..."},
  "sources": [{
    "id": "src-1", "type": "git_source", "authority": "github",
    "locator": "repo:path#L10-L30", "revision": "full-git-sha",
    "observed_at": null, "retrieved_at": "2026-10-28T12:00:00Z",
    "digest": "sha256:...", "verification": "SOURCE_AUTHENTICATED",
    "claims_supported": ["claim-1"]
  }],
  "claims": [{"id":"claim-1","text":"...","support":["src-1"],"status":"SUPPORTED_SOURCE"}],
  "gaps": [{"source":"kubernetes","reason":"TIMEOUT","impact":"live state unknown"}],
  "policy": {"scope":"allowed","freshness":"partial","redactions":0},
  "timing_ms": {"total":0},
  "cache": {"hit":false,"key":"..."}
}
```

**Statuses:** `COMPLETE`, `PARTIAL`, `REFUSED`, `UNAVAILABLE`, `INVALID_REQUEST`. **Claim statuses:** `SUPPORTED_SOURCE`, `LIVE_OBSERVED`, `REEXECUTED`, `CONTRADICTED`, `UNVERIFIED`, `STALE`. `SUPPORTED_SOURCE` means a specific source passage was retrieved and attributed; it does *not* imply entailment or real-world truth. Use `REEXECUTED` only with a proposition-bound checker and matched result.

## 4. Federated retrieval adapters

Each adapter implements `discover(request) -> Candidate[]`, `hydrate(candidate, budget) -> Evidence[]`, `health() -> Status`. Adapter discovery is bounded, parallel where safe, and always returns structured errors. No adapter may create an LLM call merely to enumerate candidates.

| Adapter | Existing authority | Initial query modes | Freshness rule |
|---|---|---|---|
| `code` | Gortex through existing broker engine client | symbols, implementations, callers, tests, code impact | indexed commit must equal requested commit; working-copy caveat preserved |
| `catalog` | Backstage/catalog projection and `idp-affected-graph` | service owners, topology, dependencies | projection revision/time reported; unobserved edges labelled declared |
| `memory` | unified-memory HTTP API | decisions, incidents, previous investigations | retrieved memory includes version, trust tier, created/updated time; never treated as current runtime state |
| `git_ci` | GitHub commits, checks, workflows | diffs, build outcomes, regression history | immutable commit/check-run identifiers, fetched at query time or bounded cache |
| `runtime` | Kubernetes API and monitoring backends | pods, deployments, events, health, observed dependencies | live mode requires observation within max_age_seconds; timeouts yield gaps |
| `telemetry` | logs, metrics, traces, event bus | incident timelines and failure correlation | explicit time window, source timestamp and clock-skew handling |
| `policy` | claim-gate, rules and current issue claim records | ownership, scope, applicable policy | live policy decision; never infer permission from semantic search |
| `evidence` | Aevum/claim checker | verified receipts, reproducible measurements | validate relevant proof with bound subject and verifier; report unverifiable separately |

**Rollout sequencing:** `code + catalog + memory` first (already implemented to varying degrees); then `git_ci + runtime`; then `telemetry + evidence`. Do not assume a connector exists merely because a deployment YAML exists. Each adapter has a separately verified access path.

## 5. Deterministic context compilation algorithm

1. Validate schema, authenticate principal, resolve tenant/scope, and apply broker policy.
2. Classify intent using deterministic signals and optionally a bounded model classifier only when ambiguous. A model cannot grant authorization or freshness exemptions.
3. Create a retrieval plan listing required and optional adapters. Example: `runtime_diagnosis` requires runtime observations; `code_navigation` requires code index.
4. Query adapters in parallel under a global deadline; enforce per-adapter fanout and concurrency. Collect candidate IDs, source timestamps and declared scores without comparing incomparable score scales.
5. Hydrate the top candidates *within each authority domain*. Reuse Gortex's order for code. Preserve structured graph edges and source excerpts.
6. Deduplicate by `(source_type, immutable_identity, revision, span)`; retain cross-source corroboration as separate evidence.
7. Detect source conflicts: same entity/property but differing values; retain both with observation times. Never choose a winner merely because semantic similarity is higher.
8. Apply authority ordering **per claim type**: live observed state > historical description for live questions; immutable code at requested commit > documentation for implementation questions; signed event > unsigned assertion for event-origin questions. No universal ranking across all claim types.
9. Allocate bounded tokens by source category, then compile deterministic ContextPlan and provenance envelope. Preserve existing plan hashing and source digest rules.
10. Return answerability/coverage and explicit missing sources. Answer generation, if requested, is a downstream consumer of the context envelope and must cite claim-support references.

**Caching:** cache keys include normalized query, intent, principal/scope hash, temporal mode, commit SHA or time bucket, adapter versions, policy revision, budget and schema version. No cross-principal cache reuse without explicit public classification. Invalidate code on new index manifest, catalog on projection revision, memory on write/version event, and runtime by TTL. Never serve expired live observations as fresh.

## 6. Security and epistemic acceptance

- **Prompt injection:** retrieved text is untrusted data; cannot issue tool instructions or override policy. Never concatenate retrieved instructions into the system policy channel.
- **Secrets:** scrub both adapter outputs and compiled response; preserve opaque secret references. Unit-test multiline and encoded secret variants; no claim that regex scrubbing is exhaustive.
- **Authorization:** perform scope enforcement before discovery and again on hydration; protect against path traversal, aliases, symlinks, tenant mixups and unauthorized cross-namespace graph edges.
- **Instrument execution:** `estate-claim-check` currently uses `bash -c`; no retrieved text may become a shell instrument. New context paths must use typed, allowlisted, sandboxed read-only probes with resource limits.
- **Claim binding:** do not promote a successful instrument to verified natural-language truth without a declared predicate, expected observation and provenance of the instrument itself.
- **Partial coverage:** a timeout, 403, stale index or missing source yields `PARTIAL` or `UNAVAILABLE`, never fabricated complete results.
- **Provenance:** all code references use immutable SHAs and line spans; all runtime observations include observed_at; all graph edges include declared/observed/inferred classification.
- **Cost:** maximum fanout, byte ceilings, token budgets, request deadlines, concurrency quotas and cache metrics are mandatory.

## 7. SLOs and release thresholds (proposed targets, not measured baselines)

**Pilot workload:** 100 curated questions covering code, architecture, deployment, incidents, policy, memory and multi-hop impact; at least 20 adversarial cases (stale documentation, wrong service, conflicting timestamps, malicious retrieved instructions, false passing checks).

| Measure | Pilot release threshold | Measurement |
|---|---|---|
| Critical authorization bypasses | 0 | negative integration and penetration tests |
| Stale response incorrectly marked live | 0 | forced index lag and runtime TTL expiry |
| Fabricated source identifiers | 0 | exact resolver verification |
| Required-source recall@20 | >= 0.90 | expert-labelled evidence sets |
| Supported factual claims with traceable source | >= 0.98 | claim-by-claim audit |
| Appropriate abstention on unanswerable cases | >= 0.95 | negative evaluation set |
| Deterministic compilation | 100% | same pinned inputs -> identical plan hash |
| Code-only p95 latency | <= 3s | warmed broker, representative queries |
| Federated p95 latency | <= 8s | mixed workload under pilot concurrency |
| Cost and token reporting | 100% requests | telemetry completeness |

These are **engineering acceptance criteria**, not forecasts. Adjust only after collecting baseline measurements; do not weaken correctness to meet latency.

## 8. Release programme / dependency graph

**Phase 0 — Reality audit (blocking):** Obtain CI runs, broker pod health, index manifest SHA, Gortex tool catalog, memory embedding health, catalog freshness, agentgateway route, actual consumer inventory, resource budgets. Execute existing tests and context gate. Deliver a signed baseline report with PASS/FAIL/BLIND per surface. **Exit:** all claimed existing capabilities have observed runtime or CI evidence; unknowns are explicit.

**Phase 1 — Contract and fixtures:** Implement response schema and source adapters' interface *without* changing current `estate_context`; build golden fixtures and adversarial tests. **Exit:** deterministic plan hashes, strict validation, no leaked secrets, zero unauthorized results.

**Phase 2 — Code/catalog/memory pilot:** Reuse existing Gortex engine, Backstage projections and unified memory. Implement deterministic cross-domain merging and coverage reporting. **Exit:** curated pilot thresholds met; old MCP tool unchanged.

**Phase 3 — Runtime and CI:** Add read-only GitHub/CI and Kubernetes adapters; bind live claims to observation time and resource UID. **Exit:** live/stale failure injection, access controls and p95 thresholds pass.

**Phase 4 — Telemetry, events and proof:** Add time-bounded logs/traces/events and proof retrieval. Correct semantic verification promotion before enabling verified answer labels. **Exit:** incident reconstruction and contradiction benchmarks pass.

**Phase 5 — Consumer migration:** Shadow-run Oracle and agent context calls; compare results and budgets, then canary by agent/surface with rollback. **Exit:** no regression against current code-context path, cost/latency within budgets, explicit consumer coverage.

**Phase 6 — Operational closure:** dashboards, runbooks, alerting, reindex failure handling, index artifact retention, access review, backup/restore, chaos tests and continuous evaluations. **Exit:** evidence of recovery from missing index, unavailable memory, unreachable Gortex, stale runtime, revoked permissions, and corrupted cache.

**No new database by default.** Add persistent technology only after a measured inability of Gortex, unified memory, existing catalog graph and event stores to meet an acceptance criterion.

## 9. Concrete repository changes proposed

All paths below are proposed; use the estate's issue/CLAIM/lane workflow before writing.

- `platform/estate/context/contracts.py`: versioned request, evidence, coverage and response models.
- `platform/estate/context/adapters/base.py`: typed adapter protocol and cancellation/deadline contract.
- `platform/estate/context/adapters/{code,catalog,memory}.py`: adapters around existing authorities, no duplicated indexes.
- `platform/estate/context/federation.py`: deterministic query planning, fanout, dedup, authority and budget handling.
- `platform/estate/context/server.py`: register `estate_context_resolve_v1`; preserve current tools.
- `platform/estate/context/broker.py`: extend policy to typed scopes and source-level authorization, preserving existing checks.
- `tests/context/`: schema, golden, negative, property, mutation, authorization, stale-index, timeout and source-conflict tests.
- `eval/estate-context/`: benchmark questions, labelled evidence sets, scorer and baseline reports.
- `platform/mcp/estate-context-broker.yaml`: only add env/secret/resource changes supported by measured deployment needs.
- `docs/runbooks/estate-context-substrate.md`: operations, degraded modes and rollback.

## 10. Mandatory test matrix

| Scenario | Expected outcome |
|---|---|
| Gortex index SHA differs from requested commit | REFUSED/STALE for commit mode |
| Working-copy index behind HEAD | labelled ASYNC_REINDEX, never presented as fresh commit proof |
| Memory server unavailable, code source available | PARTIAL; code preserved, memory gap explicit |
| Runtime source unavailable for live health question | UNAVAILABLE or PARTIAL with live status UNKNOWN |
| Retrieved document contains fake system instructions | treated as data; no action/tool invocation |
| User lacks repository or namespace scope | REFUSED before retrieval, no candidate leakage |
| Graph edge joins entities from unauthorized namespaces | edge omitted; gap or refusal recorded |
| Code and stale docs contradict | source-attributed conflict; implementation sourced from pinned code |
| Same input/revision/budget twice | identical context plan and plan_hash |
| Cache populated under privileged principal then queried by unprivileged one | no privilege leakage |
| Claim checker instrument succeeds but does not test proposition | UNVERIFIED, never REEXECUTED |
| Aevum unavailable or exported verification flag forged | proof status UNKNOWN/UNVERIFIED, not trusted |
| One adapter exceeds deadline | partial response within global deadline |
| Context output exceeds budget | deterministic omission/refusal, no silent truncation |
| Canary produces worse source recall or unauthorized results | automatic rollback to existing `estate_context` path |

## 11. Operations, ownership and rollback

**Ownership:** broker owns policy/response envelope; Gortex owns code ranking/index; unified memory owns memory records and semantic memory search; catalog owns declared topology; runtime adapters read authoritative runtime APIs; Aevum owns signed evidence. No shared write credentials across these domains.

**Observability:** emit request count, status, latency per adapter, cache hit, source coverage, stale/refused counts, index lag, redaction count, plan tokens, cost, unsupported claim rate. Include correlation ID but never secrets or full confidential payloads.

**Deployment:** feature flag new MCP tool; shadow mode; 5% canary; 25%; 100% only after gates. Retain old `estate_context` and immutable index artifacts. Rollback disables the new tool and adapter traffic, without migrating or mutating authoritative stores.

**Failure policy:** read-only code navigation may degrade to pinned source inspection if the broker explicitly supports that policy; live state queries must not degrade to historical memory while claiming freshness. Authorization uncertainty always refuses.

## 12. Unresolved questions requiring live inspection before code changes

1. Is `estate-context-broker` deployed, reachable through agentgateway, and exercised by Claude/Pi/other consumers?
2. What was the latest `context-index` workflow result, and which commit/OCI digest is deployed?
3. Which repositories and branches are actually indexed, and what is the measured index lag?
4. Is unified memory embedding/search healthy, and are memory records scoped by caller identity?
5. What are the existing runtime, CI, topology and telemetry API contracts and auth scopes?
6. What is the exact installed Gortex tool catalog, and which graph features are already usable?
7. Which agent tools currently bypass the broker, and what policy applies to non-editing read access?
8. What CPU/RAM/storage/network ceilings are available for production federation and cache?
9. Does the existing context gate pass against the current `main` and live deployment?
10. Which operational questions have verified reference answers suitable for a benchmark?

**No claim of shipping readiness is justified until Phase 0 is complete.** This RFC specifies an incremental build that can be shipped without duplicating the existing context engine; the outstanding work is to establish operational reality and then close measured gaps.
